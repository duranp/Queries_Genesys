
                      
                      
SELECT					reportes.groups_queues_pcrc.alias, count(1) llamadas_ofrecidas   
FROM					interaction_fact 
			INNER JOIN
						mediation_segment_fact ON interaction_fact.interaction_id = mediation_segment_fact.interaction_id 
            INNER JOIN
						resources ON mediation_segment_fact.resource_key = resources.resource_key 
            INNER JOIN
						resource_group_fact ON resources.resource_key = resource_group_fact.resource_key 
			inner join	
						reportes.groups_queues_pcrc on reportes.groups_queues_pcrc.group_key = resource_group_fact.group_key
      --      INNER JOIN
						--groups ON resource_group_fact.group_key = groups.group_key
where interaction_fact.id_fecha_inicial='20140701'
group by reportes.groups_queues_pcrc.alias