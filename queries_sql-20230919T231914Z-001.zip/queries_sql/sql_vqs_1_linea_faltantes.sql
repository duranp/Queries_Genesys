declare @vq_total as varchar (10)
declare @vq_detalle as varchar(500)
declare @sql as varchar(8000)


--set @vq_total= 98955	--Agent	AGENT	VAG_Re_Primera_Linea
--set @vq_total= 98956	--Agent	AGENT	VAG_Re_Segunda_Linea
--set @vq_total= 98262	--Agent	AGENT	VAG_Re_Tecnico_Comercial
--set @vq_total= 98935	--Agent	AGENT	VAG_TOTALES


--set @vq_total= 98280	--Queue	QUEUE	VQ_Re_Tecnico_Comercial
--set @vq_total= 98283	--Queue	QUEUE	VQ_Re_Total

--vq primera linea
set @vq_total= '98281'	--Queue	QUEUE	VQ_Re_Primera_Linea
set @vq_detalle= '98264,98255,98256,98250,98252,98260,98257,98253,98978,99031'--,98978'

--vqsegunda linea
--set @vq_detalle= '98261,98259,98258'
--set @vq_total= 98282	--Queue	QUEUE	VQ_Re_Segunda_Linea

set @sql='
select	
g.group_key,
rgf.resource_key,
a.resource_key,
g.group_name,
r.resource_name,
rgf.id_fecha_inicial,
rgf.id_fecha_final--,
--MAX(rgf.std_enterprise_end_time)std_enterprise_end_time 
			
from dbo.groups g
left join dbo.resource_group_fact rgf on rgf.group_key = g.group_key
left join reportes.groups_queues_pcrc gq on gq.group_key = g.group_key
left join infomart.resources r on rgf.resource_key=r.resource_key
left join (

					select	
					g.group_key,
					rgf.resource_key,
					rgf.id_fecha_inicial,
					rgf.id_fecha_final--,
					--MAX(rgf.std_enterprise_end_time)std_enterprise_end_time 
								
					from dbo.groups g
					join dbo.resource_group_fact rgf on rgf.group_key = g.group_key
					left join reportes.groups_queues_pcrc gq on gq.group_key = g.group_key
					where g.group_key in('+@vq_detalle+') and id_fecha_final > 20140911
					group by	g.group_key,
								rgf.resource_key,
								rgf.id_fecha_inicial,
								rgf.id_fecha_final


)a on rgf.resource_key =a.resource_key
where g.group_key in ('+@vq_total+') 
		and rgf.id_fecha_final> 20140911 and a.resource_key is null
group by	g.group_key,
			a.resource_key,
			g.group_name,
			r.resource_name,
			rgf.resource_key,
			rgf.id_fecha_inicial,
			rgf.id_fecha_final
'
--print @sql
execute (@sql)