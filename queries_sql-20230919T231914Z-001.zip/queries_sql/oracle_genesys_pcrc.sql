--Listo todos los pcrc vigentes en el nuevo modelo
SELECT *
FROM CONTACT.INFOMART_GROUP_ 
where group_name in
(
'VQ_Re_Informacion',
'VQ_Re_FacturacionPagos',
'VQ_Re_General',
'VQ_Re_Ventas_Voz',
'VQ_Re_Ventas_Datos',
'VQ_Re_Postventa',
'VQ_Re_Tecnico_Voz',
'VQ_Re_Tecnico_Datos',
'VQ_Re_Reclamos',
'VQ_Re_Retencion_Datos',
'VQ_Re_Retencion_Voz',
'VQ_COMERCIAL_TOP',
'VQ_Comercial_Top',
'VQ_COMERCIAL_PERSONALIZADO',
'VQ_COMERCIAL_NO_PERSONALIZADO',
'VQ_CATE_TOP',
'VQ_CATE_MULTISKILL',
'VQ_CATE_MONOSKILL',
'VQ_Py_Tecnico_Datos',
'VQ_Py_Tecnico_Voz'
)
and GROUP_TYPE_CODE='QUEUE'
and GMT_END_TIME > current_date
order by GMT_START_TIME;