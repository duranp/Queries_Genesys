SELECT * 
from Information_Schema.Tables
where TABLE_TYPE='view'
order by TABLE_SCHEMA