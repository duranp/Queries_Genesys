USE [gis]
GO

/****** Object:  StoredProcedure [dbo].[s_tablero_servicio]    Script Date: 08/28/2014 17:18:32 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO



--CREATE procedure [dbo].[s_tablero_servicio_1]
--as

declare @fecha_actualizacion as datetime

set @fecha_actualizacion = ( select MAX(fecha_bajada) from dbo.bpc_estadistica_gis )

SELECT 
	--@fecha_actualizacion as fecha_estadistica
	--,
	case pcrc 
		when 'Primera L�nea'  then 0
		when 'Segunda L�nea'  then 0
		when 'Tecnico Comercial'  then 0
		when 'Total Residenciales'  then 0
		else id_pcrc
	end as id_pcrc
	,
	 orden as orden
	--[programa] 
	,[pcrc] as PCRC
	,round( [aban_15] , 2, 0)  as AB
	--,case [vol_15]
	--	when 0 then
	--		0
	--	else 
	--		round(100 * [cola] / [vol_15], 2, 0)
	--end as [por_cola]
	,[cola]COLA
	,round( [ocio_15], 2, 0) as AVAIL
	,round( [sl_15], 2, 0) as SL
	,round( [vol_15], 2, 0) as ENT
	, prono_15 as PRONO
	,round( [tmo], 2, 0) as TMO
	,[fte] as FTE
	,[ocio] as AVAIL -- el que falta
	,[login] as [LOGIN]
	,[nr1] as NRT_1
	,[nr2] as NRT_2
	,round([aban_acum], 2, 0) as AB
	,[vol_acum] as ENT
	,round( [ocio_acum], 2, 0) as AVAIL
	,round( [sl_acum], 2, 0) as SL
	--, null as valorRp
	, prono_acum as PRONO
	,case vol_acum
	when 0 then
		0
	else 
		round( 1 - ( prono_acum / vol_acum), 2, 0 ) * 100
	end as DESVIO 
	--, round( 1 - ( prono_acum / vol_acum), 2, 0 ) as desvio_acum


  FROM [gis].[dbo].[estado_servicio]
  order by orden
GO



