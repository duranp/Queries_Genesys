--SELECT g.GROUP_NAME,r.RESOURCE_NAME
--FROM CONTACT.INFOMART8_RESOURCE_GROUP_FACT rg join
--CONTACT.INFOMART8_GROUP_ g on rg.group_key = g.GROUP_KEY join
--CONTACT.INFOMART8_RESOURCE_ r on rg.RESOURCE_KEY = r.RESOURCE_KEY
--where g.GROUP_NAME like '%VQ_Primera%';

SELECT g.GROUP_NAME PCRC,r.RESOURCE_NAME VQ_DETALLE,aux.RESOURCE_NAME VQ_1_LINEA
FROM CONTACT.INFOMART8_RESOURCE_GROUP_FACT rg join
CONTACT.INFOMART8_GROUP_ g on rg.group_key = g.GROUP_KEY join
CONTACT.INFOMART8_RESOURCE_ r on rg.RESOURCE_KEY = r.RESOURCE_KEY
left join (
                SELECT g.GROUP_NAME,r.RESOURCE_NAME
                FROM CONTACT.INFOMART8_RESOURCE_GROUP_FACT rg join
                CONTACT.INFOMART8_GROUP_ g on rg.group_key = g.GROUP_KEY join
                CONTACT.INFOMART8_RESOURCE_ r on rg.RESOURCE_KEY = r.RESOURCE_KEY
                where g.GROUP_NAME like '%VQ_Primera%'

)aux on r.resource_name =aux.Resource_name
where g.GROUP_NAME in
(
'VQ_Re_Informacion',
'VQ_Re_FacturacionPagos',
'VQ_Re_General',
'VQ_Re_Ventas_Voz',
'VQ_Re_Ventas_Datos',
'VQ_Re_Postventa',
'VQ_Re_Tecnico_Voz',
'VQ_Re_Tecnico_Datos'
--,
--'VQ_Re_Reclamos',
--'VQ_Re_Retencion_Datos',
--'VQ_Re_Retencion_Voz',
--'VQ_COMERCIAL_TOP',
--'VQ_Comercial_Top',
--'VQ_COMERCIAL_PERSONALIZADO',
--'VQ_COMERCIAL_NO_PERSONALIZADO',
--'VQ_CATE_TOP',
--'VQ_CATE_MULTISKILL',
--'VQ_CATE_MONOSKILL',
--'VQ_Py_Tecnico_Datos',
--'VQ_Py_Tecnico_Voz'
) and aux.RESOURCE_NAME is null
order by  g.GROUP_NAME,r.RESOURCE_NAME;
