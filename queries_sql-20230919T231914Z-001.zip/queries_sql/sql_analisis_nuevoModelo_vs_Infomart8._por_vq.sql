--**********************************************************************************
-- Vista de of, ab y at por pcrc ccon el origen de datos GENESYS (Nuevo modelo)
--**********************************************************************************


USE [genesys]
GO


select i.id_fecha_inicial,
			--ms.id_intervalo_inicial,
			ms.resource_key,
			r.resource_alias,
			gqp.group_name,
			count_big(*) as[total_calls_entered],
			sum(reportes.fn_abandonada(td.technical_result_code, td.result_reason_code)) as [total_calls_abandoned],
count_big(*) - sum(reportes.fn_abandonada(td.technical_result_code, td.result_reason_code)) as[total_calls_answered],
			count_big(*) as [cantidad_registros]
into ##temp_prueba -- carga la temp para comparar las otrecidas con los datos del nuevo modelo
from dbo.interaction_fact i
join dbo.mediation_segment_fact ms on ms.interaction_id = i.interaction_id
join dbo.technical_descriptor td on td.technical_descriptor_key = ms.technical_descriptor_key
join reportes.queues_pcrc qp on qp.resource_key=ms.resource_key
join reportes.groups_queues_pcrc gqp on gqp.group_key = qp.group_key
join dbo.resources r on ms.resource_key=r.resource_key
where td.technical_result_code <> 'CLEARED'
and ms.short_abandoned_flag = 0
and i.id_fecha_inicial ='20140901'
group by i.id_fecha_inicial,
			--ms.id_intervalo_inicial,
			ms.resource_key,
			r.resource_alias,
			gqp.group_name
order by i.id_fecha_inicial,
			--ms.id_intervalo_inicial,
			gqp.group_name,   
			ms.resource_key
GO


--**********************************************************************************
-- Vista de of, ab y at por pcrc ccon el origen de datos AG2_QUEUE_SUBHR
--**********************************************************************************

use etl_genesys
--select * from ##temp_prueba


select	(DATEPART(yyyy, CAL_DATE) * 10000 + DATEPART(mm, CAL_DATE)*100 + DATEPART(dd, CAL_DATE)) FECHA,
		d.GROUP_NAME PCRC,
		d.GROUP_KEY,
		e.RESOURCE_alias,
		f.resource_alias,
		c.RESOURCE_KEY,
		(f.[total_calls_entered])OFRECIDAS_Genesys,
		sum(cast(ENTERED as int)) OFRECIDAS_infomart8,
		
		sum(cast(ENTERED as int)) - sum(cast(ACCEPTED_AGENT as int)) - sum(cast(ROUTED_OTHER as int)) ADANDONADAS,
		sum(cast(ACCEPTED_AGENT as int)) + sum(cast(ROUTED_OTHER as int)) ATENDIDAS,
		case when (cast(sum(cast(ENTERED as int)) as float))>0 then cast(100.0 * (1.00 	- cast((sum(cast(ACCEPTED_AGENT as int)) + sum(cast(ROUTED_OTHER as int))) as float) / cast(sum(cast(ENTERED as int)) as float)) as decimal(10, 2))else 0 end TA
		
from		dbo.AG2_QUEUE_SUBHR a
join		dbo.INFOMART8_DATE_TIME b on a.DATE_TIME_KEY = b.DATE_TIME_KEY
join		dbo.INFOMART8_resource_GROUP_fact c on a.resource_key=c.resource_KEY
join		dbo.INFOMART8_GROUP_ d on c.group_key =d.group_key
join		dbo.INFOMART8_RESOURCE_ e on a.resource_key =e.resource_key
left join ##temp_prueba f on f.resource_alias = e.RESOURCE_alias

--left join	dbo.INFOMART8_GROUP_ g on a.GROUP_COMBINATION_KEY = g.GROUP_KEY

where (DATEPART(yyyy, CAL_DATE) * 10000 + DATEPART(mm, CAL_DATE)*100 + DATEPART(dd, CAL_DATE)) in( '20140901')
and d.group_name in
(
'VQ_Re_Informacion',
'VQ_Re_FacturacionPagos',
'VQ_Re_General',
'VQ_Re_Ventas_Voz',
'VQ_Re_Ventas_Datos',
'VQ_Re_Postventa',
'VQ_Re_Tecnico_Voz',
'VQ_Re_Tecnico_Datos',
'VQ_Re_Reclamos',
'VQ_Re_Retencion_Datos',
'VQ_Re_Retencion_Voz',
'VQ_COMERCIAL_TOP',
'VQ_Comercial_Top',
'VQ_COMERCIAL_PERSONALIZADO',
'VQ_COMERCIAL_NO_PERSONALIZADO',
'VQ_CATE_TOP',
'VQ_CATE_MULTISKILL',
'VQ_CATE_MONOSKILL',
'VQ_Py_Tecnico_Datos',
'VQ_Py_Tecnico_Voz'
)
group by (DATEPART(yyyy, CAL_DATE) * 10000 + DATEPART(mm, CAL_DATE)*100 + DATEPART(dd, CAL_DATE)), 
		d.GROUP_KEY,
		d.GROUP_NAME, 
		c.RESOURCE_KEY,
		e.RESOURCE_ALIAS,
		f.resource_alias,
		(f.[total_calls_entered])
		-- with rollup 
order by (DATEPART(yyyy, CAL_DATE) * 10000 + DATEPART(mm, CAL_DATE)*100 + DATEPART(dd, CAL_DATE)),
		d.GROUP_NAME ,
		e.RESOURCE_alias
		
		
drop table ##temp_prueba