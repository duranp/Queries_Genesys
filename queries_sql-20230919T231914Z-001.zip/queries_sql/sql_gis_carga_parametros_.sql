VAG_Re_LEC
VAG_Re_VentasIN
use gis

select * from dbo.objeto
where objeto_nombre like '%vq%'
order by 1

select * from dbo.objeto
where objeto_nombre like '%vag_re%'
order by 2

----##################################################
----inserto los pcrc de llamadas en la tabla objetos
----##################################################

--insert into dbo.objeto (objeto_nombre)
--values('VAG_Re_LEC')

--insert into dbo.objeto (objeto_nombre)
--values('VAG_Re_VentasIN')

----################################################################
----inserto los pcrc de llamadas en la tabla estadistica_suscribir
----################################################################
--begin tran

--set IDENTITY_INSERT dbo.estadistica_suscribir OFF

--insert into dbo.estadistica_suscribir
--select id_tipo_estadistica,id_filtro,id_perfil_tiempo,id_perfil,id_rango_tiempo,275 id_objeto,id_tipo_objeto,habilitado 
--from dbo.estadistica_suscribir 
--where id_objeto = 65
--union
--select id_tipo_estadistica,id_filtro,id_perfil_tiempo,id_perfil,id_rango_tiempo,276 id_objeto,id_tipo_objeto,habilitado 
--from dbo.estadistica_suscribir 
--where id_objeto = 65

--set IDENTITY_INSERT dbo.estadistica_suscribir on

--commit tran
--rollback tran

----################################################################
----inserto los pcrc de llamadas en la tabla pcrc
----################################################################
select * from dbo.pcrc

--insert into dbo.pcrc (pcrc)
--values ('VentasIN')

--insert into dbo.pcrc (pcrc)
--values ('VQ_Re_LEC')

select * from dbo.bpc_estadistica_gis where objeto like '%lec%'
select * from dbo.estado_servicio

----################################################################
----inserto los pcrc de llamadas en la tabla dbo.relacion_gis_copc
----################################################################

select * from dbo.relacion_gis_copc
--insert into dbo.relacion_gis_copc
--values(1,17,'',269,16)
--insert into dbo.relacion_gis_copc
--values(1,18,'',271,17)

--update dbo.relacion_gis_copc
--set id_objeto_vag= 276
--where id_pcrc= 17

--update dbo.relacion_gis_copc
--set id_objeto_vag= 275
--where id_pcrc= 18

