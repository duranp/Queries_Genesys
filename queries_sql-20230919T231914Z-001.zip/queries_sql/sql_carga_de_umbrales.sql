/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [id_umbral_tipo]
      ,[group_key]
      ,[id_fecha_desde]
      ,[id_fecha_hasta]
      ,[umbral_desde]
      ,[umbral_hasta]
  FROM [genesys].[dbo].[umbrales_groups_fact]
  
--groups  
begin tran
insert into [genesys].[dbo].[umbrales_groups_fact]
select	distinct
		'2' id_umbral_tipo,
		(group_key) groups_faltante,
		'20000101'id_fecha_desde,	
		'20501212'id_fecha_hasta,
		'0'umbral_desde,
		'30'umbral_hasta
from	reportes.queues_pcrc
where	group_key not in (	SELECT	distinct(group_key)
							FROM	[genesys].[dbo].[umbrales_groups_fact])
commit tran							
rollback tran

--resources
begin tran
insert into [genesys].[dbo].[umbrales_resources_fact]
select	distinct
		'2' id_umbral_tipo,
		(resource_key) resources_faltantes,
		'20110101'id_fecha_desde,	
		'20501231'id_fecha_hasta,
		'0'umbral_desde,
		'30'umbral_hasta
from	reportes.queues_pcrc
where	resource_key not in (	SELECT	distinct(resource_key)
							FROM	[genesys].[dbo].[umbrales_resources_fact])
commit tran							
rollback tran


select * from dbo.resources
where resource_key in
('174962',
'174501',
'174496',
'174502',
'174497',
'174961')