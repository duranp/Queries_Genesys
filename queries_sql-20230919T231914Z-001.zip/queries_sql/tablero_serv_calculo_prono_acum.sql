use [flash_status]
declare @intervalo_ant as int	
declare @intervalo_act as int
declare @ahora as datetime
declare @minuto as int


set @ahora=getdate()
set @minuto=DATEPART(MI,@ahora)
set @intervalo_ant =	'30'+CONVERT(nvarchar(2), dateadd(MINUTE,(-30),@ahora), 108)+right(CONVERT(nvarchar(5), dateadd(MINUTE,(-30),@ahora), 108),2) 
set @intervalo_act =	'30'+CONVERT(nvarchar(2), dateadd(MINUTE,(0),@ahora), 108)+right(CONVERT(nvarchar(5), dateadd(MINUTE,(0),@ahora), 108),2) 

if(@minuto<30)
begin 
	set @minuto=@minuto 
end
else 
	set @minuto=@minuto-30 

select case when (GROUPING (b.Grupo)=1) then 'Total Residenciales' else ISNULL(b.Grupo, 'UNKNOWN') end GRUPOS,isnull(isnull(b.servicio,b.Grupo),'Total Residenciales')PCRC,SUM(b.prono_acum)PRONO_ACUM
from(
select	case when servicio in (	'Informacion'
								,'Fact y Pagos'
								,'General'
								,'Ventas Voz'
								,'Ventas Datos'
								,'Postventa'
								,'Tecnico Voz'
								,'Tecnico Datos') then 'Primera L�nea' else 'Segunda L�nea' end Grupo,
		--case when (grouping (servicio)=1) then 'TOTAL RESIDENCIALES'ELSE ISNULL(servicio, 'UNKNOWN')end as pcrc,
		servicio,
		SUM(prono_acum)prono_acum
from(
	SELECT	servicio, 
			SUM(ofrecidas_pronosticadas) AS prono_acum
	FROM	metricas_intervalos_servicios_pronosticos f
			join intervalos i on i.id_intervalo = f.id_intervalo
	WHERE	id_fecha = DATEPART( YYYY, GETDATE() ) * 10000 + DATEPART( MM, GETDATE() ) * 100 + DATEPART( DD, GETDATE() )
			AND i.id_intervalo <= @intervalo_ant
	GROUP BY i.id_intervalo,servicio
	union

	SELECT	servicio, 
			SUM(ofrecidas_pronosticadas)/30*@minuto AS prono_acum
	FROM	metricas_intervalos_servicios_pronosticos f
			join intervalos i on i.id_intervalo = f.id_intervalo
	WHERE	id_fecha = DATEPART( YYYY, GETDATE() ) * 10000 + DATEPART( MM, GETDATE() ) * 100 + DATEPART( DD, GETDATE() )
			AND i.id_intervalo > @intervalo_ant AND i.id_intervalo <= @intervalo_act
	GROUP BY servicio
)a
group by case when servicio in ('Informacion','Fact y Pagos','General','Ventas Voz','Ventas Datos','Postventa','Tecnico Voz','Tecnico Datos') then 'Primera L�nea' else 'Segunda L�nea' end ,servicio 
--order by case when servicio in ('Informacion','Fact y Pagos','General','Ventas Voz','Ventas Datos','Postventa','Tecnico Voz','Tecnico Datos') then 'Primera L�nea' else 'Segunda L�nea' end ,servicio
)b	
group by Grupo ,b.servicio with rollup	