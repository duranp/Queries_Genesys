select top 100 *
from 
etl_genesys.dbo.interaction_fact a 
inner join etl_genesys.dbo.interaction_resource_fact b 
		on a.interaction_id = b.interaction_id 
inner join etl_genesys.dbo.[RESOURCE] c
		on b.resource_key=c.resource_key
where RESOURCE_TYPE_CODE='agent'		
inner join etl_genesys.dbo.resource_group_fact d
		on c.resource_key=d.resource_key
inner join etl_genesys.dbo.[GROUP] e
		on d.group_key=e.GROUP_CFG_DBID
where a.STD_ENTERPRISE_START_TIME>='20140721' and a.STD_ENTERPRISE_START_TIME<'20140722'