USE [genesys]
GO

--/****** Object:  View [reportes].[metricas_agents_queues]    Script Date: 07/25/2014 10:13:19 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO




--CREATE view [reportes].[metricas_agents_queues]

--as

select	i.id_fecha_inicial,
		ms.id_intervalo_inicial,
		ir.resource_key,
		ir.mediation_resource_key,
		r.resource_name,
		sum(case when reportes.fn_abandonada(td.technical_result_code, td.result_reason_code) = 0 then 1 else 0 end) as [total_calls_answered],
		count_big(*) as [cantidad_registros]
		
from dbo.interaction_fact i
join dbo.mediation_segment_fact ms on ms.interaction_id = i.interaction_id
join dbo.technical_descriptor td on td.technical_descriptor_key = ms.technical_descriptor_key
join dbo.interaction_resource_fact ir on i.interaction_id = ir.interaction_id
join dbo.resources r on ir.resource_key = r.resource_key 

where td.technical_result_code <> 'CLEARED'
and i.id_fecha_inicial in('20140710')
group by i.id_fecha_inicial,
		ms.id_intervalo_inicial,
		ir.resource_key,
		ir.mediation_resource_key,
		r.resource_name


GO


