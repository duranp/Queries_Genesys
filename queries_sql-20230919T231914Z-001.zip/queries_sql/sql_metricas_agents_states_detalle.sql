USE [genesys]
GO
/****** Object:  View [vi].[metricas_agents_state_detalle]    Script Date: 10/02/2014 16:55:48 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
--create view [vi].[metricas_agents_state_detalle] with schemabinding
--as

select 
		f.id_fecha,
		i.id_intervalo,
		sm.resource_key,
		sm.resource_state_key,
		sum(isnull(
			case
				--si el estado se encuentra dentro de un intervalo, directamente van los segundos de ese estado
				when sm.id_intervalo_inicial = sm.id_intervalo_final then sm.total_duration
				
				--(dentro de un mismo dia) si el estado viene de un intervalo anterior y 
				--a su vez contin�a en un intervalo siguiente, se suma los segundos seguidos (30 minutos cada intervalo)
				when	(i.id_intervalo > sm.id_intervalo_inicial and i.id_intervalo < sm.id_intervalo_final)and
						(f.id_fecha = sm.id_fecha_inicial and f.id_fecha = sm.id_fecha_final)		 
				then i.duracion_minutos * 60 --segundos
				-- (+ de un dia) pone 1800 a todos los intervalos del primer dia
				when	(f.id_fecha = sm.id_fecha_inicial and f.id_fecha < sm.id_fecha_final)and
						(i.id_intervalo > sm.id_intervalo_inicial ) 
				then i.duracion_minutos * 60 --segundos
				-- (+ de un dia) pone 1800 a todos los intervalos que no son ni del primer ni del ultimo dia				
				when	(f.id_fecha > sm.id_fecha_inicial and f.id_fecha < sm.id_fecha_final)
				then i.duracion_minutos * 60 --segundos
				-- (+ de un dia) pone 1800 a todos los intervalos del primer dia				
				when	(f.id_fecha > sm.id_fecha_inicial and f.id_fecha = sm.id_fecha_final)and
						(i.id_intervalo < sm.id_intervalo_final ) 
				then i.duracion_minutos * 60 --segundos
				
				--calcula los segundos finales del evento cuando excede a un intervalo
				when i.id_intervalo = sm.id_intervalo_final then datediff(ss, i.hora_desde, cast(sm.std_enterprise_end_time as time))

				--calcula los segundos iniciales del evento cuando excede a un intervalo
				when i.id_intervalo = sm.id_intervalo_inicial then 1800- datediff(ss, i.hora_desde, cast(sm.std_enterprise_start_time as time))
									
				--calcula los segundos iniciales del evento cuando excede a un intervalo
				--else datediff(ss, cast(sm.std_enterprise_start_time as time), i.hora_hasta)+1
			end, 0)
		) as total_duration,
		COUNT_BIG(*) cantidad_registros
	
from dbo.fechas f
join dbo.intervalos i on 1=1 and i.duracion_minutos = 30
join dbo.sm_res_state_fact sm on 
					f.id_fecha = sm.id_fecha_inicial and i.id_intervalo >= sm.id_intervalo_inicial or
					f.id_fecha = sm.id_fecha_final and i.id_intervalo <= sm.id_intervalo_final 
					
			

where 
sm_res_state_fact_key = 547909598

			
group by
		f.id_fecha,
		i.id_intervalo,
		sm.resource_key,
		sm.resource_state_key
order by 	
		f.id_fecha,	
		i.id_intervalo		



GO

select *
from sm_res_state_fact
where 
sm_res_state_fact_key=547909598

