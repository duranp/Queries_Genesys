use [flash_status]

declare @ahora as datetime
declare @cod_fecha as int

set @ahora=getdate()
--set @ahora='2014-08-22 10:00:48.440'
--set @ahora='2014-08-22 10:01:48.440'
--set @ahora='2014-08-22 10:14:48.440'
--set @ahora='2014-08-22 10:15:48.440'
--set @ahora='2014-08-22 10:16:48.440'
--set @ahora='2014-08-22 10:29:48.440'
--set @ahora='2014-08-22 10:30:48.440'
--set @ahora='2014-08-22 10:31:48.440'
--set @ahora='2014-08-22 10:44:48.440'
--set @ahora='2014-08-22 10:45:48.440'
--set @ahora='2014-08-22 10:46:48.440'
--set @ahora='2014-08-22 10:59:48.440'
set @cod_fecha=DATEPART(yyyy,getdate())*10000+DATEPART(MONTH,getdate())*100+DATEPART(DD,getdate())
select case when (GROUPING (b.Grupo)=1) then 'Total Residenciales' else ISNULL(b.Grupo, 'UNKNOWN') end GRUPOS,isnull(isnull(b.servicio,b.Grupo),'Total Residenciales')PCRC,SUM(b.prono_15)PRONO_15
from(
select a.Grupo,a.servicio,sum(a.prono_15)prono_15 

from(
	SELECT	case when servicio in (	'Informacion'
								,'Fact y Pagos'
								,'General'
								,'Ventas Voz'
								,'Ventas Datos'
								,'Postventa'
								,'Tecnico Voz'
								,'Tecnico Datos') then 'Primera L�nea' else 'Segunda L�nea' end Grupo
			,servicio
			,(ofrecidas_pronosticadas/30)*
			case when right(CONVERT(nvarchar(5), @ahora, 108),2) <30 then
				case when right(CONVERT(nvarchar(5), @ahora, 108),2)<=15 then
					right(CONVERT(nvarchar(5), @ahora, 108),2)
				else
					15
				end
			else
			case when right(CONVERT(nvarchar(5), @ahora, 108),2)-30<=15 then
					right(CONVERT(nvarchar(5), @ahora, 108),2)-30
				else
					15
				end 
			end prono_15
				
							
	from	dbo.metricas_intervalos_servicios_pronosticos
	where	id_fecha ='20140822'
			and 
			(id_intervalo between 
			'30'+CONVERT(nvarchar(2), dateadd(MINUTE,(-29),@ahora), 108)+right(CONVERT(nvarchar(5), dateadd(MINUTE,(-29),@ahora), 108),2) 
			and 
			'30'+CONVERT(nvarchar(2), @ahora, 108)+right(CONVERT(nvarchar(5), @ahora, 108),2)
			)
			
	union		

	SELECT	case when servicio in (	'Informacion'
								,'Fact y Pagos'
								,'General'
								,'Ventas Voz'
								,'Ventas Datos'
								,'Postventa'
								,'Tecnico Voz'
								,'Tecnico Datos') then 'Primera L�nea' else 'Segunda L�nea' end Grupo
			,servicio
			,(ofrecidas_pronosticadas/30)*
			case when right(CONVERT(nvarchar(5), @ahora, 108),2) <30 then
				case when right(CONVERT(nvarchar(5), @ahora, 108),2)<=15 then
					15-right(CONVERT(nvarchar(5), @ahora, 108),2)
				else
					15-15
				end
			else
				case when right(CONVERT(nvarchar(5), @ahora, 108),2)-30<=15 then
					15-(right(CONVERT(nvarchar(5), @ahora, 108),2)-30)
				else
					15-15
				end 
			end prono_15

					
	from	dbo.metricas_intervalos_servicios_pronosticos
	where	id_fecha ='20140822'
			and 
			( 
			id_intervalo between 
			'30'+CONVERT(nvarchar(2), dateadd(MINUTE,(-59),@ahora), 108)+right(CONVERT(nvarchar(5), dateadd(MINUTE,(-59),@ahora), 108),2) 
			and 
			'30'+CONVERT(nvarchar(2), dateadd(MINUTE,(-30),@ahora), 108)+right(CONVERT(nvarchar(5), dateadd(MINUTE,(-30),@ahora), 108),2) 
			)

	) a
group by a.Grupo,a.servicio
)b
group by b.Grupo,b.servicio with rollup
---order by b.Grupo,b.servicio