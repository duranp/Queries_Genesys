USE [genesys]
GO

/****** Object:  View [reportes].[groups_queues_programas]    Script Date: 07/24/2014 17:45:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE view [reportes].[groups_queues_programas]

as

select g.*,
		case
			when g.group_name = 'VQ_Re_Tecnico_Comercial' then 'Tecnico Comercial'
			when g.group_name = 'VQ_Re_Primera_Linea' then 'Primera Linea'
			when g.group_name = 'VQ_Re_Segunda_Linea' then 'Segunda Linea'
			when g.group_name = 'VQ_Re_Total' then 'Total Residencial'		
		else 'Sin group queue'
		end as alias
from infomart.groups g
where 
g.group_type_code = 'QUEUE'
and (g.group_name in 
		(
		'VQ_Re_Tecnico_Comercial',
		'VQ_Re_Primera_Linea',
		'VQ_Re_Segunda_Linea',
		'VQ_Re_Total'
		)
	)









GO


