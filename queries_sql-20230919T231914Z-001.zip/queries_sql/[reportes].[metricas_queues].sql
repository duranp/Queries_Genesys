USE [genesys]
GO

--/****** Object:  View [reportes].[metricas_queues]    Script Date: 07/31/2014 15:28:16 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO



--CREATE view [reportes].[metricas_queues]
--as

select i.id_fecha_inicial,
		ms.id_intervalo_inicial,
		--ms.resource_key,
		--r.resource_name,
		gqp.alias,
		count_big(*) as[total_calls_entered],
		sum(reportes.fn_abandonada(td.technical_result_code, td.result_reason_code)) as [total_calls_abandoned],
		count_big(*) - sum(reportes.fn_abandonada(td.technical_result_code, td.result_reason_code)) as[total_calls_answered],
		count_big(*) as [cantidad_registros]
from dbo.interaction_fact i
join dbo.mediation_segment_fact ms on ms.interaction_id = i.interaction_id
join dbo.resources r on r.resource_key=ms.resource_key 
INNER JOIN resource_group_fact rgf ON r.resource_key = rgf.resource_key 
inner join reportes.groups_queues_pcrc gqp on gqp.group_key = rgf.group_key
join dbo.technical_descriptor td on td.technical_descriptor_key = ms.technical_descriptor_key
where td.technical_result_code <> 'CLEARED'
and ms.short_abandoned_flag = 0
and i.id_fecha_inicial='20140701'
group by i.id_fecha_inicial,
		ms.id_intervalo_inicial,
		--ms.resource_key,
		--r.resource_name,	
		gqp.alias


GO


