--servidor: ssnews01
use bd_controles

--Paso1
--Para saber el job_id 
select distinct server, name, job_id
from control_jobs_ejecuciones
where server in ('SSNEWS01','SSNEWS02')
  and name like '%gis%'
order by 1 DESC, 2


--Paso2 hay que modificar el job_id
declare @job_id varchar(255) ='E258EAB2-0CBC-48BD-9AE4-BBD255E3C5AA'

select  name, run_date, run_time, step_id
,step_name
                ,case when run_status=1 then 'ok'
                               when run_status=0 then 'Fallo'
                               when run_status=3 then 'cancelado'
                               else 'Otros'
                               end salida--, run_duration
,case when len(CAST(run_duration as CHAR(10)))=1 then '00:00:0'+substring(CAST(run_duration as CHAR(10)),1, 2)
                when len(CAST(run_duration as CHAR(10)))=2 then '00:00:'+substring(CAST(run_duration as CHAR(10)),1, 2)
                when len(CAST(run_duration as CHAR(10)))=3 then '00:0'+substring(CAST(run_duration as CHAR(10)),1, 1)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)
                when len(CAST(run_duration as CHAR(10)))=4 then '00:'+substring(CAST(run_duration as CHAR(10)),1,2)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)
                when len(CAST(run_duration as CHAR(10)))=5 then '0'+substring(CAST(run_duration as CHAR(10)),1,1)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)+':'+ substring(CAST(run_duration as CHAR(10)),4, 2)
                when len(CAST(run_duration as CHAR(10)))=6 then substring(CAST(run_duration as CHAR(10)),1,2)+':'+ substring(CAST(run_duration as CHAR(10)),3, 2)+':'+ substring(CAST(run_duration as CHAR(10)),5, 2)
                end duracion
                --, case when run_duration>500 then 's' else '' end 'demoro?'
from control_jobs_ejecuciones
where job_id= @job_id
                and step_id=0
                --and run_date>='20140520'
                --and LEN(run_time)=6
                --and run_duration>600
group by name, run_date, run_time,case when len(CAST(run_duration as CHAR(10)))=1 then '00:00:0'+substring(CAST(run_duration as CHAR(10)),1, 2)
                when len(CAST(run_duration as CHAR(10)))=2 then '00:00:'+substring(CAST(run_duration as CHAR(10)),1, 2)
                when len(CAST(run_duration as CHAR(10)))=3 then '00:0'+substring(CAST(run_duration as CHAR(10)),1, 1)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)
                when len(CAST(run_duration as CHAR(10)))=4 then '00:'+substring(CAST(run_duration as CHAR(10)),1,2)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)
                when len(CAST(run_duration as CHAR(10)))=5 then '0'+substring(CAST(run_duration as CHAR(10)),1,1)+':'+ substring(CAST(run_duration as CHAR(10)),2, 2)+':'+ substring(CAST(run_duration as CHAR(10)),4, 2)
                when len(CAST(run_duration as CHAR(10)))=6 then substring(CAST(run_duration as CHAR(10)),1,2)+':'+ substring(CAST(run_duration as CHAR(10)),3, 2)+':'+ substring(CAST(run_duration as CHAR(10)),5, 2)
                end
                ,instance_id
                ,run_status
                ,step_id
                ,step_name
                ,run_duration
order by run_date , cast(run_time as int), step_id, instance_id asc
