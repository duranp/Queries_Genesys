
UPDATE ROSTER_NEW SET [ENVIAR QUEJA] = 1

INSERT INTO ROSTER_1L
SELECT *,NULL FROM ROSTER_NEW WHERE ASISTENTE NOT IN (SELECT ASISTENTE FROM ROSTER_1L)
update r
set pcrc = c.pcrc
from roster_1l r inner join camapa_pcrc c on r.site = c.site and r.campa�a = c.campa�a

--UPDATE ROSTER_1L SET [ENVIAR QUEJA] = 1

SELECT * FROM ROSTER_1L WHERE PCRC IS NULL
sp_helptext sp_avisos_chk


alter procedure sp_avisos_chk    
as    
select dbo.f(max(date_Time)) fecha from genesys..skill_his     
HAVING     
DATEPART(HOUR,dbo.f(max(date_Time))) IN(13,20) AND DBO.RH(dbo.f(max(date_Time))) > (SELECT DBO.RH(MAX(TIMESTAMP)) FROM AVISOS)    
  

 SELECT     distinct segmento
FROM         PSEUDOSKILL
WHERE     (atencion = N'com')
ORDER BY segmento

update pseudoskill set carterizado = 0 where atencion = 'com' and segmento in ('Alto Riesgo','Alto Valor','Alto Valor Pers','Competencia','MASIVO','PROD ESP','COBROS','SUCURSAL ON LINE','Oficinas_Comerciales')

update pseudoskill set carterizado = 1 where atencion = 'com' and segmento = 'top'

sp_helptext sp_eficiencia_dia

alter procedure sp_eficiencia_grp     (@atencion varchar(20), @mod int = null)              
as                  
select       
(select dbo.f(max(date_time)) from skill_his s inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and skill <> 'fh' and atencion = @atencion where dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(@mod,0) as datetime))  as fc_max,      
(select COUNT(distinct date_time) from skill_his s inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and skill <> 'fh' and atencion = @atencion where dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(@mod,0) as datetime)) as intervalos,                  
carterizado,  sum(abandoned)+sum(answered) ofr, round(sum(abandoned)/(sum(abandoned)+sum(answered))*100.0,2,2) TA             
from skill_his s                   
 inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(@mod,0) as datetime) and skill <> 'fh' and atencion = @atencion              
group by carterizado having sum(entered)>0    
order by sum(abandoned)+sum(answered) desc       
sp_eficiencia_grp 'com'

select p.carterizado,       
(select dbo.f(max(date_time)) from skill_his s inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and skill <> 'fh' and atencion = 'com' where dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(0,0) as datetime))  as fc_max,      
(select COUNT(distinct date_time) from skill_his s inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and skill <> 'fh' and atencion = 'com' where dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(0,0) as datetime)) as intervalos,                  
 sum(abandoned)+sum(answered) ofr, round(sum(abandoned)/(sum(abandoned)+sum(answered))*100.0,2,2) TA             
from skill_his s                   
 inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill                  
 and dbo.dmy(dbo.f(date_time)) = dbo.dmy(getdate())+cast(isnull(0,0) as datetime) and skill <> 'fh' and atencion = 'com'              
group by  p.carterizado 
having sum(entered)>0    
order by p.carterizado desc     
  


  
alter procedure sp_eficiencia_dia_grp (@atencion varchar(4), @fecha smalldatetime)          
as          
select case when carterizado =1 then 'Carterizado' when carterizado = 0 then 'No Carterizado' when grouping(carterizado) = 1 then 'TOTAL ' + @atencion else 'otros' end Cart,           
sum(abandoned)+sum(answered) ofr, sum(abandoned) AB, SUM(ANSWERED) AT,          
CAST(sum(abandoned)/(sum(abandoned)+sum(answered))*100.0 AS DECIMAL(6,2)) TA,     
case when SUM(CASE WHEN SL = 20 THEN ANS_20 ELSE ANS_40 END) = 0 then 100.00 else CAST(SUM(CASE WHEN SL = 20 THEN ANS_20 ELSE ANS_40 END)/SUM(ANSWERED)*100 AS DECIMAL(6,2)) end SL               
from skill_day_SL s                     
inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill               
AND ATENCION = @atencion and dbo.f(date_time) = @fecha          
group by carterizado   with rollup
order by carterizado DESC 

sp_eficiencia_dia_grp 'com', '02/06/2011'

grant exec on sp_eficiencia_dia_grp to web

select * from pseudoskill where segmento = 'Isla_Reclamos'

select * from pseudoskill where atencion = 'com' and carterizado is null

update pseudoskill set segmento = 'U N M' where segmento = 'Fundacion'
Productos_Nuevos


update pseudoskill set carterizado = 0 where atencion = 'com' and segmento in ('PDTI_Comercial','Productos_Nuevos')

TRANSF
TRANSF'


select dbo.f(date_time), sum(answered) from agent_his group by date_time
order by date_Time desc

select dbo.f(date_time), sum(answered) from skill_his group by date_time
ord'er by date_Time desc

sp_helptext sp_get_llamadas_proy

  
ALTER PROCEDURE SP_GET_LLAMADAS_PROY (@DATE SMALLDATETIME, @SEGMENTO VARCHAR(40))    
AS    
select intervalo, ofr, at, ab, rec_proy, cast((ofr/rec_proy)-1 as numeric(6,2)) gap, CAST(cast(ab/ofr*100 as numeric(6,2)) AS VARCHAR(5))+'%' TA from    
(    
select dbo.f(date_time)Intervalo, sum(entered)ofr, sum(answered)at, sum(abandoned)ab    
from skill_his s                     
inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill          
where atencion = @SEGMENTO and segmento <> CASE WHEN @SEGMENTO = 'COM' THEN 'top' ELSE '' END    
and dbo.dmy(dbo.f(date_time)) = dbo.dmy(@DATE)    
group by dbo.f(date_time)    
)x     
 left join WFM_LLAMADAS e on intervalo = e.date and e.segmento = CASE WHEN @SEGMENTO = 'COM' THEN 'NEG_Total_No_Carterizado_+_AV' ELSE '' END    
WHERE OFR > 0    
order by intervalo 

create table roster_cm ([name] varchar(15), firstName varchar(30), lastName  varchar(30), EmployeeID int, vag varchar(30))

alter procedure sp_ins_roster (@name varchar(15), @firstName varchar(30), @lastName  varchar(30), @EmployeeID varchar(20), @vag varchar(30))
as
insert into bcp_roster_cm values (@name, @firstname, @lastname, @employeeid, @vag)

grant exec on sp_ins_roster to web

select * from bcp_roster_cm

select * into bcp_roster_cm from roster_cm

delete from bcp_roster_cm


sp_helptext 

VAG_cc_Atento_Cordoba

create table vags (tx_vag varchar(30), tx_site varchar(30), tx_campa�a varchar(30), bl_activo bit, tx_tcs varchar(200))

select * from camapa_pcrc

insert into vags (tx_site, tx_campa�a, tx_tcs) select site, campa�a, pcrc from camapa_pcrc

select len('Atenci�n Alto Riesgo/Competencia')

select origen,gvp_postdiscado from interaction_his where pseudoskill like 'transf%'

select * from roster_1l where site = 'mercedes' and campa�a like '%top'

alter procedure sp_get_vags 
as 
select tx_vag from vags where tx_vag <> ''

select * from vags
grant exec on sp_get_vags to web

alter procedure sp_truncate_rostercm
as
delete from  bcp_roster_cm

grant exec on sp_truncate_rostercm to web

select * from bcp_roster_cm

select * from bcp_roster_cm where lastname = 'escalante'

select * from dt_tipo_cliente

select sum(1) from interaction_his 
where --ANI is null and 
tipo_interaction = 'INBOUND' AND TIPO_RECURSO = 'AGENT'
AND ISNUMERIc(ani) = 0

SELECT * FROM IN



grant exec on sp_limpio_vags to web

alter procedure sp_limpio_vags
as
delete c
	from bcp_roster_cm c 
		inner join bcp_roster_cm c2
			on c.name = c2.name and c.vag <> c2.vag
		inner join vags v
			on charindex(c.vag, v.tx_padre)>0 and c2.vag=tx_vag
delete from roster_cm where firstName + '|' + lastName in (select firstName + '|' + lastName from bcp_roster_cm)
update roster_cm set fc_baja = getdate() where fc_baja is null
insert into roster_cm ([name], firstName, lastName, EmployeeID, vag) select * from bcp_roster_cm


select * from roster_cm

		)
group by name having sum(1) >1



master..xP_cmdshell 'dir'

select * from bcp_roster_cm where name = 'UNE380'

select * from bcp_roster_cm where 


sp_helptext SP_GET_LLAMADAS_PROY

    
alter PROCEDURE SP_GET_LLAMADAS_PROY (@DATE SMALLDATETIME, @SEGMENTO VARCHAR(40))      
AS      
select intervalo, ofr, at, ab, rec_proy, cast(((ofr/rec_proy)-1)*100 as numeric(6,2)) gap, cast(ab/ofr*100 as numeric(6,2))  TA from      
(      
select dbo.f(date_time)Intervalo, sum(entered)ofr, sum(answered)at, sum(abandoned)ab      
from skill_his s                       
inner join pseudoskill p on REPLACE(dbo.splitindex(skill,'|',0),'_apy','') = p.pseudoskill            
where atencion = @SEGMENTO and segmento <> CASE WHEN @SEGMENTO = 'COM' THEN 'top' ELSE '' END      
and dbo.dmy(dbo.f(date_time)) = dbo.dmy(@DATE)      
group by dbo.f(date_time)      
)x       
 left join WFM_LLAMADAS e on intervalo = e.date and e.segmento = CASE WHEN @SEGMENTO = 'COM' THEN 'NEG_Total_No_Carterizado_+_AV' ELSE '' END      
WHERE OFR > 0      
order by intervalo 

select * from interaction_his where dbo.dmy(fecha) = dbo.dmy(getdate()) and pseudoskill = 'comercial' or pseudoskill = 'comercial_apy')

select * from roster_cm where name not in (select usuario from roster_1l) order by vag

select * from roster_1l where asistente like '%PACHIANI%'


select * from interaction_his i 
	left join roster_cm r on i.login = r.name 
where dbo.dmy(fecha) >= '01/06/2011' and pseudoskill IN('Averias_VOZ_Masivo', 'Averias_VOZ_AR')
and r.name is not null

select * from roster_cm

select * from pseudoskill where segmento = 'voz masivo'

select max(fecha) from interaction_his

SELECT * FROM STATS_online where dbo.dmy(timestamp) = '20/06/2011'

s sp_get_stats_online

  
ALTER PROCEDURE sp_get_stats_online        
as        
select     
case when grouping(atencion) = 1 then 'Atencion Total' else atencion end atencion,     
case when grouping(segmento) = 1 then 'Total' else segmento end segmento,         
sum(case when tx_stat = 'Total_Calls_Answered' then valor else 0 end) AT,        
sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end) AB,        
sum(case when tx_stat = 'Total_Calls_Entered' then valor else 0 end) OFR,        
cast(case when sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end) = 0 then 0 else sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end)*1.0 /sum(case when tx_stat = 'Total_Calls_Entered' then valor else 0 end)*100.0 end as numeric(6,2)) TA     
from stats_online s left join (select distinct replace(pseudoskill,'_oun','') ps, atencion, segmento from pseudoskill) p on replace(s.tx_vq,'vq_','') = ps    
where dbo.dmy(timestamp) = '20/06/2011'
group by atencion, segmento with rollup        
order by case when grouping(segmento) = 1 then segmento else atencion end asc, sum(case when tx_stat = 'Total_Calls_Entered' then valor else 0 end) desc 
select * from openquerY(dw,'select * from tasa.party_tipo_cliente where cd_unidad_negocio = ''pym''')

s sp_mejoresmails


sp_mejoresmails