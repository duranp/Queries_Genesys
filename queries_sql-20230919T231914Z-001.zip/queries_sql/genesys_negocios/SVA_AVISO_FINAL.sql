ALTER PROCEDURE sp_enviar_mailing_sva  
as  
SELECT * into #t FROM OPENQUERY(DW,'  
select sp.cd_pedido_cliente -20000000000 cd_pedido_cliente, sp.fc_cumplimiento, T.CD_PRODUCTO_ES , SP.CD_PARTY-20000000000 cd_party  
from  
    tasa.sub_pedido sp  
  inner join tasa.tramites t  
   on t.cd_pedido_cliente = sp.cd_pedido_cliente and t.cd_sub_pedido = sp.cd_sub_pedido  
        inner join tasa.party_tipo_cliente c  
            on sp.cd_tipo_cliente = c.cd_tipo_cliente and cd_unidad_negocio = ''PYM''          
        where  
(  
 (cd_producto_es in(  
  ''230000046031'',  
  ''230000067920'',  
  ''230000068159'',  
  ''230000068123'',  
  ''230000068162'',  
  ''230000068120'',  
  ''230000068110'',  
  ''230000046031'',  
  ''230000067920'',  
  ''230000068159'',  
  ''230000068123'',  
  ''230000068162'',  
  ''230000068120'',  
  ''230000068110''  
 ) and t.cd_tipo_tramite = 502)  
 or (cd_producto_es = ''0230000068148'' and t.cd_tipo_tramite = 516)  
 or (cd_producto_es = ''0230000068149'' and t.cd_tipo_tramite = 514)  
)  
 and t.fc_cumplimiento >= date-4 
 and t.cd_estado_tramite in (''fa'',''cu'')  
')  
  
INSERT INTO [10.105.8.249].cate.dbo.e_envio_generico (tx_mail, tx_body, tx_titulo)  
SELECT distinct CO.SWEMAILADDRESS, REPLACE(TX_BODY,'�xxxcliente�',TX_PARTY+':'), TX_TITULO  
FROM VTV..HOY C   
 inner join vtv..casos ca on c.swcaseid = ca.swcaseid  
 INNER JOIN VTV..CONTACTO CO ON CO.SWPERSONID = C.CCTPERSONID  
 INNER JOIN #T T ON T.CD_PARTY = C.TASA_CLIE_CODIGO  
 inner join mailing_sva m on ca.CCTSUBMOTIVOID = m.CCTSUBMOTIVOID and CAST(t.cd_producto_es AS BIGINT) = m.cd_producto_es  
 LEFT JOIN DW..PARTY PA ON T.CD_PARTY = PA.CD_PARTY  
WHERE CCTFECHACONTACTO BETWEEN FC_CUMPLIMIENTO -8 AND FC_CUMPLIMIENTO  
AND CA.SWCASEID NOT IN (SELECT SWCASEID FROM MAILING_SVA_HIS)  
  
  
  
INSERT INTO MAILING_SVA_HIS (SWCASEID,CD_PEDIDO_CLIENTE)   
SELECT distinct ca.SWCASEID, T.CD_PEDIDO_CLIENTE  
FROM VTV..HOY C   
 inner join vtv..casos ca on c.swcaseid = ca.swcaseid  
 INNER JOIN VTV..CONTACTO CO ON CO.SWPERSONID = C.CCTPERSONID  
 INNER JOIN #T T ON T.CD_PARTY = C.TASA_CLIE_CODIGO  
 inner join mailing_sva m on ca.CCTSUBMOTIVOID = m.CCTSUBMOTIVOID and CAST(t.cd_producto_es AS BIGINT) = m.cd_producto_es  
 LEFT JOIN DW..PARTY PA ON T.CD_PARTY = PA.CD_PARTY  
WHERE CCTFECHACONTACTO BETWEEN FC_CUMPLIMIENTO -8 AND FC_CUMPLIMIENTO  
AND CA.SWCASEID NOT IN (SELECT SWCASEID FROM MAILING_SVA_HIS)  
  
DROP TABLE #T  
  

select * from MAILING_SVA_HIS



SELECT distinct CO.SWEMAILADDRESS, REPLACE(TX_BODY,'�xxxcliente�',TX_PARTY+':'), TX_TITULO  
FROM VTV..HOY C   
 inner join vtv..casos ca on c.swcaseid = ca.swcaseid  
 INNER JOIN VTV..CONTACTO CO ON CO.SWPERSONID = C.CCTPERSONID  
 INNER JOIN #T T ON T.CD_PARTY = C.TASA_CLIE_CODIGO  
 inner join mailing_sva m on ca.CCTSUBMOTIVOID = m.CCTSUBMOTIVOID and CAST(t.cd_producto_es AS BIGINT) = m.cd_producto_es  
 LEFT JOIN DW..PARTY PA ON T.CD_PARTY = PA.CD_PARTY  
WHERE CCTFECHACONTACTO BETWEEN FC_CUMPLIMIENTO -8 AND FC_CUMPLIMIENTO  

select * from stats_ppp

select max(