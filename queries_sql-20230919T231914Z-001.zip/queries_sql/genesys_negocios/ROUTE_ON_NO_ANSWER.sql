
create procedure sp_RouteOnNoAnswer
as
SELECT     r.sup, r.PCRC, r.vag, i.INTERACTION_ID, dbo.f(i.FECHA_INICIO) FECHA_INICIO, dbo.f(i.FECHA_FIN)FECHA_FIN, i.NOMBRE_RECURSO, i.PSEUDOSKILL, i.TIEMPO_RECURSO, i.RESULTADO_TECNICO, 
                      i.RESULTADO_TECNICO_AMPLIADO
FROM         INTERACTION_DET AS i LEFT OUTER JOIN
                      roster_cm_his AS r ON dbo.usr(i.NOMBRE_RECURSO) = r.name AND dbo.DMY(dbo.F(i.FECHA_INICIO)) = r.fc_foto
where dbo.f(fecha_inicio) >=dbo.dmy(dateadd(day,-7,getdate())) and resultado_tecnico_ampliado = 'RouteOnNoAnswer'

select top 10 * from interaction_det where resultado_tecnico_ampliado = 'RouteOnNoAnswer'

so 'send'

s sendtableto

sendtableto 'SELECT     r.sup, r.PCRC, r.vag, i.INTERACTION_ID, dbo.f(i.FECHA_INICIO) FECHA_INICIO, dbo.f(i.FECHA_FIN)FECHA_FIN, i.NOMBRE_RECURSO, i.PSEUDOSKILL, i.TIEMPO_RECURSO, i.RESULTADO_TECNICO, 
                      i.RESULTADO_TECNICO_AMPLIADO
FROM         INTERACTION_DET AS i LEFT OUTER JOIN
                      roster_cm_his AS r ON dbo.usr(i.NOMBRE_RECURSO) = r.name AND dbo.DMY(dbo.F(i.FECHA_INICIO)) = r.fc_foto
where dbo.f(fecha_inicio) >=dbo.dmy(dateadd(day,-7,getdate())) and resultado_tecnico_ampliado = ''RouteOnNoAnswer''', 'redirected','sebastian.mangisch@telefonica.com'

sendtableto 'exec genesys..sp_RouteOnNoAnswer', 'mango','sebastian.mangisch@telefonica.com'