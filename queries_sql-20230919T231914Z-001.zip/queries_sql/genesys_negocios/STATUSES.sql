select min(timestamp), max(timestamp), datediff(second, 
min(timestamp), max(timestamp)) from statuses

select * from statuses order by timestamp

seelct

select s.*,e.tx_estado, name, r.pcrc from statuses s inner join roster_cm r on s.employeeid = r.employeeid and fc_baja is null inner join estados e on s.status = e.cd_estado
order by employeeid

select * into triada_asistente from vw_triada_asistente 

select cd_triada, 
sum(case when tx_estado = 'ready' then 1 else 0 end)re,
sum(case when tx_estado = 'Notready' then 1 else 0 end) nr,
sum(case when tx_estado = 'LoguedOut' then 1 else 0 end) lo,
sum(case when tx_estado not in ('ready','NotReady','LogueOut') then 1 else 0 end) ot,
sum(1) q
from triada_asistente t 
	inner join roster_cm r on t.name = r.name 
	inner join statuses s on r.employeeid = s.employeeid 
	inner join estados e on s.status = e.cd_estado
group by cd_triada

update estados set tx_estado = replace(tx_estado,' ','')

create view vw_triada_asistente t
as
select distinct cd_triada, name from cartera

select sum(1) from bcp_roster_cm
select * from roster_cm where name = 'ata087'
truncate table statuses

select * from roster_cm where name = 'ATA088'

select * from statuses where status not in (select cd_estado from estados)

insert into estados values(1,'NotReady')

select * from estados

update estados set tx_estado = replace(tx_estado,' ','')
select * from roster_CM WHERE LASTNAME LIKE '%PAN%'
update cfg_envio_ef
set tx_destinatarios = tx_destinatarios +',cabrina.capparelli@telefonica.com'
where tx_descripcion = 'Eficiencia Ventas TOL'
select * from CFG_ENVIO_EF
update

select * from sysobjects where name like '%cfg%'

