drop table #f

alter function gf()
returns @f table (ts smalldatetime)
as
begin 
	declare @ts smalldatetime
	set @ts = '01/01/2009'
	while @ts < dateadd(year,1,getdate())
	begin
		insert @f select @ts
		set @ts = dateadd(day,1,@ts)
	end
	return
end

select * from 

select ts, suM(1) from dbo.gf() f inner join casos c on f.ts between c.swdatecreated and isnull(c.swdateresolved,dateadd(day,1,getdate()))
where year(ts) = 2011
group by ts
order by ts

select ts, suM(1) from dbo.gf() f inner join inbox c on f.ts between c.swdatereceived and isnull(c.swdateactiontaken,dateadd(day,1,getdate()))
inner join rooster_bo r on c.swreceiver = r.inbox
where year(ts) = 2011 and ts < getdate()
group by ts
order by ts

t rooster_bo

select swobjectid from inbox i inner join inbox_p p on i.swobjectid = p.[id de objeto] and i.swreceiver = p.[inbox tiene objeto] and swdateactiontaken is null
and swdatereceived = [fecha de recepcion]
and estado = 'abierto'
group by swobjectid
having suM(1) > 1
order by swobjectid desc


declare @c bigint
set @c = 7490978.00000

select distinct * from inbox_p where [id de objeto] = @c
select * from inbox   where swobjectid = @c


t inbox
select distinct * from inbox_p

drop table #t
select distinct * into #t from inbox_p
drop table inbox_p
select * into inbox_p from #t

---principio tablero pendientes - tiempos
select CASE WHEN [OBSERVACIONES DEL ESTADO] = 'GESTIONADO' THEN 'GESTIONADO' ELSE 'ABIERTO' END ESTADO, 'ap-inbox'i, sup,sum(1)q, grouping(sup)g,
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) <49 then 1 else 0 end) '2' ,
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) between 49 and 72 then 1 else 0 end) '3' ,
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) between 73 and 96 then 1 else 0 end) '4' ,
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION])  >96 then 1 else 0 end) '+4', 
sum(case when datediff(hour,[fecha de recepcion], getdate()) <49 then 1 else 0 end) '2' ,
sum(case when datediff(hour,[fecha de recepcion], getdate()) between 49 and 72 then 1 else 0 end) '3' ,
sum(case when datediff(hour,[fecha de recepcion], getdate()) between 73 and 96 then 1 else 0 end) '4' ,
sum(case when datediff(hour,[fecha de recepcion], getdate())  >96 then 1 else 0 end) '+4', 
sum(case when datediff(hour,[fecha apertura], getdate()) <49 then 1 else 0 end) '2' ,
sum(case when datediff(hour,[fecha apertura], getdate()) between 49 and 72 then 1 else 0 end) '3' ,
sum(case when datediff(hour,[fecha apertura], getdate()) between 73 and 96 then 1 else 0 end) '4' ,
sum(case when datediff(hour,[fecha apertura], getdate())  >96 then 1 else 0 end) '+4'
from inbox_p P INNER JOIN ROSTER_BO R ON P.[inbox tiene objeto] LIKE R.INBOX where estado = 'abierto'
group by CASE WHEN [OBSERVACIONES DEL ESTADO] = 'GESTIONADO' THEN 'GESTIONADO' ELSE 'ABIERTO' END, sup WITH ROLLUP
use vtv

select * from sys.objects where type_desc = 'SQL_STORED_PROCEDURE'

sp_helptext sp_pendiente
T INBOX_P

select  motivo, sum(1), avg(datediff(hour,swdatecreated,getdate()))  
from vw_casos 
where swstatus = 'abierto' and year(swdatecreated) = 2011
and dbo.isupper(motivo) = 0
group by motivo
order by suM(1) desc


update roster_bo 
set cota = replace(cota,' ','')


select month(swdateresolved)mes, sup, nombres,sum(1), avg(datediff(hour,swdatecreated, swdateresolved)) horas 
from
vw_casos c INNER JOIN ROSTER_BO R 
	ON c.cctcerradopor = r.cota
where year(swdatecreated) = 2011
group by month(swdateresolved), sup, nombres with rollup




DECLARE @data NVARCHAR(MAX), 
@delimiter NVARCHAR(5)
SELECT @data = '1,2,3,6,7,8,R,a,n,g,a,n,a,t,h',
@delimiter = ','
DECLARE @textXML XML;
SELECT @textXML = CAST('<d>' + REPLACE('1,2,3,6,7,8,R,a,n,g,a,n,a,t,h', @delimiter, '</d><d>') + '</d>' AS XML);
SELECT T.split.value('.', 'nvarchar(max)') AS data FROM @textXML.nodes('/d') T (split)

SP_HELPTEXT GF

SELECT * FROM  @textXML.nodes('/D[1]') A

select * from roster_bo where sup COLLATE Latin1_General_CS_AS = upper(sup)

select dbo.isupper('ALGo')

create function dbo.islower(@string varchar(4000))
returns bit
begin
	declare @res bit
	set @res = 0
	if @string COLLATE Latin1_General_CS_AS = lower(@string) set @res = 1		
	return @res
end




select CAST('<d>' + REPLACE(sup + ',' + inbox, ',', '</d><d>') + '</d>' AS XML)xml, *  
from inbox_p P INNER JOIN ROSTER_BO R ON P.[inbox tiene objeto] LIKE R.INBOX 
group by sup

select soundex('marquitos,8,R,b,n,g,a,n,a,t,h')

select str(135464564)*str(1)

ALTER FUNCTION [dbo].GetItem (@String nvarchar(max), @level tinyint)
RETURNS varchar(100)
AS
BEGIN
    DECLARE @INDEX INT, @ID_ANT INT, @POS INT, @RES NVARCHAR(4000), @FALTA NVARCHAR(4000)

    SELECT @INDEX = 1, @ID_ANT = 1, @POS = 1, @RES = 'ALGO Y NADA', @FALTA = @STRING
	IF @String IS NULL RETURN 'NALGA'

    WHILE @INDEX !=0
        BEGIN				
        	SELECT @INDEX = CHARINDEX(',',@FALTA)
			IF @POS = @LEVEL	
				BEGIN					
		--			SET @RES = @FALTA + '|' + STR(@POS) + '|' + STR(@LEVEL) + '|' + @STRING + '|'+ STR(@ID_ANT) + '|'+ STR(@INDEX)
					SET @RES = SUBSTRING(@STRING,@ID_ANT,@INDEX-1)
					BREAK
				END
			SELECT @ID_ANT = @ID_ANT + @INDEX, @POS = @POS +1, @FALTA = RIGHT(@STRING, LEN(@STRING)-@INDEX)				
		END  
	RETURN @RES
END


declare @nivel as int
set  @nivel = 2
select CASE @nivel WHEN 1 then sup WHEN 2 then nombres end
from roster_bo
group by CASE @nivel WHEN 1 then sup WHEN 2 then nombres end



SELECT DBO.GETITEM('marquitos,8,R,b,PONERLA,g,a,n,a,t,h',4)

SELECT CHARINDEX('M','marquitos,8,R,b,PONERLA,g,a,n,a,t,h')


SELECT RIGHT('marquitos,8,R,b,PONERLA,g,a,n,a,t,h',LEN('marquitos,8,R,b,PONERLA,g,a,n,a,t,h')-)
sp_helptext dmy


--clasificacion pend inbx x sup
select [mot/ev/tar],submotivo, clasificacion, sum(1), avg(datediff(hour,[fecha apertura],getdate())) 
from inbox_p P INNER JOIN ROSTER_BO R ON P.[inbox tiene objeto] LIKE R.INBOX
where sup = 'blanco'
group by [mot/ev/tar],submotivo, clasificacion
order by sum(1) desc

--detalle pend inbox x sup motivo
select *
from inbox_p P INNER JOIN ROSTER_BO R ON P.[inbox tiene objeto] LIKE R.INBOX
where sup = 'blanco' and [mot/ev/tar] = 'quejas' and  estado = 'abierto'



select * fron instancias

SELECT * FROM VW_CASOS WHERE SUBMOTIVO LIKE 'terabox'

select * from instancias where cctcaseid in (
select top 10000 swcaseid from vw_casos where year(swdatecreated) = 2011)


select * from vw_casos where swstatus = 'abierto' and motivo = 'quejas'
--INNER JOIN CASOS C ON P.[ID DE OBJETO] = C.SWCASEID AND SWDATECREATED >= '01/01/2011'

WHERE SUP = 'COBROS'


SELECT * FROM INBOX_P WHERE [inbox tiene objeto]  LIKE '%COB%' AND [FECHA APERTURA]>= '01/01/2011'



select * from inbox i inner join casos c on i.swobjectid = c.swcaseid and swstatus = 'abierto' 
inner join inbox_p p on i.swobjectid = p.[id de objeto]
where swdateactiontaken is null

select sum(1),count(distinct [id de objeto]) from inbox_p where estado = 'abierto'
t roster_bo


--gestionados
select distinct MONTH(SWDATERESOLVED), sup, SUM(1)    
from casos c 
	inner join inbox i 
		on c.swcaseid = i.swobjectid
		and swactionid = (select max(swactionid) from inbox where c.swcaseid = swobjectid and swactiontaken = 'gestionado')
		and i.swactiontaken = 'gestionado'
	INNER JOIN ROSTER_BO R 
		on i.swreceiver = r.inbox 
where  year(swdatecreated) = 2011 and swstatus = 'cerrado'
GROUP BY MONTH(SWDATERESOLVED), sup

SELECT TOP 10 * FROM CASOS C INNER JOIN ROSTER_BO R ON CCTCERRADOPOR = COTA
where  year(swdatecreated) = 2011 and swstatus = 'cerrado'

t inbox





select * from sys.objects where type_desc = 'SQL_STORED_PROCEDURE'

sp_helptext SP_GET


SP_PENDIENTE 'G','PERNICE'

alter PROCEDURE SP_PENDIENTE (@EST VARCHAR(20)=NULL,@SUP VARCHAR(20) = NULL )  
AS  
select sup,  NOMBRES,sum(1)q, grouping(sup)g,  
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) <49 then 1 else 0 end) 'E2' ,  
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) between 49 and 72 then 1 else 0 end) 'E3' ,  
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION]) between 73 and 96 then 1 else 0 end) 'E4' ,  
sum(case when datediff(hour,[fecha apertura], [FECHA DE RECEPCION])  >96 then 1 else 0 end) 'E+4',   
sum(case when datediff(hour,[fecha de recepcion], getdate()) <49 then 1 else 0 end) 'I2' ,  
sum(case when datediff(hour,[fecha de recepcion], getdate()) between 49 and 72 then 1 else 0 end) 'I3' ,  
sum(case when datediff(hour,[fecha de recepcion], getdate()) between 73 and 96 then 1 else 0 end) 'I4' ,  
sum(case when datediff(hour,[fecha de recepcion], getdate())  >96 then 1 else 0 end) 'I+4',   
sum(case when datediff(hour,[fecha apertura], getdate()) <49 then 1 else 0 end) 'T2' ,  
sum(case when datediff(hour,[fecha apertura], getdate()) between 49 and 72 then 1 else 0 end) 'T3' ,  
sum(case when datediff(hour,[fecha apertura], getdate()) between 73 and 96 then 1 else 0 end) 'T4' ,  
sum(case when datediff(hour,[fecha apertura], getdate())  >96 then 1 else 0 end) 'T+4'   
from inbox_p P INNER JOIN ROSTER_BO R ON P.[inbox tiene objeto] LIKE R.INBOX   
where estado = 'abierto'  
AND CASE WHEN [OBSERVACIONES DEL ESTADO] = 'GESTIONADO' THEN 'G' ELSE 'A' END = ISNULL(@EST, CASE WHEN [OBSERVACIONES DEL ESTADO] = 'GESTIONADO' THEN 'G' ELSE 'A' END)  
AND ISNULL(@SUP,SUP) = SUP  
group by sup, NOMBRES WITH ROLLUP  
use vtv

sp_helptext inbox_p

BULK INSERT inbox_p
   FROM 'c:\temp\Casos pendientes.csv'
   WITH 
      (
         FIELDTERMINATOR = ',',
		 ROWTERMINATOR = '\n',
		 formatfile = 'd:\bases\inbox_p.fmt'
      )

sp_help inbox_p
exec('
BULK INSERT inbox_p FROM ''C:\TEMP\Casos pendientes.csv''
	WITH (CODEPAGE = ''RAW'',DATAFILETYPE = ''char'',FIELDTERMINATOR = '','',ROWTERMINATOR = ''\n'',KEEPNULLS)')

USE [VTV]
GO
/****** Objeto:  Table [dbo].[inbox_p]    Fecha de la secuencia de comandos: 02/14/2011 17:54:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[inbox_p](
	[Sector Tiene Objeto] [varchar](255) NULL,
	[Apellido Tiene Objeto] [varchar](255) NULL,
	[Nombre Tiene Objeto] [varchar](255) NULL,
	[Inbox Tiene Objeto] [varchar](255) NULL,
	[Fecha de Recepcion] [datetime] NULL,
	[Fecha Compromiso] [datetime] NULL,
	[Mot/Ev/Tar] [varchar](255) NULL,
	[Submotivo] [varchar](255) NULL,
	[Clasificacion] [varchar](255) NULL,
	[Solucion] [varchar](255) NULL,
	[Tipo de Mensaje] [varchar](255) NULL,
	[Observaciones del Estado] [varchar](2000) NULL,
	[Fecha de Diferido] [datetime] NULL,
	[Tipo Cliente Tasa] [varchar](255) NULL,
	[Razon Social] [varchar](255) NULL,
	[Circuito] [varchar](255) NULL,
	[NroCliente] [varchar](255) NULL,
	[Id de Objeto] [varchar](255) NULL,
	[Tipo de Objeto] [varchar](255) NULL,
	[Producto] [varchar](255) NULL,
	[Nro de Servicio] [varchar](255) NULL,
	[Nro Sistema Gestion] [varchar](255) NULL,
	[Fecha Apertura] [datetime] NULL,
	[Sector Creo Objeto] [varchar](255) NULL,
	[Apellido Creo Objeto] [varchar](255) NULL,
	[Nombre Creo Objeto] [varchar](255) NULL,
	[Inbox Creo Objeto] [varchar](255) NULL,
	[Fecha Reapertura] [datetime] NULL,
	[Nro Factura] [varchar](255) NULL,
	[Estado] [varchar](255) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF

SELECT a.* FROM OPENROWSET( BULK 'c:\temp\Casos pendientes.csv', FIRSTROW = 2) AS a


select sup, b.* from
	(select sup, month(swdateactiontaken)mes
	from inbox i inner join roster_bo r on i.swreceiver = r.inbox and swactiontaken <> 'diferido' and year(swdateactiontaken) = 2010)a
pivot (count(mes) for mes in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])) b
union
select sup, b.* from
	(select sup, month(swdateactiontaken)mes, case when datediff(hour, swdatereceived, swdateactiontaken) <= 72 then 1 else 0 end p 
	from inbox i inner join roster_bo r on i.swreceiver = r.inbox and swactiontaken <> 'diferido' and year(swdateactiontaken) = 2010)a
pivot (sum(p) for mes in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])) b

ALTER PROCEDURE SP_PUNT_Q (@ANIO SMALLINT=NULL)
AS
select ISNULL(@ANIO,YEAR(GETDATE())) ANIO, sup, b.* from (
	select r.sup, month(swdateresolved) mes
	from casos c inner join roster_bo r on c.cctcerradopor = r.cota
	WHERE YEAR(SWDATERESOLVED) = ISNULL(@ANIO,YEAR(GETDATE()))
)a
pivot (count(mes) for mes in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])) b

ALTER PROCEDURE SP_PUNT_P (@ANIO SMALLINT=NULL)
AS
select ISNULL(@ANIO,YEAR(GETDATE())) ANIO, sup, nombres, b.* from (
	select r.sup, nombres, month(swdateresolved) mes, case when datediff(hour, swdatecreated, swdateresolved) <= 72 then 1 else 0 end p
	from casos c inner join roster_bo r on c.cctcerradopor = r.cota
	WHERE YEAR(SWDATERESOLVED) = ISNULL(@ANIO,YEAR(GETDATE()))
)a
pivot (sum(p) for mes in ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])) b

alter procedure sp_puntualidad (@anio smallint= null, @ciclo smallint=null)
as
select ISNULL(@ANIO,YEAR(GETDATE())) anio,
case grouping(sup) WHEN 1 then 'TOTAL' WHEN 0 THEN SUP END sup,
case grouping(nombres) WHEN 1 then 'TOTAL' WHEN 0 THEN nombres END NOMBRES,
cast(suM(case when month(swdateresolved) = 1 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 1 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [1],
cast(suM(case when month(swdateresolved) = 2 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 2 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [2],
cast(suM(case when month(swdateresolved) = 3 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 3 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [3],
cast(suM(case when month(swdateresolved) = 4 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 4 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [4],
cast(suM(case when month(swdateresolved) = 5 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 5 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [5],
cast(suM(case when month(swdateresolved) = 6 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 6 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [6],
cast(suM(case when month(swdateresolved) = 7 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 7 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [7],
cast(suM(case when month(swdateresolved) = 8 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 8 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [8],
cast(suM(case when month(swdateresolved) = 9 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 9 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [9],
cast(suM(case when month(swdateresolved) = 10 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 10 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [10],
cast(suM(case when month(swdateresolved) = 11 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 11 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [11],
cast(suM(case when month(swdateresolved) = 12 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 12 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [11]
from casos c inner join roster_bo r on c.cctcerradopor = r.cota
where YEAR(SWDATERESOLVED) = ISNULL(@ANIO,YEAR(GETDATE()))
group by sup, nombres
with rollup

drop procedure sp_puntuliadad 

grant exec on sp_puntualidad to web

sp_puntuliadad 2010

sp_helptext sp_pendientes

grom 


SP_PUNT_P 2011

select datediff(hour, swdatereceived, swdateactiontaken),* 
from inbox i inner join roster_bo r on i.swreceiver = r.inbox and swactiontaken <> 'diferido' where swobjectid = 10875997

select max(SWDATERESOLVED) from casos where swdateresolved < '01/02/2011' 


selecT * FR


alter procedure sp_puntualidad (@anio smallint= null, @ciclo smallint=null)
as
select ISNULL(@ANIO,YEAR(GETDATE())) anio,
case grouping(sup) WHEN 1 then 'TOTAL' WHEN 0 THEN SUP END sup,
case grouping(nombres) WHEN 1 then 'TOTAL' WHEN 0 THEN nombres END NOMBRES,
cast(suM(case when month(swdateresolved) = 1 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 1 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [1],
cast(suM(case when month(swdateresolved) = 2 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 2 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [2],
cast(suM(case when month(swdateresolved) = 3 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 3 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [3],
cast(suM(case when month(swdateresolved) = 4 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 4 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [4],
cast(suM(case when month(swdateresolved) = 5 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 5 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [5],
cast(suM(case when month(swdateresolved) = 6 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 6 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [6],
cast(suM(case when month(swdateresolved) = 7 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 7 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [7],
cast(suM(case when month(swdateresolved) = 8 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 8 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [8],
cast(suM(case when month(swdateresolved) = 9 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 9 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [9],
cast(suM(case when month(swdateresolved) = 10 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 10 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [10],
cast(suM(case when month(swdateresolved) = 11 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 11 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [11],
cast(suM(case when month(swdateresolved) = 12 then 1 else 0 end) as varchar(5)) +','+
cast(suM(case when month(swdateresolved) = 12 and datediff(hour, swdatecreated, swdateresolved)<= isnull(@ciclo,72) then 1 else 0 end) as varchar(5)) [11]
from casos c inner join roster_bo r on c.cctcerradopor = r.cota
where YEAR(SWDATERESOLVED) = ISNULL(@ANIO,YEAR(GETDATE()))
group by sup, nombres
with rollup

alter procedure sp_graph (@anio smallint=null, @sup varchar(50)=null)
as
select month(swdateresolved) mes, sup, sum(1)q, sum(case when datediff(hour, swdatecreated, swdateresolved)<= 72 then 1 else 0 end)*1.0/sum(1)*1.0 p
from casos c inner join roster_bo r on c.cctcerradopor = r.cota
where year(swdateresolved) = isnull(@anio,year(getdate()))and sup = isnull(@sup,sup)
group by month(swdateresolved), sup
order by month(swdateresolved), sup

sp_graph  2010,'batista' 


