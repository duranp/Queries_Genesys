select * from openquery(ge,'
SELECT fecha_inicio, fecha_fin, ultimo_recurso, atencion_agente FROM CONTACT_UNPRE.INTERACTION_201101 WHERE fecha_inicio > ''20110120000000'' and ultimo_recurso in 
(''Basso, Leonardo (XRE016)'',''Gersinich, Mario (XRE049)'') and pseudoskill <> ''sk_test_unpre'' order by ultimo_recurso, fecha_inicio')
select * from openquery(ge,'
select * from contact_unpre.agent_201101 WHERE DATE_TIME > ''20110120120000'' and agent <> ''OYM (adminUnpre)'' and talktime > 0 order by agent, date_time')
