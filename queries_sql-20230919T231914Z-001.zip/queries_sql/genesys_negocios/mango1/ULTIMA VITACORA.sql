declare @dts as varchar(50)
--set @dts = 'visualizador_manzanero'
set @dts = 'visualizador'
--set @dts = 'nuevos indicadores(am)'

select (select description from dts_detail where paquete= @dts and replace(taskname,'DTSTask','DTSStep') = slog.stepname) Proceso,
stepexecstatus, stepexecresult, starttime, endtime, elapsedtime, errordescription, progresscount 
from msdb..sysdtssteplog slog 
where lineagefull = 
	(select top 1 lineagefull from msdb..sysdtspackagelog where name= @dts order by starttime desc) 
order by starttime desc, isnull(endtime,getdate())desc


    
