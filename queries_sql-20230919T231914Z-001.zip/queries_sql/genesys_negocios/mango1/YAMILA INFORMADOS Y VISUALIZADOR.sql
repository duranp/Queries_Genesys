--EN TIC 10.105.8.249
select distinct dbo.dmy(timestamp) timestamp, tx_usuario, cd_manzana, cd_central, tx_calle, vl_numero, r_tb_pe, r_tb_pi, r_zp, r_sp, r_voip, r_fwt
from v_vitacora
where vl_numero <> 99999 and timestamp >= dbo.dmy(dateadd(month,-1,dbo.pd(getdate())))

--EN INDICADORES
select distinct cd_pedido_cliente, cd_sub_pedido, cd_tramite from tb_detalle 
where 
	--cd_accion = 'inf' 
	--and
	 tx_motivo in (select motivo from motivos_red)
	and fc_cumplimiento >= dbo.dmy(dateadd(month,-1,dbo.pd(getdate())))



