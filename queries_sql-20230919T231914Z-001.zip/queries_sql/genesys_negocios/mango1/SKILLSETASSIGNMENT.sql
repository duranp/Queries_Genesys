

select * into usaron from posventa.cate.dbo.usaron
select * into skillsetbyassignment from posventa.cate.dbo.skillsetbyassignment
select * into skilset from posventa.cate.dbo.skillset
select * into agent from posventa.cate.dbo.agent

select * into SkillsetByAssignment from posventa.cate.dbo.SkillsetByAssignment

select * from agent
select usertelsetloginid, surname, givenname, title, department, dbo.concatenate(distinct skillsetname) skillset
into asingaciones
from SkillsetByAssignment s 
	left join agent a on s.userid = a.userid
	inner join usaron u on a.telsetloginid = u.agentlogin
group by usertelsetloginid, surname, givenname, title, department

select * from asingaciones
union all
select telsetloginid usertelsetloginid, surname, givenname, title, department, '' skillset from agent where telsetloginid in (select agentlogin from usaron)
and telsetloginid not in (select usertelsetloginid from asingaciones)


SELECT * FROM AGENT WHERE surname = 'Leonarduzzi'
select * from agent where  and userid not in (select userid from skillsetbyassignment)

select * from SkillsetByAssignment where userid  in (select userid from agent)


