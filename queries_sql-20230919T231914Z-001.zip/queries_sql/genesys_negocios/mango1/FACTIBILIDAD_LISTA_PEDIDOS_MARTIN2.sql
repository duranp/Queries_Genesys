delete from borrar_fr3 where gpym <> 'GPYM'
select * from borrar_fr3
select distinct cd_pedido_cliente, cd_party into #cliente from [10.244.65.20].posventa.dbo.tb t inner join borrar_fr3 f on t.cd_pedido_cliente = f.pedido

select distinct 
case when f.cd_central is not null then 'si' else 'no' end fwt, 
case when v.[cod central] is not null then 'si' else 'no' end voip, 
case when a.codigo is not null then 'si' else 'no' end adsl,
case when p.cd_central is not null then 'si' else 'no' end parque_tb,
case when ps.cd_central is not null then 'si' else 'no' end parque_sp,
RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(DOMICILIO, '-', 0),':',1))) TX_CALLE, RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(domicilio, '-', 1),':',1))) VL_NUMERO, c.*
from borrar_fr3 c 
	left join #cliente cl 
		on c.pedido = cl.cd_pedido_cliente
	left join v_parque_tb_sp p 
		on cl.cd_party = p.cd_party_titular and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(domicilio, '-', 0),':',1))) = p.tx_calle 
		and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(domicilio, '-', 1),':',1))) = p.nu_calle
	left join v_parque_tb_sp ps
		on cl.cd_party = p.cd_party_titular and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(domicilio, '-', 0),':',1))) = ps.tx_calle 
		and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(domicilio, '-', 1),':',1))) = ps.nu_calle
		and ps.tx_producto is not null
	left join v_disp_adsl a on c.centralcd = a.codigo
	left join v_disp_voip v on c.centralcd = v.[cod central]
	left join v_disp_fwt f on c.centralcd = f.cd_central

select * from borrar_fr3		

select distinct cd_pedido_cliente, cd_party into #cliente from [10.244.65.20].posventa.dbo.tb t inner join borrar_fr f on t.cd_pedido_cliente = f.pedido

		/*
select top 1000 * from v_parque_tb_sp 

select * from v_parque_tb_sp where tx_calle = 'ADOLFO ALSINA' and nu_calle = '00431'

select * from dt_central

drop table borrar_cancelar
*/



