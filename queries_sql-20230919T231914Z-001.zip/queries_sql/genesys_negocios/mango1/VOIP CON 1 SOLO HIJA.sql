
select * from analisis..trafico_voip where [cd destino_2] in 
(select ani_hija from voip_madre_hija where ani_madre in (
	(select ani_madre from voip_madre_hija group by ani_madre having sum(1) =1)))


