select * from sysobjects where name like '%script%'

select * from v_reglas_scripts
select * from v_scripts


select * from V_zona_peligrosa where cd_central = 581 and cd_manzana = 561

select * from v_parque_tb_sp where cd_central = 586 and cd_manzana = 4476

sp_helptext SP_GET_SCRIPT

CREATE PROCEDURE SP_SCRIPTS (@CD_PRODUCTO AS VARCHAR(50), @TB BIT, @SP BIT, @VOIP BIT, @ZP CHAR(2))  
AS  
 SELECT CD_PRODUCTO,  
 CASE WHEN (CASE WHEN TB   IS NOT NULL THEN 1 ELSE 0 END) = @TB   THEN TB   ELSE NULL END TB,  
 CASE WHEN (CASE WHEN SP   IS NOT NULL THEN 1 ELSE 0 END) = @SP   THEN SP   ELSE NULL END SP,  
 CASE WHEN (CASE WHEN VOIP IS NOT NULL THEN 1 ELSE 0 END) = @VOIP THEN VOIP ELSE NULL END VOIP,  
 CASE WHEN @ZP IN ('PG','AM') AND ZP IS NOT NULL THEN ZP    
   WHEN @ZP = 'PI'         AND ZI IS NOT NULL THEN ZI   
   ELSE CASE WHEN (CASE WHEN VOIP IS NOT NULL THEN 1 ELSE null END) = @VOIP THEN VOIP ELSE   
    CASE WHEN (CASE WHEN SP IS NOT NULL THEN 1 ELSE null END) = @SP   THEN SP ELSE   
     CASE WHEN (CASE WHEN TB   IS NOT NULL THEN 1 ELSE null END) = @TB   THEN TB  
      ELSE NULL         
 END END END    
 END SCRIPTS  
 FROM V_REGLAS_SCRIPTS WHERE CD_PRODUCTO = @CD_PRODUCTO   
 
 sp_scripts 'sp',1,1,1,'pi'
 
 alter procedure sp_get_scripts 
 as
	select * from v_scripts_old order by cd_script
 go
 create  procedure sp_get_reglas_scripts 
 as
	select * from v_reglas_scripts
 go
 
 sp_upd_script @cd_script=1, @tx_info_adicional = 'cacofono!!!'

drop table v_scripts_old
select * into v_scripts_old from v_scripts
select * from v_reglas_scripts

select * from v_scripts
 
 alter procedure sp_upd_script (@cd_script tinyint, @tx_situacion varchar(8000) = null, @tx_script varchar(8000) = null, @tx_info_adicional varchar(8000) = null, @tx_oferta_comercial varchar(8000) = null, @tx_objeciones varchar(8000) = null)
 as
	update v_scripts_old set 
		tx_situacion = isnull(@tx_situacion, tx_situacion),
		tx_script = isnull(@tx_script, tx_script),
		tx_info_adicional = isnull(@tx_info_adicional, tx_info_adicional),
		tx_oferta_comercial = isnull(@tx_oferta_comercial, tx_oferta_comercial),
		tx_objeciones = isnull(@tx_objeciones, tx_objeciones)
	where cd_script = @cd_script
 go
 
grant exec on sp_upd_script to v
 alter procedure sp_add_blank_script 
 as 
	insert into v_scripts_old (tx_situacion, tx_script, tx_info_adicional, tx_oferta_comercial, tx_objeciones) values (null, null, null, null, null)	 
 go

grant exec on sp_add_blank_script to v
sp_del_script 16
alter procedure sp_del_script (@cd_script tinyint)
as
	declare @cant as int
	select @cant = count(*) from v_reglas_scripts where tb like '%,'+cast(@cd_script as varchar(30))+',%' or sp = @cd_script or voip = @cd_script or zp = @cd_script or zi = @cd_script 
	--print @cant
	if @cant > 0
		begin
			select 'no' borro
		
		end
	if @cant = 0
		begin
			select 'si' borro
				delete from v_scripts_old where cd_script = @cd_script
		end
go
 grant exec on sp_upd_regla to v
sp_del_script 5
 
update v_reglas_scripts set tb = ',1,2,3,4,5,' where tb = '1,2,3,4,5'
 
 sp_add_script 'prueba','prueba','prueba','prueba','prueba'
 
 
 delete from v_scripts where cd_script = 15
 sp_get_scripts
 
 select * from v_reglas_scripts
 
 
 
 sp_helptext sp_scripts
 

alter PROCEDURE SP_GET_SCRIPT (@CD_SCRIPT AS TINYINT)  
AS  
 SELECT * FROM V_SCRIPTS WHERE CD_SCRIPT = @CD_SCRIPT  


select * from V_parque_tb_sp where ani = '1143622221'


select * from v_retrabajos where cd_pedido = 194510646

select * from v_scripts_old
delete from v_scripts_old where cd_script = 1 and tx_situacion is null

declare @max as int
select @max = max(cd_script) from v_scripts_old
print @max
DBCC CHECKIDENT (v_scripts_old, RESEED, @max)

select * from

	SET XACT_ABORT ON
	declare @max as int
	select @max = max(cd_script) from v_scripts_old	
	DBCC CHECKIDENT (v_scripts_old, RESEED, @max)

select 


select * into v_reglas_scripts_old from v_reglas_scripts


alter procedure sp_upd_regla (@cd_producto varchar(50), @tb varchar(50) = null, @sp varchar(50) = null, @voip varchar(50) = null, @zp varchar(50) = null, @zi varchar(50) = null)  
as  
 update v_reglas_scripts_old set   
  tb = case when @tb = '' then null else isnull(@tb, tb) end,  
  sp = case when @sp = '' then null else isnull(@sp, sp) end,  
  voip = case when @voip = '' then null else isnull(@voip, voip) end,  
  zp = case when @zp = '' then null else isnull(@zp, zp) end,  
  zi = case when @zi = '' then null else isnull(@zi, zi) end
 where cd_producto = @cd_producto  
go

exec sp_upd_regla @cd_producto='sp+voip',@tb=''
exec sp_get_reglas_scripts

select substring(',1,5,3,4,23,',2,len(',1,5,3,4,23,')-2)
if charindex(',',substring(',1,5,3,4,23,',2,len(',1,5,3,4,23,')-2),0)>0
begin 
	print 'array'
end

alter procedure sp_chk_regla (@vec_scripts as varchar(200))
as
if charindex(',',@vec_scripts,0)>0
	begin 
		select items cd_script from split(@vec_scripts,',') t where items not in (select cd_script from v_scripts) and items <>''
	end
else
	begin
		select items cd_script from split(@vec_scripts,'') t where items not in (select cd_script from v_scripts)
	end	
go
select * from  split(',15,16,17,',',') where items <>''

sp_chk_regla ''
select * from v_scripts

sp_upd_regla @cd_producto='TB+SP',@tb=',1,2,3,4,5'

sp_helptext sp_get_reglas_scripts

alter procedure sp_get_reglas_scripts   
 as  
 select * from v_reglas_scripts_old  

sp_helptext sp_upd_regla

sp_get_reglas_scripts
SELECT * FROM V_PARQUE_TB_SP WHERE ANI = 2324428360

SELECT * FROM BCP_retrabajos_DW ORDER BY CD_PEDIDO_CLIENTE DESC WHERE FC_CUMPLIMIENTO IS NULL WHERE CD_PEDIDO_CLIENTE= '195594016'

SELECT * FROM 

SELECT * FROM BCP_RETRABAJOS WHERE TX_CALLE LIKE '%MOSCONI%' AND VL_NUMERO = 128


create procedure sp_add_regla (@cd_producto varchar(50))
as
	insert into v_reglas_scripts_old values(@cd_producto,null,null,null,null,null)
go

create procedure sp_del_regla (@cd_producto varchar(50))
as
	delete from v_reglas_scripts_old where cd_producto = @cd_producto
go

sp_add_regla 'prueba'

grant exec on sp_del_regla to v



