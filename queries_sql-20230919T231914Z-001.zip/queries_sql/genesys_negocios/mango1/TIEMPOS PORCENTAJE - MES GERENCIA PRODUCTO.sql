--CONEX:CS_ADMIN_TE071065
use POSVENTA

SET NOCOUNT ON  
select e.tx_gerencia, year(t.fc_cumplimiento) anio, month(t.fc_cumplimiento) mes, T.cd_central, datediff(day, T.fc_emision, isnull(a.fc_cumplimiento,t.fc_cumplimiento)) t, CASE WHEN A.CD_PEDIDO_CLIENTE IS NULL THEN 'TB mono' ELSE 'TBSP' END tx_producto  
into #t   
from tb T 
	LEFT JOIN ADSL A ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO and a.cd_estado_tramite = 'cu'
	left join adsl a2 ON A2.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A2.CD_SUB_PEDIDO = t.cd_sub_pedido and a2.cd_estado_tramite = 'an'
	left join dt_estructura e on t.cd_central = e.cd_central
where   
 T.cd_estado_tramite = 'fa' and a2.cd_pedido_cliente is null
 and T.cd_producto not in ('02100000000P7','02100000000P4')  
 and t.fc_cumplimiento >= dbo.pd(dateadd(month,-6,getdate()))
union all  
select e.tx_gerencia, year(a.fc_cumplimiento) anio, month(a.fc_cumplimiento)mes, A.cd_central, datediff(day, A.fc_emision, A.fc_cumplimiento) t, 'sp mono' tx_producto  
from adsl A LEFT JOIN TB T ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO
	left join dt_estructura e on a.cd_central = e.cd_central
where   
 A.cd_motivo_ingreso is null  
 AND T.CD_PEDIDO_CLIENTE IS NULL
 and A.cd_estado_tramite = 'cu'   
 and A.fc_cumplimiento >= dbo.pd(dateadd(month,-6,getdate()))
   
select distinct  tt.tx_gerencia, tt.anio, tt.mes, tt.tx_producto,
(select MAX(T) from (select top 10 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '10%',  
(select MAX(T) from (select top 20 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '20%',
(select MAX(T) from (select top 30 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '30%',
(select MAX(T) from (select top 40 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '40%',
(select MAX(T) from (select top 50 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '50%',
(select MAX(T) from (select top 60 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '60%',
(select MAX(T) from (select top 70 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '70%',
(select MAX(T) from (select top 80 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '80%',
(select MAX(T) from (select top 90 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '90%',
(select MAX(T) from (select top 100 percent with ties t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia order by T)a) '100%',
(select SUM(1) from (select t from #T where  tx_producto = tt.tx_producto  and mes = tt.mes and anio = tt.anio and tx_gerencia = tt.tx_gerencia )a) 'total'
from #T tt 

drop table #t
/*
select *
from tb T 
	inner JOIN ADSL A ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO and a.cd_estado_tramite = 'cu'
where t.cd_estado_tramite = 'fa' and t.fc_cumplimiento >= '01/03/2010'  and T.cd_producto not in ('02100000000P7','02100000000P4')  
*/

