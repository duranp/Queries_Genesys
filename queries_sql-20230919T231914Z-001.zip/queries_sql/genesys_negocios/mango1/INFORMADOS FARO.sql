select * from tb where cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)


drop table #tb
drop table #adsl


select distinct cd_pedido_cliente - 20000000000 cd_pedido_cliente, cd_sub_pedido, fc_entrada, fc_emision, fc_cumplimiento, tx_estado_tramite
into #tb
from tb_detalle t where
(tx_motivo in ('casa cerrada','avisara','no se localiza domicilio') or tx_motivo like '%desiste%')
and fc_entrada = (select min(fc_entrada) from tb_detalle where
	(tx_motivo in ('casa cerrada','avisara','no se localiza domicilio') or tx_motivo like '%desiste%')
	and cd_pedido_cliente = t.cd_pedido_cliente and cd_sub_pedido = t.cd_sub_pedido)
and fc_entrada >= '03/10/2009'
and cd_accion = 'inf'


select distinct cd_pedido_cliente - 20000000000 cd_pedido_cliente, cd_sub_pedido, fc_entrada, fc_emision, fc_cumplimiento, tx_estado_tramite
into #adsl
from adsl_detalle a where
(tx_motivo in ('casa cerrada','avisara','no se localiza domicilio') or tx_motivo like '%desiste%')
and fc_entrada = (select min(fc_entrada) from adsl_detalle where
(tx_motivo in ('casa cerrada','avisara','no se localiza domicilio') or tx_motivo like '%desiste%')
and cd_pedido_cliente = a.cd_pedido_cliente and cd_sub_pedido = a.cd_sub_pedido)
and fc_entrada >= '03/10/2009'
and cd_accion = 'inf'
and cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)
  
--INFORMADOS POR MES TB
select COUNT(*) from tb t INNER join #TB t2 on t.cd_pedido_cliente = t2.cd_pedido_cliente and t.cd_sub_pedido = t2.cd_sub_pedido
where   
 cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)
and FC_ENTRADA BETWEEN '04/11/2009' AND '19/11/2009'
AND CD_PRODUCTO NOT IN ('02100000000P7','02100000000P4')

--EMITIDOS TB
SELECT COUNT(*) FROM TB
WHERE  
 FC_EMISION BETWEEN '04/11/2009' AND '19/11/2009'
AND CD_PRODUCTO NOT IN ('02100000000P7','02100000000P4')
AND  cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)

--INFORMADOS POR MES ADSL
select COUNT(*) from ADSL t INNER join #ADSL t2 on t.cd_pedido_cliente = t2.cd_pedido_cliente and t.cd_sub_pedido = t2.cd_sub_pedido
where   
 cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)
and FC_ENTRADA BETWEEN '04/11/2009' AND '19/11/2009'
AND CD_MOTIVO_INGRESO IS NULL AND TX_PROD_ADSL <> 'CAM24'


--EMITIDOS ADSL
SELECT COUNT(*) FROM ADSL
WHERE
FC_EMISION BETWEEN '04/11/2009' AND '19/11/2009'
AND CD_MOTIVO_INGRESO IS NULL AND TX_PROD_ADSL <> 'CAM24'
AND  cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)

  /*
select cd_estado_tramite, month(fc_emision), count(*) tot, sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) inf 
	from tb t 
		left join #tb i 
			on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
			where t.fc_cumplimiento >= '01/07/2009'
			and cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)
group by cd_estado_tramite, month(fc_cumplimiento)
order by cd_estado_tramite, month(fc_cumplimiento)	

select cd_estado_tramite, month(fc_cumplimiento), count(*) tot, sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) inf 
	from adsl t 
		left join #adsl i 
			on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
			where t.fc_cumplimiento >= '01/07/2009'
			and t.cd_motivo_ingreso is null
						and cd_central in (
116, 234, 285, 354, 406, 913, 260, 690, 261, 226, 262, 263, 265, 264, 266, 737, 722, 476, 298, 305, 723,28,
27, 26, 25, 489,29)
group by cd_estado_tramite, month(fc_cumplimiento)
order by cd_estado_tramite, month(fc_cumplimiento)			
  
 


*/