

select datediff(hour,fh_ingreso, fh_cierre)horas_reparacion, case when p.ani is not null then 'si' else 'no' end speedy, a.*
from cate..averias a 
	inner join #t t on a.cd_tipo_cliente = t.cd_tipo_cliente and cd_unidad_negocio in ('GCL')
	left join TIC.VISUALIZADOR.DBO.V_PARQUE_TB_SP p on a.ani = p.ani AND P.TX_PRODUCTO IS NOT NULL
where 
fh_cierre >= '01/01/2010'

SELECT TOP 1200 * FROM TIC.VISUALIZADOR.DBO.V_PARQUE_TB_SP WHERE TX_PRODUCTO IS NOT NULL


select * from dt_tipo_cliente

select * into #t from openquery(dw,'select * from tasa.party_tipo_cliente')
select * from #t 

SELECT * FROM VOIP_MADRE_HIJA