--CONEX:CS_ADMIN_TIC
USE CATE

/*
--REBOTES
	--sup agent
	select month(ts)mes, tx_supervisor, tx_usuario, sum(rebote)/cast(sum(1) as real) [%r], sum(1) t, sum(rebote) r
	from (
		select distinct dbo.dmy(en.timestamp)ts, (select top 1 P.TX_USUARIO from e_usuarios_j h       
		left join e_usuarios_j p on h.id_parent = p.id_usuario WHERE h.tx_usuario = en.TX_USUARIO) tx_supervisor, en.tx_usuario, en.tx_mail,
		case when m.tx_mail is not null then 1 else 0 end rebote
		from e_enviados en left join e_mails m on en.tx_mail = m.tx_mail)x
	group by month(ts), tx_supervisor, tx_usuario
	order by month(ts), tx_supervisor, tx_usuario

	--sup 
	select month(ts)mes, tx_supervisor, sum(rebote)/cast(sum(1) as real) [%r], sum(1) t_env, sum(rebote) r
	from (
		select distinct dbo.dmy(en.timestamp)ts, (select top 1 P.TX_USUARIO from e_usuarios_j h       
		left join e_usuarios_j p on h.id_parent = p.id_usuario WHERE h.tx_usuario = en.TX_USUARIO) tx_supervisor, en.tx_usuario, en.tx_mail,
		case when m.tx_mail is not null then 1 else 0 end rebote
		from e_enviados en left join e_mails m on en.tx_mail = m.tx_mail)x
	group by month(ts), tx_supervisor
	order by month(ts), tx_supervisor
*/
--ranking total
select e1.mes, e1.tx_supervisor, e1.tx_usuario, t_env enviados,r rebotes,t_enc encuestados,p preg_critica
from (
	select (select top 1 P.TX_USUARIO from cate..e_usuarios_j h left join cate..e_usuarios_j p on h.id_parent = p.id_usuario WHERE h.tx_usuario = env.TX_USUARIO)tx_supervisor,
	env.tx_usuario, month(enc.timestamp) mes, avg(p10)p, sum(1)t_enc 
	from cate..e_encuestas enc inner join cate..e_enviados env on enc.id_enviado = env.id_enviado
	group by tx_usuario, month(enc.timestamp) 
	) e1
left join 
	(
	select month(ts)mes, tx_supervisor, tx_usuario, sum(rebote)/cast(sum(1) as real) [%r], sum(1) t_env, sum(rebote) r
	from (
		select distinct dbo.dmy(en.timestamp)ts, (select top 1 P.TX_USUARIO from cate..e_usuarios_j h       
		left join cate..e_usuarios_j p on h.id_parent = p.id_usuario WHERE h.tx_usuario = en.TX_USUARIO) tx_supervisor, en.tx_usuario, en.tx_mail,
		case when m.tx_mail is not null then 1 else 0 end rebote
		from cate..e_enviados en left join cate..e_mails m on en.tx_mail = m.tx_mail)x
	group by month(ts), tx_supervisor, tx_usuario	
	) e2
on e1.mes = e2.mes and e2.tx_usuario = e1.tx_usuario and e1.tx_supervisor = e1.tx_supervisor






