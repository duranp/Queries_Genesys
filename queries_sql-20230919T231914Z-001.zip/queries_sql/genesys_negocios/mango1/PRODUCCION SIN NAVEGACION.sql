
create table #fecha (fc_dia smalldatetime)

declare @a as int
set @a=0
while (@a < datediff(day, '01/07/2008', getdate()))
begin
	set @a=@a+1
	insert into #fecha values(convert(varchar(10),dateadd(day, -@a, getdate()), 112))
end
select * from #fecha

select 
f.fc_dia, isnull(vl_cumplidas, 0) vl_cumplidas, isnull(vl_canceladas, 0) vl_canceladas, isnull(vl_emitidas, 0) vl_emitidas, 'Sin Navegacion' tx_producto 
into #SN
from #fecha f
	left join (select count(*) vl_emitidas, a.fc_emision fc_dia
		   from adsl a inner join bv_sin_navegacion s on a.cd_pedido_cliente = s.cd_pedido_cliente and a.cd_motivo_ingreso is null
		   where year(a.fc_emision) >= 2008
		   group by a.fc_emision) e
		on f.fc_dia = e.fc_dia
	left join (select a.fc_cumplimiento fc_dia, 
		   sum(case when a.cd_estado_tramite = 'an' then 1 else 0 end) vl_canceladas,  
		   sum(case when a.cd_estado_tramite = 'cu' then 1 else 0 end) vl_cumplidas
		   from adsl a inner join bv_sin_navegacion s on a.cd_pedido_cliente = s.cd_pedido_cliente and a.cd_motivo_ingreso is null
		   where year(a.fc_cumplimiento) >= 2008
		   group by a.fc_cumplimiento) af
		on f.fc_dia = af.fc_dia
order by f.fc_dia

DELETE from pd_indicadores where fc_dia in (select FC_DIA from #mig) and tx_producto = 'Sin Navegacion'
INSERT INTO PD_INDICADORES
SELECT * FROM #SN

			
drop table #fecha
DROP TABLE #SN

/*

select 'SN' tx_producto, e.anio, e.mes, e.dia, e.e, fc.fa, fc.an from
(select 
year(a.fc_emision) anio, month(a.fc_emision) mes, day(a.fc_emision) dia,
count(*) e
from adsl a inner join bv_sin_navegacion s on a.cd_pedido_cliente = s.cd_pedido_cliente where cd_motivo_ingreso is null
group by year(a.fc_emision), month(a.fc_emision), day(a.fc_emision))e
left join 
(select 
year(a.fc_cumplimiento) anio, month(a.fc_cumplimiento) mes, day(a.fc_cumplimiento) dia,
sum(case when a.cd_estado_tramite = 'cu' then 1 else 0 end)fa, 
sum(case when a.cd_estado_tramite = 'an' then 1 else 0 end)an,
count(*) cant
from adsl a inner join bv_sin_navegacion s on a.cd_pedido_cliente = s.cd_pedido_cliente where cd_motivo_ingreso is null
group by year(a.fc_Cumplimiento), month(a.fc_cumplimiento), day(a.fc_cumplimiento))fc
on e.anio = fc.anio and e.mes = fc.mes and e.dia = fc.dia
where e.anio >= 2010*/