CREATE ASSEMBLY StringUtilities FROM 'C:\Archivos de programa\Microsoft SQL Server\90\Samples\Engine\Programmability\CLR\StringUtilities\CS\StringUtilities\bin\debug\StringUtilities.dll'
WITH PERMISSION_SET=SAFE;
GO

CREATE AGGREGATE [dbo].[Concatenate]
(@input [nvarchar](4000))
RETURNS[nvarchar](4000)
EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.Concatenate]
sp_configure 'clr enabled',1