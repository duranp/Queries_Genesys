--drop table #mc
SELECT * INTO #MC FROM INDICADORES.ANALISIS.DBO.MOTIVOS_adsl WHERE CD_IMPLICANCIA = 'C' 
and tx_motivo not in (select motivo from indicadores.posventa.dbo.motivos_red)
union all
select * from INDICADORES.ANALISIS.DBO.MOTIVOS_tb WHERE CD_IMPLICANCIA = 'C'
and motivo not in (select motivo from indicadores.posventa.dbo.motivos_red)

select * from borrar_informados_pegaso where cd_pedido= 186941336
select sum(1) FROM #mc --INDICADORES.ANALISIS.DBO.MOTIVOS_tb WHERE CD_IMPLICANCIA = 'C'
select * from #mc
drop table BORRAR_INFORMADOS_PEGASO
select p.cd_pedido, p.cd_sub_pedido, p.cd_tramite, p.cd_producto_pgc, e.timestamp, M.TX_MOTIVO
INTO BORRAR_INFORMADOS_PEGASO
from pgc_pedidos p 
	inner join vw_pgc_estados e
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
	INNER JOIN DT_MOTIVO M
		ON E.CD_MOTIVO = M.CD_MOTIVO
where 
e.cd_usuario in ('cota') and e.tx_estado_pgc = 'informado' and p.cd_producto_pgc in (
'ADSL', 
'EQ VOIP',
'CAM24',
'FWT',
'LAN OFFICE',
'MIGR LAN',
'MIGR VOIP',
'PC',
'PDTI',
'SFT-MUSICA',
'SPD READY',
'TB',
'TB MP',
'VOIP',
'VPN'
)

and e.timestamp >= '01/01/2010'
AND M.TX_MOTIVO IN (SELECT tx_MOTIVO FROM #MC)



select month(timestamp) mes, datepart(week, timestamp) semana, 
case when datepart(weekday,TIMESTAMP) = 6 then 'Sabado' 
			   when datepart(weekday,TIMESTAMP) = 7 then 'Domingo' 
	      end dia,*
from BORRAR_INFORMADOS_PEGASO
where datepart(weekday,TIMESTAMP)  in (6,7)


select * from v_retrabajos where cd_manzana = 572 and cd_central = 200




