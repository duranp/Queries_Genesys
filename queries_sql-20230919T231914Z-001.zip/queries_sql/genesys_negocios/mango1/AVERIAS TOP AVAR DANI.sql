select case when tx_tipo_cliente like 'alto%' then 'AV-AR' when tx_tipo_cliente like 'top%' then 'TOP' end Segmento, month(fh_cierre), sum(1)  
from cate..averias
where (tx_tipo_cliente like 'alto%' or tx_tipo_cliente like 'top%') and year(fh_cierre) = 2010
group by case when tx_tipo_cliente like 'alto%' then 'AV-AR' when tx_tipo_cliente like 'top%' then 'TOP' end, month(fh_cierre)
order by case when tx_tipo_cliente like 'alto%' then 'AV-AR' when tx_tipo_cliente like 'top%' then 'TOP' end, month(fh_cierre)

dbcc checktable(preguntas)

select * from pgc_deuda

select top 10 * from posventa..adsl

select top 10 * from averias

select * from sysobjects where xtype = 'u' order by name

select * into act_cierre from openquery(dw,'select * from tasa.tipo_actuacion where cast(cd_tipo_actuacion as varchar(10)) like ''%4''')


select left(cd_tipo_actuacion,len(cd_tipo_actuacion)-1),* from act_cierre where cd_tipo_actuacion in (select cd_tipo_actuacion_cierre from averias)