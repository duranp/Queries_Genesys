drop table #a
--reiteros
select a.*,b.cd_tipo_actuacion_apertura r_sintoma, b.cd_tipo_actuacion_cierre r_franqueo, datediff(day, a.fh_cierre,b.fh_ingreso) ventana, t.cd_unidad_negocio 
into #a
from averias a 
	inner join posventa..dt_tipo_cliente t 
		on a.cd_tipo_cliente = t.cd_tipo_cliente 
	left  join averias b
		on a.ani = b.ani and a.cd_averia <> b.cd_averia and a.fh_cierre between dateadd(day,-7,b.fh_ingreso) and b.fh_ingreso
where a.fh_cierre >= '01/09/2009'

--averias por franqueo|cliente|mes
select a.tx_tipo_cliente, t.tx_tipo_actuacion, a.cd_tipo_actuacion_cierre, month(fh_cierre)mes , year(fh_cierre) mes, sum(1) 
from cate..averias a 
	left join tipo_actuacion t on a.cd_tipo_actuacion_cierre = t.cd_tipo_actuacion
	inner join posventa..dt_tipo_cliente tc on a.cd_tipo_cliente = tc.cd_tipo_cliente 
where fh_cierre >= '01/09/2009'
group by a.tx_tipo_cliente, t.tx_tipo_actuacion, a.cd_tipo_actuacion_cierre, month(fh_cierre), year(fh_cierre)
order by a.tx_tipo_cliente, t.tx_tipo_actuacion, a.cd_tipo_actuacion_cierre, month(fh_cierre), year(fh_cierre)

