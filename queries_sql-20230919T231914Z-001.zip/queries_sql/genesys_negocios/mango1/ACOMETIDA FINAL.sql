s 'analisis..borrar_no_edificios'
drop table analisis..borrar_no_edificios 



--edificios
select * into analisis..borrar_no_edificios from openquery(dw,
	'Select	distinct rtrim(cd_interurbano)||rtrim(cd_urbano)||cd_linea ani
From	 tasa.service_number s Inner Join tasa.producto_instancia_red pir
	On	s.cd_producto_instancia = pir.cd_producto_instancia
Inner Join tasa.producto_instancia pi
	On	pi.cd_producto_instancia = s.cd_producto_instancia
	Inner Join tasa.caja c
	On	pir.cd_manzana_central = c.cd_central
	And	pir.cd_manzana = c.cd_manzana
	And	pir.cd_caja = c.cd_caja
	And	cd_tipo_caja in(''03'',''05'',''06'',''07'',''08'',''09'')
	Inner Join tasa.party_tipo_cliente tc
	On	pi.cd_tipo_cliente = tc.cd_tipo_cliente
	And	cd_unidad_negocio = ''pym''
Where	pir.fc_cambio = (
Select	max(fc_cambio)
From	tasa.producto_instancia_red
Where	cd_producto_instancia = pir.cd_producto_instancia)
and pi.fc_baja is null and s.fc_FINAL IS NULL')




---FINAL drop table #para_acometer2 drop table #para_acometer
declare @fc as smalldatetime
set @fc = dateadd(month, -4, getdate())

select a.ani
into #para_acometer
from cate..averias a 
	--left join #parque p on a.ani = p.ani	
where --p.ani is not null and 
fh_cierre >= @fc
and a.ani not in (select ani from acometidas_final)
and a.ani  in (select ani from analisis..borrar_no_edificios)
group by a.ani--, a.tx_tipo_cliente--, p.tx_producto,  p.cd_party_titular, p.cd_central, p.cd_manzana,p.tx_calle, p.nu_calle
having count(*)>2

--limpio paruqe --drop table  #parque
select * into #parque from tic.visualizador.dbo.v_parque_tb_sp p where exists(select * from #para_acometer where ani = p.ani)

--query final --drop table #para_acometer2
/*declare @fc as smalldatetime
set @fc = dateadd(month, -3, getdate())*/
select a.ani, a.tx_tipo_cliente, p.tx_producto,  p.cd_party_titular, p.cd_central, p.cd_manzana,p.tx_calle, p.nu_calle,
 count(*) ave, 
(select sum(1) from vtv_ave where ani = a.ani and fc_llamada>=@fc)vtv, 
(select tx_submotivo_contacto from vtv_ave where ani = a.ani and cd_caso = (select max(cd_caso) from vtv_ave where a.ani = ani) and fc_llamada>=@fc) submotivo,
(select tx_gestion_contacto from vtv_ave where ani = a.ani and cd_caso = (select max(cd_caso) from vtv_ave where a.ani = ani) and fc_llamada>=@fc) gestion,
case when exists (select ani from parque_speedy where ani = a.ani) then 'si' else 'no' end sp
into #para_acometer2
from cate..averias a 
	left join #parque p on a.ani = p.ani	
where p.ani is not null and fh_cierre >=@fc
and a.ani not in (select ani from acometidas_final)
group by a.ani, a.tx_tipo_cliente, p.tx_producto,  p.cd_party_titular, p.cd_central, p.cd_manzana,p.tx_calle, p.nu_calle
having count(*)>2

select a.*,e.[contrato desc] contrata, tx_dis_g_g distrito, tx_ger_g_g 
from #para_acometer2 a left join tic.posventa.dbo.dt_central_contrata e on a.cd_central = e.cent
where rtrim(gestion) in ('Falla en Repartidor General',
'Lado Cliente',
'Plantel Exterior',
'Reiterado',
'Retenci�n')
and rtrim(submotivo) in ('M�dem No Sincroniza','Cortes Intermitentes')
and a.tx_producto is not null
and a.tx_tipo_cliente like 'alto%'
and a.cd_central is not null and a.cd_manzana is not null
