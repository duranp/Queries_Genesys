select 'adsl' tx_producto, case when cd_estado_tramite in ('fa','cu','an') then 'cerrado' else 'abierto' end estado, * 
from adsl 
where (fc_cumplimiento >= dbo.pd(getdate()) or fc_cumplimiento is null) and cd_tipo_cliente in('0Q','0P','0H','0C') and cd_motivo_ingreso is null

select 'tb' tx_producto, case when cd_estado_tramite in ('fa','cu','an') then 'cerrado' else 'abierto' end estado, * 
from tb
where (fc_cumplimiento >= dbo.pd(getdate()) or fc_cumplimiento is null) and cd_tipo_cliente in('0Q','0P','0H','0C') 
and cd_producto not like '%p%' and cd_producto not like '%u%' 

select 'voip' tx_producto, case when cd_estado_tramite in ('fa','cu','an') then 'cerrado' else 'abierto' end estado, * 
from tb
where (fc_cumplimiento >= dbo.pd(getdate()) or fc_cumplimiento is null) and cd_tipo_cliente in('0Q','0P','0H','0C') 
and (cd_producto like '%p%' or cd_producto like '%u%')

select 'cambio domicilio' tx_producto, case when cd_estado_tramite in ('fa','cu','an') then 'cerrado' else 'abierto' end estado, * 
from cd
where (fc_cumplimiento >= dbo.pd(getdate()) or fc_cumplimiento is null) and cd_tipo_cliente in('0Q','0P','0H','0C') 

select 'pc' tx_producto, case when cd_estado_tramite in ('fa','cu','an') then 'cerrado' else 'abierto' end estado, * 
from pc
where (fc_cumplimiento >= dbo.pd(getdate()) or fc_cumplimiento is null) and cd_tipo_cliente in('0Q','0P','0H','0C') 

--averias
select case when ani in (select ani from parque_speedy where ani = a.ani) then 'si' else 'no' end tiene_adsl,
case when fh_cierre is not null then 'cerrado' else 'abierto' end estado, 
(select tx_submotivo_contacto from vtv_ave v where ani = a.ani and fc_llamada = dbo.dmy(a.fh_ingreso)
and cd_caso =(select max(cd_caso) from vtv_ave where ani = v.ani and fc_llamada = v.fc_llamada)
) vtv, t.tx_tipo_actuacion apertura_cota,
a.* 
from cate..averias a left join tipo_actuacion t on a.cd_tipo_actuacion_apertura = t.cd_tipo_actuacion
where (fh_cierre >= dbo.pd(getdate()) or fh_cierre is null) and cd_tipo_cliente in('0Q','0P','0H','0C') 





