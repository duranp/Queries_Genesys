select * into vtv_casos from openquery(d,'select SWCASEID, SWCUSTOMERID, CCTMOTIVOID, CCTSUBMOTIVOID, CCTCLASIFICACIONID, SWCREATEDBY, SWDATECREATED, SWDATERESOLVED, SWSTATUS,CCTCERRADOPOR,  CCTTELEFONORECLAMO  from SWBAPPS.SW_case where SWCREATEDBY <> ''CANAL_ONLINE'' AND swdatecreated >= ''01/01/2010''')

drop table #rani
drop table #d
SELECT distinct ani, D.[GRUPO UNIFICADO], d.dictamen_gral, b1.TX_SEGMENTO, case when b1.tx_segmento = b2.tx_segmento then 1 else 0 end mismo
into #d
FROM d09 D 
	LEFT JOIN BO b1 ON D.[GRUPO UNIFICADO] = B1.TX_GRUPO 
	left join bo b2 on D.grupo_ingreso = B2.TX_GRUPO 
where b1.tx_segmento is not null 


select c.*, case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between dateadd(day,1,c.swdateresolved) and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID = 4147 and cctclasificacionid <> 5262 ) then 1 else 0 end r
, D.DICTAMEN_GRAL, d.tx_segmento, [grupo unificado], d.ani, d.mismo
into #rani 
from (select * from vtv_casos where cctmotivoid = 93 AND CCTSUBMOTIVOID = 4146 and swdateresolved between '01/09/2010' and '30/09/2010') c 	
	full JOIN #d D 
		ON D.ANI = C.CCTTELEFONORECLAMO 

select * from #d
select distinct cctdescsubmotivo from vtv_casos v left join submotivo s on v.cctsubmotivoid = s.cctsubmotivoid where v.cctmotivoid = 93

select * from submotivo where cctdescsubmotivo = 'consulta'

select sum(1) from #rani where ani is not null
select * from bo
drop table d09
select * from #d
select * from #rani
select * from d09 d where D.[GRUPO UNIFICADO] is null
SELECT CAST ('30/09/2010' AS DATETIME)
drop table #d
SWBAPPS.CCT_INSTANCIA

select r.swcaseid,r.swdatecreated,* from vtv_casos c
	inner join vtv_casos r on r.ccttelefonoreclamo = c.ccttelefonoreclamo and r.swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and r.swcaseid <> c.swcaseid and r.cctmotivoid = 93 AND r.CCTSUBMOTIVOID = 4147
where c.swcaseid = 10816253








select * from openquery(d,'select * from SWBAPPS.CCT_INSTANCIA where cctcaseid = 10816253.00000')
select * from openquery(d,'select * from SWBAPPS.CCT_INSTANCIA where cctcaseid = 10971725.00000')


select * from d09 where ani = '1146872424'

select * from clasificacion where cctsubmotivoid = 4147 order by cctdescripcion

1146375685
select * from #d


select * from d09
/*

DROP TABLE #RANI
select * from vtv_casos c where 
exists (select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) 
and swdateresolved between '01/07/2010' and '31/07/2010'
and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148
DROP TABLE #RANI

SELECT DISTINCT CCTDESCSUBMOTIVO FROM #RANI R INNER JOIN SUBMOTIVO S ON R.CCTSUBMOTIVOID = S.CCTSUBMOTIVOID

SELECT * FROM SUBMOTIVO WHERE CCTDESCSUBMOTIVO = 'Campa�a'


DROP TABLE #RANI
select c.*, case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) then 1 else 0 end r
, D.DICTAMEN
into #rani 
from vtv_casos c 	LEFT JOIN (SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO) D 
		ON D.ANI = C.CCTTELEFONORECLAMO 
where cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148
and swdateresolved between '01/09/2010' and '30/09/2010'

select month(swdateresolved), sum(r)r,  sum(1)t, DICTAMEN from #rani
group by month(swdateresolved), DICTAMEN
order by month(swdateresolved), DICTAMEN


SELECT *, CASE WHEN EXISTS(SELECT * FROM #RANI WHERE D.ANI = CCTTELEFONORECLAMO AND R=1 AND SWDATECREATED BETWEEN '01/09/2010' AND '30/09/2010') THEN 1 ELSE 0 END R FROM #D D


select top 100 * from vtv_casos


select * from openquery(d,'select * from SWBAPPS.SW_CASE where SWCASEID = 10396917.00000')
select * from openquery(d,'select * from SWBAPPS.SW_CUSTOMER where rownum <100')

select * from vtv_casos c where 
exists (select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93) 

and swdateresolved between '01/09/2010' and '30/09/2010'
and cctmotivoid = 93





SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO


DROP TABLE #RANI
select * from vtv_casos c 
	LEFT JOIN (SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO) D 
		ON D.ANI = C.CCTTELEFONORECLAMO 
where exists 
	(select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) 
and swdateresolved between '01/07/2010' and '31/07/2010'
and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148



SELECT TOP 10 * FROM vtv_casos

select distinct ani, dictamen_gral, [grupo unificado]  from d09 A where ani  in (select ani from d09 where [grupo unificado] <> a.[grupo unificado] and ani = a.ani)
ORDER BY ANI



*/