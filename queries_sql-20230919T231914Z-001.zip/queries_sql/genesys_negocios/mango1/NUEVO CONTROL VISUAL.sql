drop table dom
select * into dom from openquery (dw,'SELECT      DISTINCT
sp.cd_pedido_cliente - 20000000000 cd_pedido_cliente, sp.cd_sub_pedido, sp.cd_central,
                Case
                        When    d.cd_manzana is Null Then t.cd_manzana
                        Else      d.cd_manzana
                End cd_manzana, d.tx_calle, d.nu_calle vl_numero
FROM   tasa.tramites t 
        Inner Join TASA.PRODUCTO p
                On  t.cd_producto = p.cd_producto
        And p.cd_tipo_telefonia=''1''
        Inner Join tasa.sub_pedido sp
                On  t.cd_pedido_cliente = sp.cd_pedido_cliente
                And t.cd_sub_pedido = sp.cd_sub_pedido
        Inner Join tasa.party_tipo_cliente tc
                On  t.cd_tipo_cliente = tc.cd_tipo_cliente
        And tc.cd_unidad_negocio=''PYM''          
        Inner Join tasa.domicilio d
                On  t.cd_localizacion = d.cd_localizacion
WHERE
t.fl_heredado=''N'' 
        AND      t.cd_tipo_tramite IN (1,2, 500,510,512)
        And (t.fc_emision>=''01/01/2010''
        Or   t.fc_cumplimiento is null)
        And
                Case
                        When    d.cd_manzana is Null Then t.cd_manzana
                        Else      d.cd_manzana
                               End      is Not Null')

--traigo vitacora cruzada con parque
select distinct dbo.dmy(timestamp) timestamp, v.tx_usuario, v.cd_manzana, v.cd_central, v.tx_calle, 
case when p.nu_calle is not null then p.nu_calle else cast(v.vl_numero as varchar(10)) end vl_numero, v.r_tb_pe, v.r_tb_pi, v.r_zp, v.r_sp, v.r_voip, v.r_fwt
into visual
from tic.visualizador.dbo.v_vitacora v 
	left join tic.visualizador.dbo.v_parque_tb_sp p on case when len(vl_numero) = 10 then v.vl_numero end = p.ani
where vl_numero not in (99999,8888) and timestamp <dbo.dmy(dbo.pd(getdate()))

/*--
select distinct d.*, case when v.r_tb_pe is null then 1 else 0 end visual
into #t
from visual v right join dom d on v.cd_central = d.cd_central and v.cd_manzana = d.cd_manzana and v.tx_calle = d.tx_calle and d.vl_numero = v.vl_numero
select visual, sum(1) from #t group by visual

drop table #t_dom
drop table #a_dom
drop table #rt_dom
drop table #ra_dom
*/
select * from dom where cd_pedido_cliente = 200531326
--falta de red drop table #fr select * from #fr where cd_pedido_cliente = 200531326
select distinct t.cd_pedido_cliente - 20000000000 cd_pedido_cliente, d.cd_central, d.cd_manzana, d.tx_calle, d.vl_numero
into #fr 
from tb_detalle t left join dom d on t.cd_pedido_cliente - 20000000000 = d.cd_pedido_cliente
where year(fc_entrada) = 2010 and tx_motivo in (select motivo from motivos_red) and cd_estado_detalle = 'in' and fc_emision >= '01/01/2010'
select * from #fr
--cruzo tb con parque drop table #t_dom
select distinct t.*, d.cd_manzana, d.tx_calle, d.vl_numero 
into #t_dom
	from tb t 
		left join dom d on t.cd_pedido_cliente = d.cd_pedido_cliente and t.cd_sub_pedido = d.cd_sub_pedido
where fc_emision >= '01/01/2010'
--cruzo adsl con parque drop table #a_dom
select distinct t.*, d.cd_manzana, d.tx_calle, d.vl_numero 
into #a_dom
	from adsl t 
		left join dom d on t.cd_pedido_cliente = d.cd_pedido_cliente and t.cd_sub_pedido = d.cd_sub_pedido
where fc_emision >= '01/05/2010'



--1er aproximacion tb drop table #rt_dom select sum(1) from #rt_dom
select distinct t.*, case when v.r_tb_pe is not null then 1 else 0 end visual, case when r_tb_pe = 'no' or r_tb_pi = 'no'  then 'no' when r_tb_pe is null then 'sd' else 'si' end r_tb,
case when f.cd_central is not null then 1 else 0 end fr
into #rt_dom
from #t_dom t 
	left join visual v on v.cd_central = t.cd_central and v.cd_manzana = t.cd_manzana and v.tx_calle = t.tx_calle and t.vl_numero = v.vl_numero and t.fc_emision between v.timestamp and dateadd(day,10,timestamp)
	left join #fr f on v.cd_central = f.cd_central and v.cd_manzana = f.cd_manzana and v.tx_calle = f.tx_calle and f.vl_numero = v.vl_numero 
where fc_emision >= '01/05/2010' and t.vl_numero is not null

--1er aproximacion adsl drop table #ra_dom
select distinct t.*, case when v.r_tb_pe is not null then 1 else 0 end visual
into #ra_dom
from #a_dom t 
	left join visual v on v.cd_central = t.cd_central and v.cd_manzana = t.cd_manzana and v.tx_calle = t.tx_calle and t.vl_numero = v.vl_numero and t.fc_emision between v.timestamp and dateadd(day,10,timestamp)
where fc_emision >= '01/05/2010' and t.vl_numero is not null

select 'tb' prod,cd_estado_tramite, visual,r_tb, sum(1) from #rt_dom where fc_cumplimiento is not null group by visual,cd_estado_tramite, r_tb
union all
select 'adsl' prod,cd_estado_tramite, visual, sum(1) from #ra_dom where fc_cumplimiento is not null group by visual,cd_estado_tramite

--drop table #visual_cota
select distinct v.*, case when a.cd_central is not null or t.cd_Central is not null then 1 else 0 end cota, case when f.cd_central is not null then 1 else 0 end fr
into #visual_cota
	from visual v 
		left join #t_dom t on v.cd_central = t.cd_central and v.cd_manzana = t.cd_manzana and v.tx_calle = t.tx_calle and t.vl_numero = v.vl_numero and t.fc_emision between v.timestamp and dateadd(day,10,timestamp)
		left join #a_dom a on v.cd_central = a.cd_central and v.cd_manzana = a.cd_manzana and v.tx_calle = a.tx_calle and a.vl_numero = v.vl_numero and a.fc_emision between v.timestamp and dateadd(day,10,timestamp)
		left join #fr f on v.cd_central = f.cd_central and v.cd_manzana = f.cd_manzana and v.tx_calle = f.tx_calle and f.vl_numero = v.vl_numero 
where timestamp >= dateadd(day,-15,'01/05/2010')

select distinct * from visual where timestamp >= dateadd(day,-15,'01/05/2010')

select * from #fr

select visual, r_tb, fr, cd_estado_tramite, sum(1) from #rt_dom where fc_cumplimiento is not null group by visual, r_tb, fr, cd_estado_tramite

select * from openquery(dw,'select * from tasa.tramites where cd_pedido_cliente = ''020175863286''')
select * from dom where cd_pedido_cliente = 175863286 


DROP TABLE #R
SELECT DISTINCT A.*, CASE WHEN B.CD_PEDIDO_CLIENTE IS NOT NULL THEN 1 ELSE 0 END R 
INTO #R
FROM #T_DOM A 
	LEFT JOIN #T_DOM B ON A.CD_CENTRAL = B.CD_CENTRAL AND A.CD_MANZANA = B.CD_MANZANA AND A.TX_CALLE = B.TX_CALLE AND A.VL_NUMERO = B.VL_NUMERO
		AND (A.FC_EMISION BETWEEN B.FC_CUMPLIMIENTO AND DATEADD(DAY,35,B.FC_CUMPLIMIENTO) OR A.FC_EMISION BETWEEN B.FC_EMISION AND B.FC_CUMPLIMIENTO)
		AND A.CD_PEDIDO_CLIENTE <> B.CD_PEDIDO_CLIENTE
	INNER JOIN VISUAL V on v.cd_central = A.cd_central and v.cd_manzana = A.cd_manzana and v.tx_calle = A.tx_calle and A.vl_numero = v.vl_numero and A.fc_emision between v.timestamp and dateadd(day,10,timestamp)

SELECT MONTH(FC_EMISION) MES, R, SUM(1) FROM #R GROUP BY MONTH(FC_EMISION), R ORDER BY MONTH(FC_EMISION), R 

select sum(case when r_tb_pe = 'no' or r_tb_pi = 'no' then 1 else 0 end), sum(1) from visual

SELECT CD_CENTRAL,CD_MANZANA, TX_CALLE, VL_NUMERO, SUM(1) FROM #T_DOM GROUP BY  CD_CENTRAL,CD_MANZANA, TX_CALLE, VL_NUMERO
HAVING SUM(1) > 1

drop table #ra
select distinct a.*, case when b.ani is not null then 1 else 0 end r
into #ra
from adsl a 
	left join adsl b 
		on a.ani = b.ani and a.cd_pedido_cliente <> b.cd_pedido_cliente and (a.fc_emision between b.fc_cumplimiento and dateadd(day,35, b.fc_cumplimiento) or a.fc_emision between b.fc_emision and b.fc_cumplimiento)
where year(a.fC_emision) = 2010

SELECT MONTH(FC_EMISION) MES, R, SUM(1) FROM #Ra GROUP BY MONTH(FC_EMISION), R ORDER BY MONTH(FC_EMISION), R 

select year(fC_cumplimiento), month(fc_cumplimiento), sum(case when tx_motivo_canc like 'wf%' then 1 else 0 end) wf, sum(1) from adsl 
where   year(fc_cumplimiento) >= 2009 and cd_estado_tramite = 'an' 
group by year(fC_cumplimiento), month(fc_cumplimiento)
order by year(fC_cumplimiento), month(fc_cumplimiento)





