select * from analisis..intenciones

select distinct 
isnull(a.tx_agente_externo,a.tx_canal_venta) canal_adsl, a.fc_cumplimiento fc_adsl, 
isnull(t.tx_agente_externo,t.tx_canal_venta) canal_tb, t.fc_cumplimiento fc_tb,
isnull(a.tx_agente_externo,a.tx_canal_venta) canal_voip, a.fc_cumplimiento fc_voip,
v.*
from analisis..intenciones v 
	left join adsl a 
		on v.cd_party = a.cd_party 
			and a.fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha and a.cd_estado_tramite in ('fa','cu')
			and a.fc_cumplimiento = (select max(fc_cumplimiento) from adsl where cd_party = a.cd_party and fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha and cd_estado_tramite in ('fa','cu'))
	left join tb   t 
		on v.cd_party = t.cd_party 
			and t.fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha 
			and t.cd_estado_tramite in ('fa','cu')
			and t.cd_producto not in ('02100000000P7','02100000000P4')
			and t.fc_cumplimiento = (select max(fc_cumplimiento) from tb where cd_party = t.cd_party and fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha and cd_estado_tramite in ('fa','cu') and cd_producto not in ('02100000000P7','02100000000P4'))
	left join tb   vo 
		on v.cd_party = vo.cd_party 
			and vo.fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha 
			and vo.cd_estado_tramite in ('fa','cu')
			and vo.cd_producto in ('02100000000P7','02100000000P4')
			and vo.fc_cumplimiento = (select max(fc_cumplimiento) from tb where cd_party = vo.cd_party and fc_cumplimiento between dateadd(month,-14,v.fecha) and v.fecha and cd_estado_tramite in ('fa','cu') and cd_producto in ('02100000000P7','02100000000P4'))
order by v.cd_party

select * from parque_basica where rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea = '1146694482'
select distinct cd_producto from tb where cd_producto like '%p%'

