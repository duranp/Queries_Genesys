select 
t.cd_unidad_negocio,
sum(case when datediff(hour, fH_INGRESO, fh_cierre) between 0 and 48 then 1 else 0 end) '0-48',
sum(case when datediff(hour, fH_INGRESO, fh_cierre) between 49 and 72 then 1 else 0 end) '49-72',
sum(case when datediff(hour, fH_INGRESO, fh_cierre) between 73 and 96 then 1 else 0 end) '73-96',
sum(case when datediff(hour, fH_INGRESO, fh_cierre) between 97 and 120 then 1 else 0 end) '97-120',
sum(case when datediff(hour, fH_INGRESO, fh_cierre) > 120 then 1 else 0 end) '>120',
count(*) tot,
month(fh_cierre),year(fh_cierre)
from cate..averias a inner join posventa.dbo.dt_tipo_cliente t on  a.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio in ('pca','pnc')
where year(fh_cierre)>= 2009
group by 
month(fh_cierre),year(fh_cierre),t.cd_unidad_negocio
order by 
t.cd_unidad_negocio,year(fh_cierre), month(fh_cierre)

