select * from tb t 
	inner join tb v 
		on t.cd_pedido_cliente = v.cd_pedido_cliente --and t.cd_sub_pedido <> v.cd_sub_pedido
		and t.cd_producto not in ('02100000000P7','02100000000P4','02100000000U4','02100000000U5')
		and v.cd_producto in ('02100000000P7','02100000000P4','02100000000U4','02100000000U5')
	inner join adsl a on a.cd_pedido_cliente = t.cd_pedido_cliente and a.cd_sub_pedido = t.cd_sub_pedido


select * from tb where cd_pedido_cliente = 135130956
select * from adsl where cd_pedido_cliente = 135130956

--select distinct cd_producto from tb t where t.cd_producto like '%p%' or t.cd_producto like '%u%'
select max(fc_cumplimiento),cd_estado_tramite from adsl group by cd_estado_tramite
select max(fc_cumplimiento),cd_estado_tramite from tb group by cd_estado_tramite

SELECT * FROM OPENQUERY(DW,'SELECT * FROM TASA.PARTY_TIPO_CLIENTE')
