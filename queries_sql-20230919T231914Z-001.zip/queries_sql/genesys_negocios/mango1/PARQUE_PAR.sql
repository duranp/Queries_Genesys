drop table parque_par
select * into parque_par from openquery(dw,
	'Select	Distinct	rtrim(cd_interurbano)||rtrim(cd_urbano)||cd_linea ani, pa.nu_longitud_linea, pa.fc_cambio fc_cambio_pa, r.fc_cambio fc_cambio_pr, r.*
	From	tasa.producto_instancia_red r 
	Inner Join tasa.service_number s
		On	r.cd_producto_instancia = s.cd_producto_instancia
	inner join tasa.producto_instancia pi on
			r.cd_producto_instancia = pi.cd_producto_instancia and pi.fc_baja is null
	Left Join tasa.prefa_adsl_par pa
		On	pa.cd_manzana_central = r.cd_manzana_central
		And	pa.cd_manzana = r.cd_manzana
		And	pa.cd_cable_central = r.cd_cable_central
		And	pa.cd_cable = pa.cd_cable
		And	pa.cd_par_primario = r.cd_par_primario
Where	s.fc_final is Null
	And	r.fc_cambio = (
Select	max(fc_cambio)
From	tasa.producto_instancia_red
Where	cd_producto_instancia = r.cd_producto_instancia)')

drop table parque_par2
select * into parque_par2 from parque_par p where (fc_cambio_pa = (select max(fc_cambio_pa) from parque_par where ani = p.ani) and fc_cambio_pa> fc_cambio_pr)or fc_cambio_pa is null

select ani, sum(1) from parque_par2 group by ani having sum(1) >1
select sum(1) from parque_par 
select sum(1) from parque_par2

select * from parque_par2 where ani = '1143222041'

select * from pc where cd_pedido_cliente = '196191470'
select * from pc where cd_producto_es = '0220000044618'









delete from parque_par where cd_manzana_central is null

select cd_manzana_central, cd_cable, cd_cable_central, cd_par_primario, cd_par_secundario, sum(1) 
from parque_par 
where cd_par_primario is not null and cd_cable is not null and cd_canal_nro is null
group by cd_manzana_central, cd_cable, cd_cable_central, cd_par_primario, cd_par_secundario
having sum(1) >1

select * from parque_par 
where
cd_manzana_central = 328 and
cd_cable =13 and 
cd_cable_central =328 and
cd_par_primario = 450


600	6	600	653
select * from voip_madre_hija where ani_hija = '2355431646'

select sum(1) from parque_par where cd_canal_nro is not null
select * from tic.visualizador.dbo.v_parque_tb_sp where ani in (
2204922121,
2204922141)

select * from parque_basica where rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea in 
(2355430149,
2355431646,
2355430772,
2355431800)


select ani, sum(1) from parque_par group by ani having sum(1) >1

select * from parque_par where ani = 2214501061



select 
(select case when exists(select ani from cate..averias where ani = a.ani and fh_cierre between dateadd(day,-30,a.fh_ingreso) and fh_ingreso) then 'si' else 'no' end) r_ani,
(select case when exists(select ani from cate..averias where cd_party_titular = a.cd_party_titular and fh_cierre between dateadd(day,-30,a.fh_ingreso) and fh_ingreso) then 'si' else 'no' end) r_party,
a.*
from cate..averias a 
where year(fh_cierre) = 2010

