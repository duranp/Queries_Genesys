
create procedure sp_iol_fuera
as
--defino motivos comerciales
set nocount OFF
SELECT * INTO #MC FROM INDICADORES.ANALISIS.DBO.MOTIVOS_adsl WHERE CD_IMPLICANCIA = 'C'
union all
select * from INDICADORES.ANALISIS.DBO.MOTIVOS_tb WHERE CD_IMPLICANCIA = 'C'
delete from #mc where tx_motivo in (select motivo from indicadores.posventa.dbo.motivos_red)

--marco pedidos con gestiones iol
select distinct p.cd_pedido, p.cd_sub_pedido 
into #IOL
from pgc_pendientes p 
	inner join pgc_estados e
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
		and (e.tx_g_resultado like '%(aei)%' or e.tx_g_motivo_real like '%(aei)%')
	
set nocount ON		
--vista final
select p.*, m.tx_motivo, e.tx_central, e.tx_distrito_atc, e.tx_gerencia from pgc_pendientes p 
	inner join dt_motivo m 
		on p.cd_motivo = m.cd_motivo and p.tx_estado = 'informado' and m.tx_motivo in (select tx_motivo from #mc)
	inner join dt_estructura e on p.cd_central = e.cd_central
	inner join dt_tipo_cliente t on p.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio in ('pca','pnc')
where 
p.cd_pedido not in (select cd_pedido from #iol where cd_pedido = p.cd_pedido) 
and cd_producto_pgc not like '%otros%' 
and fc_informado >= '12/04/2010'
order by cd_pedido, cd_sub_pedido, cd_tramite, cd_producto_pgc

drop table #mc
drop table #iol
go



use posventa
declare @sql as varchar(60)
declare @path as varchar(50)
declare @canal as varchar(20)
set @sql = 'exec sp_iol_fuera '
--exec(@sql)
set @path = 'c:\IOL_no_trabajados_' + replace(convert(varchar(12),getdate(),103),'/','')+ '.xls'
	--creo el excel
	EXEC sp_makewebtask @outputfile = @path , @query = @sql, @colheaders =1, 
		@FixedFont=0,@lastupdated=0,@resultstitle = 'IOL - No trabajados'
	--envio el mail
	exec master..xp_sendmail 
		@recipients='ozane@telefonica.com.ar; ametllac@telefonica.com.ar; Mangisch Sebastian;', 
		@attachments = @path, @subject='IOL - No trabajados (auto)',
		@message='Gente, Les paso los pedidso informados comerciales que no tuvieron gestion de IOL.
Atte,
Sebastian A. Mangisch
TE 11-4333-1540'




drop table BORRAR_INFORMADOS_PEGASO
select p.cd_pedido, p.cd_sub_pedido, p.cd_tramite, p.cd_producto_pgc, e.timestamp, M.TX_MOTIVO
INTO BORRAR_INFORMADOS_PEGASO
from pgc_pedidos p 
	inner join vw_pgc_estados e
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
	INNER JOIN DT_MOTIVO M
		ON E.CD_MOTIVO = M.CD_MOTIVO
where 
e.cd_usuario in ('cota') and e.tx_estado_pgc = 'informado' and p.cd_producto_pgc in ('ADSL', 
'EQ VOIP',
'CAM24',
'FWT',
'LAN OFFICE',
'MIGR LAN',
'MIGR VOIP',
'PC',
'PDTI',
'SFT-MUSICA',
'SPD READY',
'TB',
'TB MP',
'VOIP',
'VPN'
)

select * from pgc_pendientes where cd_pedido = '188896112'

select * from BORRAR_INFORMADOS_PEGASO where tb_producto_pgc in ('tb','tb mp')