--bajop discoverer
use vtv
DROP TABLE VTv_casos
delete from vtv_casos where swdatecreated >= dbo.dmy(dbo.pd(dateadd(month,-1,getdate())))
insert into vtv_casos select * from openquery(d,'select SWCASEID, SWCUSTOMERID, CCTMOTIVOID, CCTSUBMOTIVOID, CCTCLASIFICACIONID, CCTSOLUCIONID, SWCREATEDBY, SWDATECREATED, SWDATERESOLVED, SWSTATUS,CCTCERRADOPOR,  CCTTELEFONORECLAMO  from SWBAPPS.SW_case where SWCREATEDBY <> ''CANAL_ONLINE'' AND swdatecreated >= concat(concat(concat(''01/'',to_char(extract( month from add_months(sysdate,-1)))),''/''),to_char(extract(year from add_months(sysdate,-1))))')


--creo tabla calculada drop table #t
select  m, s, cl, sl, dia, sum(fcr2) fcr2, sum(fcr7) fcr7, sum(1) q 
into #t
from 
(select m.cctdescripcion m, s.cctdescsubmotivo s, cl.cctdescripcion cl, sl.cctdescripcion sl, dbo.dmy(swdatecreated) dia,
case when exists(select swcaseid from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swcaseid <> c.swcaseid and swdatecreated between c.swdatecreated and dateadd(day,7,c.swdatecreated)) then 1 else 0 end fcr7,
case when exists(select swcaseid from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swcaseid <> c.swcaseid and swdatecreated between c.swdatecreated and dateadd(day,2,c.swdatecreated)) then 1 else 0 end fcr2
from vtv_casos c 
	left join motivo m on c.cctmotivoid = m.cctmotivoid 
	left join submotivo s on c.cctsubmotivoid = s.cctsubmotivoid  
	left join clasificacion cl on c.cctCLASIFICACIONid = cl.cctCLASIFICACIONid 
	left join clasificacion Sl on c.cctSOLUCIONid = Sl.cctCLASIFICACIONid
where m.CCTMOTIVOID <>0 and swdatecreated between '01/09/2010' and '01/12/2010')x
group by  m, s, cl, sl, dia
select max(swdatecreated) from vtv_casos
select * from #t

declare @r as int
set @r = 0
select month(dia)mes,sum(q), sum(fcr2)f2, sum(fcr7)f7,m,s,cl,sl, left(dia,@r) t from #t 
--WHERE M = 'aver�as' and dia between '01/09/2010' and '30/11/2010'
group by month(dia),m,s,cl,sl, left(dia,@r) 
order by month(dia),m,s,cl,sl, left(dia,@r) 

select * from vtv_casos where cctclasificacionid = 13633
select * from openquery(d,'select * from SWBAPPS.SW_case where cctclasificacionid = 13633 and swdatecreated >= ''01/01/2009''')
select  min(swdatecreated) from vtv_casos

select 






select * from #t where m is null



select * from openquery(d,'select sum(1) from SWBAPPS.SW_case where swdatecreated >= concat(concat(concat(''01/'',to_char(extract( month from add_months(sysdate,-1)))),''/''),to_char(extract(year from add_months(sysdate,-1))))')
select * from openquery(d,'select to_date(''01/1/2010'') a from dual')


	select * from CLASIFICACION

select suM(1), count(distinct cctclasificacionid) from clasificacion

select * from sys.objects

