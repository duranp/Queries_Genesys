--create user
I_USUARIOS_LOGIN 'nico','nico',9999

declare @usuario as varchar(50)
declare @mail as varchar(50)

set @usuario	= 'mango'
set @mail		= 'mangiscs@telefonica.com.ar'

exec I_USUARIOS_INSERT 1223, '9297FE6E-61D6-4936-B5C9-101E074A1AB4', @usuario, @mail, 1, 1, 1
	

--change pass
I_USUARIOS_LOGIN 'nico','nico',777

i_usuarios_password 1256, '52445E19-E1EB-4798-A0CE-737F12E14F22', 'masnuevo', 'nuevo'

--reset pass
dbo.I_USUARIOS_RESET 1351, '758C169A-C60F-488B-9A60-74F318B1D40C', 13 --25 es mango

UPDATE usuarios  SET TX_MAIL = 'gnm@argennet.com' WHERE CD_USUARIO = 15

SELECT * FROM USUARIOS

select * from BCP_manzanero where isnumeric(nu_desde) = 0


