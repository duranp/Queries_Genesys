							--ADSL MONO
--tmi, instalaciones en plazo
select 
month(a.fc_cumplimiento) mes,
avg(cast(datediff(day, a.fc_emision, a.fc_cumplimiento) as real)) tmi, count(*) inst,
sum(case when datediff(day, a.fc_emision, a.fc_cumplimiento) <=10 then 1 else 0 end) dentro,
sum(case when datediff(day, a.fc_emision, a.fc_cumplimiento) >10 then 1 else 0 end) fuera,
cast(sum(case when datediff(day, a.fc_emision, a.fc_cumplimiento) <=10 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from adsl a left join tb t on a.cd_pedido_cliente = t.cd_pedido_cliente
inner JOIN dt_tipo_cliente tc on tc.cd_tipo_cliente = a.cd_tipo_cliente and cd_unidad_negocio in ('pca', 'pnc')			
where 
a.CD_ESTADO_TRAMITE IN ('FA', 'CU')
and year(a.fc_cumplimiento) = year(getdate())
AND a.tx_prod_adsl <> 'cam24'
and t.cd_pedido_cliente is null
and cd_motivo_ingreso is null 
group by month(a.fc_cumplimiento)
order by month(a.fc_cumplimiento)

--averias en garantia
select 
case	when tc.cd_unidad_negocio = 'pnc' and Tc.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when tc.cd_unidad_negocio = 'pnc' and Tc.tx_tipo_cliente NOT like 'ALTO VALOR%' then 'NO CART' 
ELSE 'CART' END,
month(V.fc_cumplimiento) mes,
sum(case when a.cd_averia is not null then 1 else 0 end) 'si',
sum(case when a.cd_averia is null then 1 else 0 end) 'no',
cast(sum(case when a.cd_averia is NOT null then 1 else 0 end) as real)/ cast(count(*) as real)*100 '%_av_gtia',
count(*)
from adsl v 
	left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
	left join tb t on V.cd_pedido_cliente = t.cd_pedido_cliente
	inner JOIN dt_tipo_cliente tc on v.cd_tipo_cliente = tc.cd_tipo_cliente and tc.cd_unidad_negocio in ('pca', 'pnc')	
where 
V.CD_ESTADO_TRAMITE IN ('FA', 'CU')
and year(V.fc_cumplimiento) = year(getdate())
AND V.tx_prod_adsl <> 'cam24'
AND T.CD_PEDIDO_CLIENTE IS NULL
group by 
case	when tc.cd_unidad_negocio = 'pnc' and Tc.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when tc.cd_unidad_negocio = 'pnc' and Tc.tx_tipo_cliente NOT like 'ALTO VALOR%' then 'NO CART' 
ELSE 'CART' END, month(V.fc_cumplimiento) 