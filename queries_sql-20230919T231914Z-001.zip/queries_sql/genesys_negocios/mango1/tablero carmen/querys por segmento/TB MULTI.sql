use posventa	
--TB multi
--tmi, instalaciones en plazo
select 
case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END  'T_CLIENTE',
month(t.fc_cumplimiento) mes,
avg(cast(datediff(day, t.fc_emision, t.fc_cumplimiento) as real)) tmi, count(*) inst,
sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) <=7 then 1 else 0 end) dentro,
sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) >7 then 1 else 0 end) fuera,
cast(sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) <=7 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from tb t left join adsl a on t.cd_pedido_cliente = a.cd_pedido_cliente and a.cd_motivo_ingreso is null
	inner JOIN dt_tipo_cliente tc on t.cd_tipo_cliente = tc.cd_tipo_cliente and cd_unidad_negocio in ('pca', 'pnc')
where 
t.cd_estado_tramite in('fa', 'cu')
and year(t.fc_cumplimiento) = year(getdate())
and a.cd_pedido_cliente is not null
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
 END, month(t.fc_cumplimiento)
order by case	
		when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(t.fc_cumplimiento)


-- TRA
select 
case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END cliente,
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a inner JOIN dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and cd_unidad_negocio in ('pca', 'pnc')
where 
year(fh_cierre) = year(getdate())
and cd_tipo_actuacion_cierre not in (334,344)
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)
order by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)
