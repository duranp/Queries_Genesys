							--TB
--tmi, instalaciones en plazo select * from dt_tipo_cliente
select 
case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
END 'T_CLIENTE',
month(fc_cumplimiento) mes,
avg(cast(datediff(day,fc_emision, fc_cumplimiento) as real)) tmi, count(*) inst,
sum(case when datediff(day,fc_emision, fc_cumplimiento) <=7 then 1 else 0 end) dentro,
sum(case when datediff(day,fc_emision, fc_cumplimiento) >7 then 1 else 0 end) fuera,
cast(sum(case when datediff(day,fc_emision, fc_cumplimiento) <=7 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from tb v inner join dt_tipo_cliente t on v.cd_tipo_cliente = t.cd_tipo_cliente
where 
cd_estado_tramite = 'fa' 
and year(fc_cumplimiento) = year(getdate())
group by case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
END, month(fc_cumplimiento)
order by case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
END, month(fc_cumplimiento)





--reiterados
select case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' 
END  cd_undidad_negocio, month(fh_cierre) mes, count(*), count(distinct ani) 
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = year(getdate())
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre) 

-- TRA
select 
case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END cliente,
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where 
year(fh_cierre) = year(getdate())
and cd_tipo_actuacion_cierre not in (334,344)
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)
order by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)