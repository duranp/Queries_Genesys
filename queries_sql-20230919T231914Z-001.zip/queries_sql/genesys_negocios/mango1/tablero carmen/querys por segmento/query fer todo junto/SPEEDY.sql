							--sPEEDY
--tmi, instalaciones en plazo
select 
month(fc_cumplimiento) mes,
avg(cast(datediff(day,fc_emision,fc_Cumplimiento) as real)) tmi, count(*) inst,
sum(case when cast(datediff(day,fc_emision,fc_Cumplimiento) as real)  <=10 then 1 else 0 end) dentro,
sum(case when cast(datediff(day,fc_emision,fc_Cumplimiento) as real)  >10 then 1 else 0 end) fuera,
cast(sum(case when cast(datediff(day,fc_emision,fc_Cumplimiento)as real )  <=10 then 1 else 0 end) as real)     /cast(count(*) as real)*100 '%_dentro'
from adsl
where 
cd_estado_tramite in ('fa','cu') and cd_motivo_ingreso is null 
and year(fc_cumplimiento) = year(getdate())
AND tx_prod_adsl = 'speedy'
group by month(fc_cumplimiento)
order by month(fc_cumplimiento)


--averias en garantia
select month(fc_cumplimiento) mes,
sum(case when a.cd_averia is not null then 1 else 0 end) 'si',
sum(case when a.cd_averia is null then 1 else 0 end) 'no',
cast(sum(case when a.cd_averia is NOT null then 1 else 0 end) as real)/ cast(count(*) as real)*100 '%_av_gtia',
count(*)
from v_adsl v left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
where 
tx_estado_tramite = 'facturado' 
and year(fc_cumplimiento) = year(getdate())
and v.tx_producto = 'speedy'
group by month(fc_cumplimiento) 


--PARQUE ADSL
select 
case 	when tx_producto like '%lan%' then 'LAN' 
	when tx_producto like '%cam%'then 'CAM' 
else 'SPEEDY' END TX_PRODUCTO,
COUNT(*)
from parque_speedy where TX_PRODUCTO NOT LIKE 'MEGA%'
GROUP BY 
case 	when tx_producto like '%lan%' then 'LAN' 
	when tx_producto like '%cam%'then 'CAM' 
else 'SPEEDY' END


--AVERIAS POR PRODUCTO - ADSL
SELECT 
COUNT(*),
MONTH(FH_CIERRE) MES, 
case 	when P.tx_producto like '%lan%' then 'LAN' 
	when P.tx_producto like '%cam%'then 'CAM' 
else 'SPEEDY' END PRODUCTO 
FROM CATE..AVERIAS A INNER JOIN PARQUE_SPEEDY P 
	ON A.ANI = P.ANI and p.TX_PRODUCTO NOT LIKE 'MEGA%'
WHERE YEAR(FH_CIERRE) = YEAR(GETDATE())
GROUP BY 
MONTH(FH_CIERRE), 
case 	when P.tx_producto like '%lan%' then 'LAN' 
	when P.tx_producto like '%cam%'then 'CAM' 
else 'SPEEDY' END
ORDER BY
case 	when P.tx_producto like '%lan%' then 'LAN' 
	when P.tx_producto like '%cam%'then 'CAM' 
else 'SPEEDY' END, MONTH(FH_CIERRE) 

--				speedy
-- TRA
select 
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a 
inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
inner join parque_speedy p on a.ani = p.ani and 
p.tx_producto not like '%LAN%' and p.tx_producto not like '%cam%' and p.tx_producto not like 'mega%'
where 
year(fh_cierre) = year(getdate())
and cd_tipo_actuacion_cierre not in (334,344)
group by month(fh_cierre)
order by month(fh_cierre)

--reiterados
select month(fh_cierre) mes, count(*), count(distinct ani) 
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = 2008
group by month(fh_cierre) 



CREATE view v_adsl as
select distinct replace(cast([cd_interurbano] as varchar(10))+cast([cd_urbano] as varchar(10))+cast([cd_linea] as varchar(10)),' ','') as ani,[Cd_Pedido_Cliente], [CD_SUB_PEDIDO], [cd tramite],
case [tx_estado_tramite] when 'CUMPLIDO' then 'FACTURADO'
		WHEN NULL THEN NULL
		  else [tx_estado_tramite]
end [tx_estado_tramite], tx_agente_externo, CD_CENTRAL
,[Tx_Canal_venta], [Fc_Emision],[tx_tipo_cliente],   [Fc_Cumplimiento], [Fc_Libramiento],[Cd_Interurbano], [Cd_Urbano],[Cd_Linea], [Fc_Contratacion], datediff(day,[fc_emision],[fc_cumplimiento]) as ti, tx_motivo_canc,
case when tx_razon_social is null then tx_nombre + ' ' + tx_apellido else tx_razon_social end tx_razon_social, cd_party,
case 	when tx_producto like '%WI-FI%' then 'LAN OFFICE'
	WHEN TX_PRODUCTO like '%MODEM ADSL 4 BOCAS%' THEN 'CAM24'
	ELSE 'SPEEDY' END TX_PRODUCTO
FROM adsl_detalle
where [tx_producto] not like 'CAMARA%'
and fc_cumplimiento is not null


SP_HELPTEXT 'V_CAM24'
SP_HELPTEXT 'V_LAN'