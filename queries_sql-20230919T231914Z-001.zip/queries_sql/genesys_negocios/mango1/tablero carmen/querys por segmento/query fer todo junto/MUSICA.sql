							--PC
--tmi, instalaciones en plazo
select 
month(fc_cumplimiento) mes,
avg(cast(DATEDIFF(DAY,FC_EMISION, FC_CUMPLIMIENTO) as real)) tmi, count(*) inst,
sum(case when DATEDIFF(DAY,FC_EMISION, FC_CUMPLIMIENTO) <=10 then 1 else 0 end) dentro,
sum(case when DATEDIFF(DAY,FC_EMISION, FC_CUMPLIMIENTO) >10 then 1 else 0 end) fuera,
cast(sum(case when DATEDIFF(DAY,FC_EMISION, FC_CUMPLIMIENTO) <=10 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from musica
where 
CD_estado_tramite = 'fa' 
and year(fc_cumplimiento) = year(getdate()) AND CD_TIPO_TRAMITE IN (3, 502)
group by month(fc_cumplimiento)
order by month(fc_cumplimiento)


--averias en garantia
select month(fc_cumplimiento) mes,
sum(case when a.cd_averia is not null then 1 else 0 end) 'si',
sum(case when a.cd_averia is null then 1 else 0 end) 'no',
cast(sum(case when a.cd_averia is NOT null then 1 else 0 end) as real)/ cast(count(*) as real)*100 '%_av_gtia',
count(*)
from musica v left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
where 
CD_estado_tramite = 'FA' 
and year(fc_cumplimiento) = year(getdate())
group by month(fc_cumplimiento) 


--PARQUE PC
select COUNT(*)from parque_PC WHERE FC_BAJA IS NULL

--AVERIAS POR PRODUCTO - PC
SELECT MONTH(FH_CIERRE), COUNT(*)
FROM CATE..AVERIAS A INNER JOIN PARQUE_PC P 
	ON A.ANI = P.ANI 
WHERE YEAR(FH_CIERRE) = YEAR(GETDATE())
GROUP BY 
MONTH(FH_CIERRE)
ORDER BY
MONTH(FH_CIERRE) 

--				TB
-- TRA
select 
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a 
inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
inner join parque_PC p on a.ani = p.ani 
where 
year(fh_cierre) = year(getdate())
and cd_tipo_actuacion_cierre not in (334,344)
group by month(fh_cierre)
order by month(fh_cierre)

--reiterados
select month(fh_cierre) mes, count(*), count(distinct A.ani) 
from cate..averias a 
	inner join dt_tipo_cliente t 
		on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
	INNER JOIN PARQUE_SPEEDY P 
		ON A.ANI = P.ANI and p.TX_PRODUCTO NOT LIKE 'MEGA%'
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = 2008
group by month(fh_cierre) 

