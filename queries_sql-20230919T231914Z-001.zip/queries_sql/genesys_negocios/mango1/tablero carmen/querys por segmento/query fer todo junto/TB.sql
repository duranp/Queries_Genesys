							--TB
--tmi, instalaciones en plazo
select 
month(fc_cumplimiento) mes,
avg(cast(datediff(day,fc_emision, fc_cumplimiento) as real)) tmi, count(*) inst,
sum(case when datediff(day,fc_emision, fc_cumplimiento) <=7 then 1 else 0 end) dentro,
sum(case when datediff(day,fc_emision, fc_cumplimiento) >7 then 1 else 0 end) fuera,
cast(sum(case when datediff(day,fc_emision, fc_cumplimiento) <=7 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from tb 
where 
cd_estado_tramite = 'fa' 
and year(fc_cumplimiento) = year(getdate())
group by month(fc_cumplimiento)
order by month(fc_cumplimiento)


--averias en garantia
select month(fc_cumplimiento) mes,
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END 'T_CLIENTE',
sum(case when a.cd_averia is not null then 1 else 0 end) 'no',
sum(case when a.cd_averia is null then 1 else 0 end) 'si',
cast(sum(case when a.cd_averia is NOT null then 1 else 0 end) as real)/ cast(count(*) as real)*100 '%_av_gtia',
count(distinct v.ani)
from tb v left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
where 
cd_estado_tramite = 'fa' --and v.tx_producto = 'cam24'
--and (v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%')
and year(fc_cumplimiento) = year(getdate())
group by month(fc_cumplimiento),
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END
ORDER BY month(fc_cumplimiento),
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END

/*
select month(fc_cumplimiento) mes,
sum(case when a.cd_averia is not null then 1 else 0 end) 'si',
sum(case when a.cd_averia is null then 1 else 0 end) 'no',
count(*)
from tb v left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
where 
cd_estado_tramite = 'fa' --and v.tx_producto = 'cam24'
--and (v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%')
and year(fc_cumplimiento) = year(getdate())
group by month(fc_cumplimiento) 
*/


--PARQUE BASICA
select count(*), cd_unidad_negocio from parque_basica P LEFT JOIN dt_tipo_cliente t on p.cd_tipo_cliente = t.cd_tipo_cliente
group by cd_unidad_negocio 

--				TB
SELECT COUNT(*), cd_unidad_negocio,
MONTH(FH_CIERRE) MES
FROM CATE..AVERIAS a
inner JOIN dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and cd_unidad_negocio in ('pca', 'pnc')
WHERE YEAR(FH_CIERRE) = YEAR(GETDATE()) 
GROUP BY 
MONTH(FH_CIERRE), cd_unidad_negocio
order BY 
MONTH(FH_CIERRE), cd_unidad_negocio

-- TRA
select 
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where 
year(fh_cierre) = year(getdate())
and cd_tipo_actuacion_cierre not in (334,344)
group by month(fh_cierre)
order by month(fh_cierre)

--reiterados
select month(fh_cierre) mes, count(*), count(distinct ani) 
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = 2009
group by month(fh_cierre) 

