use cate
delete from dapplicationstat
insert into  dapplicationstat select * from 
OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04',
'select * from dApplicationStat') 
WHERE  year(timestamp)=2009 and 
month(timestamp)=12 and 
applicationid in (select applicationid from aplicacion where skill is not null)
