 --sa inner join Agent a on sa.UserID = a.UserID inner join Skillset s on sa.SkillsetID = s.SkillsetID')
drop table SkillsetByAssignment 
drop table Skillset
drop table agent
select * into SkillsetByAssignment from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=casasm;PWD=estefi@2','select * from SkillsetByAssignment')
select * into skillset from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=casasm;PWD=estefi@2','select * from Skillset')
select * from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=casasm;PWD=estefi@2','select top 1000 * from dAgentPerformanceStat')

select distinct a.*,
sa1.skillsetid,
sa2.skillsetid,
sa3.skillsetid,
sa4.skillsetid,
sa5.skillsetid,
sa6.skillsetid,
sa7.skillsetid,
sa8.skillsetid,
sa9.skillsetid,
sa10.skillsetid,
sa11.skillsetid
 from 
	Agent a 
	left join SkillsetByAssignment sa1 on a.userid = sa1.userid and sa1.priority = 1 and sa1.skillsetstate = 'active'
	left join SkillsetByAssignment sa2 on a.userid = sa2.userid and sa2.priority = 2 and sa2.skillsetstate = 'active'
	left join SkillsetByAssignment sa3 on a.userid = sa3.userid and sa3.priority = 3 and sa3.skillsetstate = 'active'
	left join SkillsetByAssignment sa4 on a.userid = sa4.userid and sa4.priority = 4 and sa4.skillsetstate = 'active'
	left join SkillsetByAssignment sa5 on a.userid = sa5.userid and sa5.priority = 5 and sa5.skillsetstate = 'active'
	left join SkillsetByAssignment sa6 on a.userid = sa6.userid and sa6.priority = 6 and sa6.skillsetstate = 'active'
	left join SkillsetByAssignment sa7 on a.userid = sa7.userid and sa7.priority = 7 and sa7.skillsetstate = 'active'
	left join SkillsetByAssignment sa8 on a.userid = sa8.userid and sa8.priority = 8 and sa8.skillsetstate = 'active'
	left join SkillsetByAssignment sa9 on a.userid = sa9.userid and sa9.priority = 9 and sa9.skillsetstate = 'active'
	left join SkillsetByAssignment sa10 on a.userid = sa10.userid and sa10.priority = 10 and sa10.skillsetstate = 'active'
	left join SkillsetByAssignment sa11 on a.userid = sa11.userid and sa11.priority = 11 and sa11.skillsetstate = 'active'


select distinct assignname from skillsetbyassignment 
where userid in (select userid from agent  where surname = 'rossi')






drop table SkillsetByAssignment 