select * from tb where cd_producto like '%p%' and fc_cumplimiento is null
and cd_pedido_cliente not in (select cd_pedido_cliente from iad)
and cd_pedido_cliente = 160647408
and ani in (select cd_destino from analisis..trafico_voip)

select * from parque_voip where cd_ani in (select cd_destino from analisis..trafico_voip)
select * from voip_madre_hija where ani_hija not in (select cd_destino from analisis..trafico_voip)

select * from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente 
where fh_cierre between '01/05/2010' and '31/05/2010'

select month(fh_cierre), sum(1) from cate..averias 
where fh_cierre > '01/01/2010'
group by month(fh_cierre)
select sum(1) from  analisis..trafico_voip


SELECT DISTINCT CD_PRODUCTO_ES FROM IAD


