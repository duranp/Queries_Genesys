select count(*) cant, year(fh_cierre) anio, month(fh_cierre) mes
	from cate..averias a
	inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where 
cd_tipo_actuacion_apertura in (97074, 97084, 97094, 97124, 97144, 97154, 97164, 97174) 
and year(fh_cierre) >= 2009
group by year(fh_cierre), month(fh_cierre) 
order by year(fh_cierre), month(fh_cierre) 
