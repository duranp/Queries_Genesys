
select [sector tiene objeto],sup,sum(1) from inbox_p i inner join rooster_bo r on i.[inbox tiene objeto] = r.inbox 
group by sup,[sector tiene objeto]

select * from inbox_p where [sector tiene objeto]  = 'bot' and [inbox tiene objeto] not in (select inbox from rooster_bo where sup = 'batista')

select [sector tiene objeto] , suM(1) from inbox_p group by [sector tiene objeto] order by sum(1) desc 



insert into rooster_bo values ('back office t�cnico',null,'BOT','batista',null)
update roos

select [inbox tiene objeto] , suM(1) from inbox_p group by [inbox tiene objeto] order by sum(1) desc 
select * from inbox_p where [sector tiene objeto] like '%pend%'

select top 10 * from inbox i inner join inbox i2 on i.swobjectid = i2.swobjectid and dateadd(minute,-5,i.swdatereceived) between i2.swdatereceived and i2.swdateactiontaken and i.swactionid <> i2.swactionid
select * from inbox where swobjectid = 9240307.00000
select max([fecha de recepcion]) from inbox_p

select sup,[apellido tiene objeto], [nombre tiene objeto],suM(1), avg(datediff(hour, [fecha apertura], getdate())) tm 
from inbox_p i inner join rooster_bo r on i.[inbox tiene objeto] = r.inbox
group by sup,[apellido tiene objeto], [nombre tiene objeto]
order by sup, sum(1) desc

select * from inbox_p i inner join rooster_bo r on i.[inbox tiene objeto] = r.inbox

select * from inbox_p where [id de objeto]= 12208009
select * from inbox where swobjectid = 12208009
select * from casos where swcaseid = 12208009

select distinct [id de objeto] from inbox_p where estado = 'abierto' and [id de objeto] not in (

select swobjectid from inbox i inner join casos c on i.swobjectid = c.swcaseid and c.swstatus = 'abierto'
where swdisplay = 1 )

select sum(1) from casos where swcreatedby = 'sua_adm' and swstatus = 'abierto'

select * from inbox casos swobjectid = 10136022
select * from rooster_bo

select year(swdateresolved), month(swdateresolved), sup, nombres, sum(1)q, sum(cast(fcr2 as tinyint)) fcr2, sum(cast(fcr2 as tinyint))*1.0 /sum(1)*1.0 '%fcr'
from casos c inner join rooster_bo r on c.cctcerradopor = replace(r.cota,' ','')
group by year(swdateresolved), month(swdateresolved), sup, nombres
order by year(swdateresolved), month(swdateresolved), sup, sum(1) desc

select 




use vtv
select motivo, submotivo, sum(1) from vw_casos where swstatus = 'abierto'
group by motivo, submotivo
order by suM(1) desc

select * from rooster_bo WHERE NOMBRES = 'Pires Oscar Manuel'

update rooster_bo set sup = 'Batista' where sup = 'batista'


----vamos cerrando!!!

SP_GET_ST_BO_AG  'Pires Oscar Manuel'

SELECT sup,nombres, c.* FROM vw_CASOS c inner join rooster_bo r on c.cctcerradopor = replace(r.cota,' ','') and sup = 'pernice'
AND SWDATERESOLVED >= '01/01/2011' and swstatus = 'cerrado'


SP_GET_ST_BO_AG null,2011
ALTER PROCEDURE SP_GET_ST_BO_AG (@TX_AGENTE VARCHAR(33)=NULL, @anio smallint = null)
AS
select isnull(ce.anio,isnull(ge.anio,ce.anio))anio, isnull(ce.mes,isnull(ge.mes,ce.anio))mes,isnull(ce.sup,ge.sup)sup, isnull(ce.nombres,ge.nombres)nombres, isnull(ce.cerrados,0)cerrados,ce.tmc,ce.fcr2,[%fcr],ISNULL(ge.gestionados,0)gest, ISNULL(ge.tmg,0) tmg from (
select year(swdateresolved)anio, month(swdateresolved)mes, sup, nombres, sum(1)cerrados, avg(datediff(hour,swdatecreated,swdateresolved)) tmc, sum(cast(fcr2 as tinyint)) fcr2, sum(cast(fcr2 as tinyint))*1.0 /sum(1)*1.0 '%fcr'
from casos c inner join rooster_bo r on c.cctcerradopor = replace(r.cota,' ','') and swstatus = 'cerrado'
group by year(swdateresolved), month(swdateresolved), sup, nombres
) ce
left join (
select year(swdateactiontaken)anio , month(swdateactiontaken)mes,sup, nombres,  sum(1) gestionados,  avg(datediff(hour,swdatereceived,swdateactiontaken)*1.0) tmg
from inbox i inner join rooster_bo r on i.swreceiver = r.inbox 
where swactiontaken = 'gestionado' and swdateactiontaken is not null
group by year(swdateactiontaken), month(swdateactiontaken),sup, nombres) ge
on ce.anio = ge.anio and ce.mes = ge.mes and ce.sup = ge.sup and ce.nombres = ge.nombres
where ISNULL(@TX_AGENTE,isnull(CE.NOMBRES,ge.nombres)) = isnull(CE.NOMBRES,ge.nombres) and isnull(@anio,isnull(ce.anio,ge.anio)) = isnull(ce.anio,ge.anio)

t inbox
avg(datediff(hour,swdatecreated,swdateresolved)) tmc

SP_GET_ST_BO_SUP null,2011

alter PROCEDURE SP_GET_ST_BO_SUP (@sup VARCHAR(10)=NULL, @anio smallint = null)
AS
select isnull(ce.anio,isnull(ge.anio,ce.anio))anio, 
isnull(ce.mes,isnull(ge.mes,ce.anio))mes,
isnull(ce.sup,ge.sup)sup, isnull(ce.cerrados,0)cerrados,ce.tmc,ce.fcr2,[%fcr],ISNULL(ge.gestionados,0)gest, ISNULL(ge.tmg,0) tmg 
from (
select year(swdateresolved)anio, month(swdateresolved)mes, sup, sum(1)cerrados, avg(datediff(hour,swdatecreated,swdateresolved)) tmc, sum(cast(fcr2 as tinyint)) fcr2, sum(cast(fcr2 as tinyint))*1.0 /sum(1)*1.0 '%fcr'
from casos c inner join rooster_bo r on c.cctcerradopor = replace(r.cota,' ','') and swstatus = 'cerrado'
group by year(swdateresolved), month(swdateresolved), sup
) ce
left join (
select year(swdateactiontaken)anio , month(swdateactiontaken)mes,sup, sum(1) gestionados,  avg(datediff(hour,swdatereceived,swdateactiontaken)*1.0) tmg
from inbox i inner join rooster_bo r on i.swreceiver = r.inbox 
where swactiontaken = 'gestionado' and swdateactiontaken is not null
group by year(swdateactiontaken), month(swdateactiontaken),sup) ge
on ce.anio = ge.anio and ce.mes = ge.mes and ce.sup = ge.sup 
where ISNULL(@sup,isnull(CE.sup,ge.sup)) = isnull(CE.sup,ge.sup) and isnull(@anio,isnull(ce.anio,ge.anio)) = isnull(ce.anio,ge.anio)

select distinct a.a,getdate()
from (
select getdate()a from 
sysobjects where getdate() in 
	(select getdate()))a
inner join (
select getdate()a from 
sysobjects where getdate() in 
	(select getdate()))b
on a.a = b.a



t inbox
avg(datediff(hour,swdatecreated,swdateresolved)) tmc





sp_alert_rebote 'amorinj@hotmail.com.ar','01/02/2011 7:59:34'