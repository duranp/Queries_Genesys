SELECT DISTINCT p.tx_estado, m.tx_motivo, p.cd_tipo_tramite, a.CD_ESTADO_TRAMITE estado_adsl, a.TX_MOTIVO_CANC motivo_adsl,  F.*
FROM BORRAR_FABIO F 
	LEFT JOIN ADSL A
		ON F.PEDIDO = A.CD_PEDIDO_CLIENTE
	LEFT JOIN posventa.posventa.dbo.pgc_pedidos p
		on f.pedido = p.cd_pedido and p.cd_producto_pgc in ('tb','tb mp')
	left join posventa.posventa.dbo.dt_motivo m
		on p.cd_motivo = m.cd_motivo
		
		
		select * from posventa.posventa.dbo.pgc_pedidos
		where cd_pedido = '165202624'
		
		
		
	
