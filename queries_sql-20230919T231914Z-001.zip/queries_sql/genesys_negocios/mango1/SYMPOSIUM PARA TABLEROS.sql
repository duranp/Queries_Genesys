begin tran
delete from dAgentPerformanceStat where month(timestamp)>=month(timestamp)
insert into dAgentPerformanceStat select * from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04','select * from dAgentPerformanceStat  where AgentLogin between ''1000'' and ''1100'' and AgentSurName is not null') where month(timestamp)>=month(timestamp)-1
commit tran
-------------
begin tran
delete from dapplicationstat
insert into  dapplicationstat select * from 
OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04',
'select * from dApplicationStat') 
WHERE  year(timestamp)=year(getdate())and 
month(timestamp)=month(getdate())  and 
applicationid in (select applicationid from aplicacion where skill is not null)
commit tran
go
-------------
begin tran
delete from mAgentPerformanceStat where year(timestamp)=year(getdate()) 
insert into mAgentPerformanceStat select * from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04','select * from mAgentPerformanceStat  where AgentLogin between ''1000'' and ''1100'' and AgentSurName is not null') WHERE  year(timestamp)=year(getdate()) 
commit tran
-------------
begin tran
delete from mApplicationStat  where  year(timestamp)=year(getdate())
INSERT into mApplicationStat  SELECT * from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04','select * from mApplicationStat') WHERE  year(timestamp)=year(getdate())
and applicationid in (select applicationid from aplicacion where skill is not null)
commit tran


/*
select * from aplicacion
select * from 
OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana04',
'select * from Application') s left join aplicacion a on s.name = a.name
*/


CREATE PROCEDURE [dbo].[sp_buscar_ag]
@user varchar(20)
AS
select * from usuarios where U_red like @user

GO

CREATE procedure [dbo].[sp_call_stats] (@mes as integer,@anio as integer, @operador as integer) 
as 
if @operador=9999
begin
	goto todos
end
if @operador = 8888
begin
	goto lista
end
select 
	sum(shortcallsanswered) SC,
	sum(callsanswered) as CA,
	sum(notreadytime) as NR,
	dbo.fn_div(sum(notreadytime),sum(loggedintime)) as pNR,
	sum(waitingtime) as WT,
	dbo.fn_div(sum(waitingtime),sum(loggedintime)) as pWT,
	sum(holdtime) as HT,
	dbo.fn_div(sum(holdtime),sum(loggedintime)) as pHT,
	sum(talktime) as TT,
	dbo.fn_div(sum(talktime),sum(loggedintime)) as pTT,
	sum(loggedintime) as LT,
	sum(ringtime) as RT
	from mAgentPerformanceStat 
	where month(timestamp)=@mes and 
	year(timestamp)=@anio and
	agentlogin = @operador 
goto fin
todos:
select 
	sum(shortcallsanswered) SC,
	sum(callsanswered) as CA,
	sum(notreadytime) as NR,
	dbo.fn_div(sum(notreadytime),sum(loggedintime)) as pNR,
	sum(waitingtime) as WT,
	dbo.fn_div(sum(waitingtime),sum(loggedintime)) as pWT,
	sum(holdtime) as HT,
	dbo.fn_div(sum(holdtime),sum(loggedintime)) as pHT,
	sum(talktime) as TT,
	dbo.fn_div(sum(talktime),sum(loggedintime)) as pTT,
	sum(loggedintime) as LT,
	sum(ringtime) as RT
	from mAgentPerformanceStat 
	where month(timestamp)=@mes and 
	year(timestamp)=@anio
goto fin
lista:
	select agentsurname+', '+agentgivenname as 'Apellido/Nombre',
	shortcallsanswered Cortas,
	callsanswered as Contestadas,
	dbo.int_a_time(notreadytime) as Not_ready,
	dbo.fn_div(notreadytime,loggedintime) as '%_Not_ready',
	dbo.int_a_time(waitingtime) as Ocioso,
	dbo.fn_div(waitingtime,loggedintime) as '%_Ocioso',
	dbo.int_a_time(holdtime) as Hold,
	dbo.fn_div(holdtime,loggedintime) as '%_Hold',
	dbo.int_a_time(talktime) as Talking_time,
	dbo.fn_div(talktime,loggedintime) as '%_Talk',
	dbo.int_a_time(loggedintime) as Logueo,
	dbo.int_a_time(ringtime) as Ring_time,
	dbo.int_a_time(talktime/callsanswered) as 'Tallk/LL',
	dbo.int_a_time(notreadytime/callsanswered) as 'NotR/LL',
	dbo.int_a_time(waitingtime/callsanswered)  as 'Wait/LL',
	dbo.int_a_time(holdtime/callsanswered) as 'Hold/LL'
	from mAgentPerformanceStat 
	where month(timestamp)=@mes and 
	year(timestamp)=@anio and
	agentlogin in (select agentlogin from usuarios where rango='operador')
	order by 'Apellido/Nombre'
fin:
GO

CREATE PROCEDURE [dbo].[sp_mappstat_d_sk] 
@@skill varchar(255),
@@ind varchar(20)
AS
exec('select dia,'+@@IND+' from 
(SELECT day(a.[Timestamp]) AS dia, CAST((((SUM(a.CallsAnswered) + SUM(a.CallsAbandoned)) 
                      - (SUM(a.CallsAnsweredAftThreshold) + SUM(a.CallsAbandonedAftThreshold))) * 100) / (SUM(a.CallsAnswered) + SUM(a.CallsAbandoned)) AS numeric) 
                      AS SL, CAST(CAST(SUM(a.CallsAnswered) AS real) / (CAST(SUM(a.CallsOffered) AS real)) 
                      AS real) * 100 AS EF, SUM(a.CallsAnswered) AS CallsAnswered, SUM(a.CallsAbandoned) AS CallsAbandoned, SUM(a.Callsoffered) as CallsOffered 
FROM         dbo.Aplicacion INNER JOIN
                      dbo.dApplicationStat a ON dbo.Aplicacion.ApplicationID = a.ApplicationID
where dbo.aplicacion.skill in('+@@SKILL+')
and callsoffered<>0
GROUP BY day(a.[Timestamp])
) t')
GO


CREATE PROCEDURE [dbo].[sp_mappstat_mes]
@@mensual varchar(1),
@@anio varchar(4)
AS
if @@mensual = 'n' 
begin
	select month(timestamp)
	from mapplicationstat 
	where year(timestamp)=@@anio
	group by month(timestamp)
end
if @@mensual = 's' 
begin
	select day(timestamp)
	from dapplicationstat 
	where month(timestamp)=month(getdate())
	group by day(timestamp)
end
GO

CREATE PROCEDURE [dbo].[sp_mappstat_sk] 
@@anio varchar(4),
@@skill varchar(255),
@@ind varchar(20)
AS
exec ('select mes,'+@@ind+' from 
( SELECT top 100 percent MONTH(a.[Timestamp]) AS mes, YEAR(a.[Timestamp]) AS anio, CAST((((SUM(a.CallsAnswered) + SUM(a.CallsAbandoned)) 
                      - (SUM(a.CallsAnsweredAftThreshold) + SUM(a.CallsAbandonedAftThreshold))) * 100) / (SUM(a.CallsAnswered) + SUM(a.CallsAbandoned)) AS numeric) 
                      AS SL, CAST(CAST(SUM(a.CallsAnswered) AS numeric) / (CAST(SUM(a.CallsOffered) AS numeric)) 
                      AS dec(4, 4)) * 100 AS EF, SUM(a.CallsAnswered) AS CallsAnswered, SUM(a.CallsAbandoned) AS CallsAbandoned, SUM(a.Callsoffered) as CallsOffered 
FROM         dbo.Aplicacion INNER JOIN
                      dbo.mApplicationStat a ON dbo.Aplicacion.ApplicationID = a.ApplicationID
where dbo.aplicacion.skill in('+@@skill+')
GROUP BY MONTH(a.[Timestamp]), YEAR(a.[Timestamp])
ORDER BY YEAR(a.[Timestamp]) DESC, MONTH(a.[Timestamp]) DESC ) t
 where t.anio='+@@anio+'order by t.mes')
GO


CREATE PROCEDURE [dbo].[sp_mappstat_sk2]
@@anio varchar(4),
@@skill varchar(255),
@@ind varchar(20)
AS
exec ('select mes,'+@@ind+' from mappstat_skill where anio='+@@anio+' and skill in('+@@skill+') order by mes')

GO



