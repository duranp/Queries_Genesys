
select distinct 
case when f.cd_central is not null then 'si' else 'no' end fwt, 
case when v.[cod central] is not null then 'si' else 'no' end voip, 
case when a.codigo is not null then 'si' else 'no' end adsl,
case when p.cd_central is not null then 'si' else 'no' end parque_tb,
case when ps.cd_central is not null then 'si' else 'no' end parque_sp,
RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 0),':',1))) TX_CALLE, RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 1),':',1))) VL_NUMERO, c.*
from borrar_cancelar c 
	left join v_parque_tb_sp p 
		on c.cd_party = p.cd_party_titular and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 0),':',1))) = p.tx_calle 
		and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 1),':',1))) = p.nu_calle
	left join v_parque_tb_sp ps
		on c.cd_party = p.cd_party_titular and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 0),':',1))) = ps.tx_calle 
		and RTRIM(LTRIM(DBO.SPLITINDEX(DBO.SPLITINDEX(TX_DOMICILIO, '-', 1),':',1))) = ps.nu_calle
		and ps.tx_producto is not null
	left join v_disp_adsl a on c.cd_central = a.codigo
	left join v_disp_voip v on c.cd_central = v.[cod central]
	left join v_disp_fwt f on c.cd_central = f.cd_central		

		/*
select top 1000 * from v_parque_tb_sp 

select * from v_parque_tb_sp where tx_calle = 'ADOLFO ALSINA' and nu_calle = '00431'

select * from dt_central
*/

SELECT * FROM borrar_cancelar




