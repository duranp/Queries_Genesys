ALTER procedure sp_tmi_visualizador_INS
AS
SET NOCOUNT ON  
select T.cd_central, datediff(day, T.fc_emision, T.fc_cumplimiento) t, CASE WHEN A.CD_PEDIDO_CLIENTE IS NULL THEN 'TB' ELSE 'TBSP' END tx_producto  
into #t   
from tb T LEFT JOIN ADSL A ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO 
where   
 T.cd_estado_tramite = 'fa' 
 and T.fc_cumplimiento between dbo.pd(dateadd(month,-1,getdate()))  and dbo.ud(dateadd(month,-1,getdate()))
 and T.cd_producto not in ('02100000000P7','02100000000P4')  
union all  
select A.cd_central, datediff(day, A.fc_emision, A.fc_cumplimiento) t, 'sp' tx_producto  
from adsl A LEFT JOIN TB T ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO
where   
 A.cd_motivo_ingreso is null  
 AND T.CD_PEDIDO_CLIENTE IS NULL
 and A.cd_estado_tramite = 'cu'   
 and A.fc_cumplimiento between dbo.pd(dateadd(month,-1,getdate()))  and dbo.ud(dateadd(month,-1,getdate()))
   
INSERT INTO V_TMI_VISUALIZADOR   
select distinct  tt.tx_producto, tt.cd_central,
(select MAX(T) from (select top 10 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '10',  
(select MAX(T) from (select top 20 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '20',
(select MAX(T) from (select top 30 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '30',
(select MAX(T) from (select top 40 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '40',
(select MAX(T) from (select top 50 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '50',
(select MAX(T) from (select top 60 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '60',
(select MAX(T) from (select top 70 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '70',
(select MAX(T) from (select top 80 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '80',
(select MAX(T) from (select top 90 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '90',
(select MAX(T) from (select top 100 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '100',
(select SUM(1) from (select t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto)a) 'TOTAL',
dbo.pd(getdate()) timestamp
from #T tt 
WHERE dbo.pd(getdate()) NOT IN (SELECT TIMESTAMP FROM V_TMI_VISUALIZADOR)

drop table #t
GO

sp_helptext 'dbo.ud'

DELETE FROM V_TMI_VISUALIZADOR
EXEC sp_tmi_visualizador_INS

SELECT* FROM  V_TMI_VISUALIZADOR

sp_helptext  sp_tmi_visualizador

DROP TABLE V_TMI_CENTRAL

Text
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
alter procedure sp_tmi_visualizador
AS
SET NOCOUNT ON  
select T.cd_central, datediff(day, T.fc_emision, T.fc_cumplimiento) t, CASE WHEN A.CD_PEDIDO_CLIENTE IS NULL THEN 'TB' ELSE 'TBSP' END tx_producto  
into #t   
from tb T LEFT JOIN ADSL A ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO 
where   
 T.cd_estado_tramite = 'fa' 
 and T.fc_cumplimiento between dbo.pd(dateadd(month,-1,getdate()))  and dbo.ud(dateadd(month,-1,getdate()))
 and T.cd_producto not in ('02100000000P7','02100000000P4')  
union all  
select A.cd_central, datediff(day, A.fc_emision, A.fc_cumplimiento) t, 'sp' tx_producto  
from adsl A LEFT JOIN TB T ON A.CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = T.CD_SUB_PEDIDO
where   
 A.cd_motivo_ingreso is null  
 AND T.CD_PEDIDO_CLIENTE IS NULL
 and A.cd_estado_tramite = 'cu'   
 and A.fc_cumplimiento between dbo.pd(dateadd(month,-1,getdate()))  and dbo.ud(dateadd(month,-1,getdate()))
   
select distinct  tt.tx_producto, tt.cd_central,
(select MAX(T) from (select top 10 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '10',  
(select MAX(T) from (select top 20 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '20',
(select MAX(T) from (select top 30 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '30',
(select MAX(T) from (select top 40 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '40',
(select MAX(T) from (select top 50 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '50',
(select MAX(T) from (select top 60 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '60',
(select MAX(T) from (select top 70 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '70',
(select MAX(T) from (select top 80 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '80',
(select MAX(T) from (select top 90 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '90',
(select MAX(T) from (select top 100 percent with ties t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto order by T)a) '100',
(select SUM(1) from (select t from #T where  cd_central = tt.cd_central and tx_producto = tt.tx_producto)a) '100',
dbo.pd(getdate()) timestamp
from #T tt 

drop table #t




