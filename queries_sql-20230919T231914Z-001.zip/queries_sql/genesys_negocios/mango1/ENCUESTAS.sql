SELECT * FROM SYSOBJECTS WHERE NAME LIKE 'SP[_]%'


ALTER PROCEDURE SP_SAVE_CONTACTO (@CD_PARTY BIGINT, @TX_MAIL VARCHAR(500), @TX_CELULAR VARCHAR(15))
AS
INSERT INTO [CATE].[dbo].[E_CONTACTOS]
           ([cd_party]
           ,[tx_mail]
           ,[tx_celuar])
     VALUES
           (@CD_PARTY
           ,@TX_MAIL
           ,@TX_CELULAR)
GO


ALTER PROCEDURE SP_ENVIAR_ENC (@ani BIGINT, @CD_CASO bigint, @TX_USUARIO VARCHAR(100), @TX_MAIL VARCHAR(500), @TX_CELULAR VARCHAR(15))
AS
DECLARE @HASH AS VARCHAR(100), @cd_party bigint
SET @HASH = NEWID()
SET NOCOUNT ON

EXEC visualizador.dbo.sp_get_party @ANI, @cd_party = @cd_party output  

INSERT INTO [CATE].[dbo].[E_ENVIADOS]
           ([CD_PARTY]
		   ,[ANI]
		   ,[CD_CASO]
           ,[TX_USUARIO]
           ,[TX_HASH]
		   ,[TX_MAIL]
		   ,[TX_CELULAR]
)
     VALUES(
           @CD_PARTY
		   ,@ANI
		   ,@CD_CASO        
           ,@TX_USUARIO
           ,@HASH
		   ,@TX_MAIL
		   ,@TX_CELULAR)
SET @HASH = 'HTTP://WWW.SATISFACCION.SPEEDY.COM.AR/?HASH='+@HASH
EXEC [10.244.65.234].MASTER.DBO.XP_SENDMAIL @RECIPIENTS=@TX_MAIL, @MESSAGE=@HASH, @subject='Encuesta de Satisfacci�n de clientes'
SELECT @HASH TX_HASH
GO

SP_ENVIAR_ENC 99, 'MANGO2', 'SEBASTIAN.MANGISCH@TELEFONICA.COM'
sp_helptext SP_SAVE_ENCUESTA

ALTER PROCEDURE SP_SAVE_ENCUESTA (@ip varchar(80), @HASH VARCHAR(36),@P1 BIGINT,@P2 BIGINT,@P3 BIGINT,@P4 BIGINT,@P5 BIGINT,@P6 BIGINT,@P7 BIGINT,@P8 BIGINT,@P9 BIGINT,@P10 BIGINT,@TX_OBS VARCHAR(8000))  
AS  
if (not exists(select tx_hash from e_encuestas e inner join e_enviados en on e.id_enviado = en.id_enviado where tx_hash = @hash))  
begin  
 DECLARE @ID_ENVIADO BIGINT  
 SELECT @ID_ENVIADO=ID_ENVIADO FROM E_ENVIADOS WHERE TX_HASH = @HASH   
 INSERT INTO E_ENCUESTAS (  
  ip, ID_ENVIADO,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10, TX_OBS  
  ) VALUES (@ip, @ID_ENVIADO,@P1,@P2,@P3,@P4,@P5,@P6,@P7,@P8,@P9,@P10,@TX_OBS)   
end  

SELECT * FROM E_ENVIADOS


alter procedure sp_chk_enc (@tx_hash varchar(36))
as
	declare @cd_party bigint
	declare @tx_party varchar(200)

	SELECT @cd_party = b.cd_party
	FROM E_ENCUESTAS a right join E_ENVIADOS b on a.id_enviado = b.id_enviado
	where TX_HASH = @tx_hash
	
	select @tx_party = isnull(tx_razon_social, tx_apellido + ', ' + tx_nombre) 
	from [10.244.65.234].posventa.dbo.parque_basica where cd_party_titular-20000000000 = @cd_party

	SELECT case when a.id_encuesta is null then 'NO' else 'SI' end vl_enc, @tx_party tx_party
	FROM E_ENCUESTAS a right join E_ENVIADOS b on a.id_enviado = b.id_enviado
	where TX_HASH = @tx_hash
go
sp_chk_enc '53A19992-8D97-402E-B962-7E2BA124F460'

SELECT * FROM E_ENVIADOS WHERE TX_HASH = '32FFBC32-4C5E-4C8D-9849-D1471854AE29'
SELECT *,
case
	when b.id_enviado is not null and a.id_encuesta is null then 'NO' else 'SI' end vl_enc FROM E_ENCUESTAS a right join E_ENVIADOS b on a.id_enviado = b.id_enviado
where TX_HASH = '32FFBC32-4C5E-4C8D-9849-D1471854AE29'

sp_chk_enc '600590B0-748C-4791-94D6-9371D79EB920'
delete from e_encuestas where id_encuesta = 4 and id_enviado = 6
select * from e_encuestas where id_enviado =


alter procedure sp_get_mail (@ani bigint)
as
declare @cd_party bigint
exec visualizador.dbo.sp_get_party @ani, @cd_party = @cd_party output
select distinct tx_mail from e_enviados where cd_party = @cd_party
go

sp_get_mail 88
select * from e_enviados where id_enviado = 75
sp_get_enc_usr ''

delete from e_encuestas where id_encuesta = 14
SP_SAVE_ENCUESTA 'E51036C9-BD19-4A69-88DC-3A0F39D68AFF',2,2,4,4,5,1,5,1,4,9,10,'la verdad una masa'
sp_helptext sp_get_env_usr
select * from visualizador..dt_central where tx_central like '%alfons%'
alter procedure sp_get_env_usr (@tx_usuario varchar(50) = null)  
as  
select e.id_encuesta,e.timestamp fc_encuesta, en.id_enviado, en.cd_party, en.timestamp fc_enviado, en.cd_caso, en.tx_mail, en.tx_hash  
from e_enviados en left join e_encuestas e on en.id_enviado = e.id_enviado where tx_usuario = isnull(@tx_usuario, tx_usuario)  
order by e.timestamp desc, en.timestamp desc  


SELECT * FROM cate..E_ENVIADOS


SELECT * FROM  E_ENCUESTAS e left join e_enviados en on e.id_enviado = en.id_enviado

create procedure dbo.sp_get_party (@ani as bigint, @cd_party bigint output)
as
select distinct @cd_party = cd_party_titular from v_parque_tb_sp where ani = @ani
go


declare @cd_party bigint
exec visualizador.dbo.sp_get_party 1149821229, @cd_party = @cd_party output
print @cd_party

grant exec on sp_get_env_full to cate

sp_get_enc 16,'TASA\MANGISCHS'

sp_helptext sp_get_manz_new 115,142,'OLAGUER Y FELIU',02884

select * from visualizador..v_parque_tb_sp where ani = 1144509986

select * from v_manzanero where cd_central = 115 and cd_manzana = 142

use cate

create procedure sp_vitacora (@tx_usuario varchar(100), @app varchar(100))
as
	insert into e_vitacora (tx_usuario, app) values (@tx_usuario, @app)
go

SP_VITACORA 'MANGO','APP'

GRANT EXEC ON SP_VITACORA TO CATE

select * from visualizador..v_pe where cd_central = 1859 and manzana = 4
select * from visualizador..v_manzanero where cd_central = 1859

select * from visualizador..v_parque_tb_sp where cd_central = 1859

alter procedure sp_get_enc (@id_encuesta bigint, @tx_usuario varchar(100) = null)
as
select en.timestamp fc_enviado, e.timestamp fc_encuesta, p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,tx_obs, en.tx_usuario from e_encuestas e inner join e_enviados en on e.id_enviado = en.id_enviado where id_encuesta = @id_encuesta and isnull(@tx_usuario,en.tx_usuario) = en.tx_usuario 
order by fc_encuesta desc

sp_helptext sp_get_enc  10, 'tasa\mangischs'

select * from e_VITACORA order by timestamp desc

SP_HELPTEXT SP_MONITOREO 'TEST'

CREATE procedure sp_monitoreo (@tx_usuario varchar(50))  
as  
set nocount on  
DECLARE @tx_usuario varchar(50)
SET @TX_USUARIO = 'MANGO'
declare @tx_rol varchar(50)  
select @tx_rol = r.tx_rol from pegaso.dbo.usuarios u inner join pegaso.dbo.roles r on u.cd_rol = r.cd_rol and u.tx_usuario = @tx_usuario  
select   *,@tx_rol tx_rol from v_vitacora where (@tx_rol = 'visualizador' and tx_usuario = @tx_usuario) or @tx_rol='ADMINISTRADOR' order by timestamp desc

sp_get_env_usr null


sp_helptext sp_get_enc

alter procedure sp_get_enc (@id_encuesta bigint, @tx_usuario varchar(100) = null)  
as  
select en.timestamp fc_enviado, e.timestamp fc_encuesta, p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,tx_obs, en.tx_usuario from e_encuestas e inner join e_enviados en on e.id_enviado = en.id_enviado where id_encuesta = @id_encuesta and isnull(@tx_usuario,en.tx_usuario) = en.tx_usuario   
order by fc_encuesta desc  

CREATE procedure sp_get_env_usr (@tx_usuario varchar(50) = null)      
as      
select e.id_encuesta,e.timestamp fc_encuesta, en.id_enviado, en.cd_party, en.ani, en.timestamp fc_enviado, en.cd_caso, en.tx_mail, en.tx_usuario    
from e_enviados en left join e_encuestas e on en.id_enviado = e.id_enviado where tx_usuario = isnull(@tx_usuario, tx_usuario)      
order by e.timestamp desc, en.timestamp desc 

sp_get_env_full 'TASA\SAFTIHC'

select round(cast(10 as real)/ 3,2)


alter  procedure sp_get_env_full (@tx_usuario varchar(50) = null)    
as    
select case when e.id_encuesta is null then 'NO' else 'SI' end encuestado, en.id_enviado, e.P1,e.P2,e.P3,e.P4,e.P5,e.P6,e.P7,e.P8,e.P9,e.P10,e.TX_OBS,e.TIMESTAMP fc_encuesta, ID_ENCUESTA, en.cd_party, en.ani, en.timestamp fc_enviado, en.cd_caso, en.tx_mail, en.tx_usuario, CASE WHEN @TX_USUARIO IS NULL THEN IP ELSE 'SIN PERMISO' END IP
from e_enviados en left join e_encuestas e on en.id_enviado = e.id_enviado where tx_usuario = isnull(@tx_usuario, tx_usuario)    
order by e.timestamp desc, en.timestamp desc    

select e.ID_ENVIADO,e.P1,e.P2,e.P3,e.P4,e.P5,e.P6,e.P7,e.P8,e.P9,e.P10,e.TX_OBS,e.TIMESTAMP fc_encuesta, ID_ENCUESTA
 from e_encuestas

select * from e_vitacora



alter procedure sp_ins_usuario (@tx_usuario varchar(100),@tx_mail varchar(100))
as
set nocount on
if not exists(select tx_usuario from e_usuarios where tx_usuario = @tx_usuario)
	begin
		insert into e_usuarios (tx_usuario,tx_mail) values (@tx_usuario, @tx_mail)	
		select 'no' existe
	end
else
	begin
		select 'si' existe
	end
go

alter procedure sp_chk_usuario (@tx_usuario varchar(100) = null)
as
	select tx_mail from e_usuarios where isnull(@tx_usuario,tx_usuario) = tx_usuario
go

grant exec on sp_ins_usuario to cate
sp_chk_usuario 
sp_chk_usuario 'tasa\mangischs','sebastian.mangisch@telefonica.com.ar'
delete from e_usuarios
sel

select tx_usuario,  avg(p1),avg(p2),avg(p3),avg(p4),avg(p5),avg(p6),avg(p7),avg(p8),avg(p9),avg(p10) from e_ENCUESTAS e inner join e_enviados en on e.id_enviado = e.id_enviado
group by tx_usuario


select * from e_vitacora order by timestamp desc
sp_helptext sp_vitacora

SP_GET_MANZ_ady 952,5617,'SARMIENTO',2000

sp_helptext sp_get_manz_new




select * from e_usuarios
select * from visualizador..v_vitacora

ALTER procedure sp_vitacora (@tx_usuario varchar(100), @app varchar(100))  
as  
if @tx_usuario <> 'TASA\MANGISCHS' 
BEGIN
	insert into e_vitacora (tx_usuario, app) values (@tx_usuario, @app)  
END

SELECT * from e_vitacora where tx_usuario = 'tasa\mangischs'
  
create PROCEDURE SP_GET_MANZ_new (@CD_CENTRAL INT, @CD_MANZANA INT, @TX_CALLE AS VARCHAR(60), @NUMERO INT)    
as            
SELECT DISTINCT  v.tx_calle tx_calle_lindante, v.cd_central, v.CD_MANZANA,-- 'YO' NORTE,               
case when               
cast(              
case when pe.porc_sat_caja > 0 and pe.porc_sat_caja > pe.porc_sat_arm then pe.porc_sat_caja               
  when pe.porc_sat_arm > 0 and pe.porc_sat_arm > pe.porc_sat_caja then pe.porc_sat_arm              
  when  pe.porc_sat_arm = 0 then pe.porc_sat_caja               
  when  pe.porc_sat_caja = 0 then pe.porc_sat_arm              
end as real) >=90 then 'no' else 'si' end pe,               
case when pi.cv > 50 then 'si' else 'no' end pi,              
case when vv.[cod central] is not null then 'si' else 'no' end voip,              
case when vf.cd_central is not null then 'si' else 'no' end fwt,              
pr.avg_LONG long,               
case when va.cd_central is null then 'NO'            
 else             
 case  when ve.velocidad = '10mb' and (vs.[10mb] is null or vs.[zona competencia] not in ('z0','z1')) then '5MB'              
    when pr.avg_long is null then 's/d'            
    else ve.velocidad               
 end          
end speedy,            
tm1.[80]+1 tmi_tb,              
tm2.[80] tmi_sp,           
tm3.[80]+1 [tmi_tb+sp],            
z.[zona competencia] tx_zona_competencia,            
case when zp.mz_pg is null then 'NO' ELSE zp.mz_pg END MZ_PG            
FROM v_manzanero v               
left join v_pe pe on v.cd_central = pe.cd_central and v.cd_manzana = pe.manzana              
left join v_pi pi on v.cd_central = pi.cntcd-- and v.cd_manzana = pi.cd_manzana              
left join v_prefa pr on v.cd_central = pr.cd_central and v.cd_manzana = pr.cd_manzana              
left join v_velocidades ve on pr.avg_LONG between ve.minima and ve.maxima              
left join v_disp_voip vv on v.cd_central = vv.[cod central]              
left join v_disp_speedy vs on v.cd_central = vs.[cod central]              
left join v_disp_fwt vf on v.cd_central = vf.cd_central              
left join v_cupo_adsl va on v.cd_central = VA.cd_central and va.nu_disponible >= 9            
left join v_tmi_central tm1 on v.cd_central = tm1.cd_central and tm1.tx_producto = 'tb' and tm1.timestamp = dbo.pd(getdate())          
left join v_tmi_central tm2 on v.cd_central = tm2.cd_central and tm2.tx_producto = 'sp' and tm2.timestamp = dbo.pd(getdate())           
left join v_tmi_central tm3 on v.cd_central = tm3.cd_central and tm3.tx_producto = 'tb+sp' and tm3.timestamp = dbo.pd(getdate())          
left join v_zonas z on v.cd_central = z.[cod central]            
left join v_zona_peligrosa zp on v.cd_central = zp.cd_central and v.cd_manzana = zp.cd_manzana     
where  
v.tx_calle = @tx_calle   
and @numero between V.NU_DESDE AND v.NU_HASTA AND V.NU_DESDE % 2 = @numero % 2  
and v.cd_central = @cd_central and v.cd_manzana = @cd_manzana  