

SELECT * INTO #VOZ FROM OPENQUERY(POSVENTA,'POSVENTA.DBO.SP_ULTIMA_VOZ_VISUALIZADOR')

select A.cd_pedido_cliente, A.cd_sub_pedido, A.cd_tramite, A.fc_emision, A.fc_cumplimiento, A.cd_estado_tramite, A.tx_motivo_canc, V.TX_G_MOTIVO_REAL, tx_g_resultado
from adsl A LEFT JOIN #VOZ V ON A.CD_PEDIDO_CLIENTE = V.CD_PEDIDO AND A.CD_SUB_PEDIDO = V.CD_SUB_PEDIDO AND A.CD_TRAMITE = V.CD_TRAMITE
where (cd_estado_tramite = 'an' and A.FC_CUMPLIMIENTO >= dateadd(day,-35,GETDATE())) or A.fc_cumplimiento is null
union all
select A.cd_pedido_cliente, A.cd_sub_pedido, A.cd_tramite, A.fc_emision, A.fc_cumplimiento, A.cd_estado_tramite, A.tx_motivo_canc
from TB A LEFT JION #VOZ V ON A.CD_PEDIDO_CLIENTE = V.CD_PEDIDO_CLIENTE AND A.CD_SUB_PEDIDO = V.CD_SUB_PEDIDO AND A.CD_TRAMITE = V.CD_TRAMITE
where (cd_estado_tramite = 'an' and FC_CUMPLIMIENTO >= dateadd(day,-35,GETDATE())) or fc_cumplimiento is null

DROP TABLE #VOZ

v
t tb