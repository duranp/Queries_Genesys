SET NOCOUNT ON
DECLARE @paquete varchar(100)
DECLARE @object int
Declare @Tasks int
declare @i int
Declare @prop varchar(100)
Declare @Name varchar(100)
Declare @Description varchar(100)

set @paquete = 'NUEVOS INDICADORES(AM)'
--if exists(select * from sysobjects where name like 'dts_detail') drop table dts_detail
if not exists(select * from sysobjects where name like 'dts_detail')
begin
create table dts_detail (
paquete varchar(1000),
taskname varchar(100),
description varchar(1000)
)
end

delete from dts_detail where paquete = @paquete

EXEC sp_OACreate 'DTS.Package', @object OUTPUT
EXEC sp_OAMethod @object, 'LoadFromSQLServer',NULL,'INDICADORES','','','256','','','',@paquete
EXEC sp_OAGetProperty @object, 'Tasks.Count', @Tasks OUT
set @i = 0
While @i < @Tasks
begin
set @i = @i + 1
set @prop = 'Tasks(' + rtrim(cast(@i as char)) + ').Name'
EXEC sp_OAGetProperty @object, @prop, @Name OUT
set @prop = 'Tasks(' + rtrim(cast(@i as char)) + ').Description'
EXEC sp_OAGetProperty @object, @prop, @Description OUT

insert into dts_detail values (@paquete,@Name,@Description)
end

select * from dts_detail




  
--select top 1 Name, starttime, endtime, elapsedtime, computer, operator, logdate, errordescription from msdb..sysdtspackagelog order by starttime desc
select (select description from dts_detail where replace(taskname,'DTSTask','DTSStep') = slog.stepname), stepexecstatus, stepexecresult, starttime, endtime, elapsedtime, errordescription, progresscount from msdb..sysdtssteplog slog where lineagefull = (select top 1 lineagefull from msdb..sysdtspackagelog order by starttime desc)
--and stepexecresult=1

    
    select fc_cumplimiento, tipo_producto, count(*) from bv_bienvenida  b    
    group by tipo_producto, fc_cumplimiento
    order by fc_cumplimiento desc, count(*) desc
