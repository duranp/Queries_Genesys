drop table #pc
select * into #pc from openquery(posventa, 
'select P.*, C.TX_CANAL, F.TX_FDV, M.TX_MOTIVO
from posventa..pgc_pedidos p 
	left join posventa..pgc_fdv f on p.cd_fdv = f.cd_fdv 
	left join posventa..pgc_canal c on ''02''+p.cd_CANAL = C.CD_CANAL
	LEFT JOIN POSVENTA..DT_MOTIVO M ON P.CD_MOTIVO = M.CD_MOTIVO
where cd_producto_pgc like ''pc%''
and  fc_cumplimiento >= ''01/09/2009''')

select MONTH(FC_CUMPLIMIENTO) MES_C, MONTH(FC_EMISION) MES_E,*, DATEDIFF(DAY, FC_EMISION, FC_CUMPLIMIENTO) TMI from #pc P LEFT JOIN DT_CENTRAL_DISTRITO_REGION CDR ON P.CD_CENTRAL = CDR.CD_CENTRAL


SELECT * FROM #PC WHERE TX_ESTADO = 'AN'