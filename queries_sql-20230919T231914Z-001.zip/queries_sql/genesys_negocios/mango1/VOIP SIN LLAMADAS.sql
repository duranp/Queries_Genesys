select * from parque_voip p left join posventa.dbo.parque_basica m on p.ani_madre = rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea 

where ani_hija not in (select ani from trafico_voip) 
--and ani_hija  in (select ani from trafico_voip_entrante)
and replace(fc_desde,'-','') < dateadd(month,-3,getdate()) and fc_hasta = '?'


select * from posventa.dbo.parque_basica

select * from trafico_voip where ani not in (select ani from trafico_voip_entrante)
select * from trafico_voip_entrante where ani not in (select ani from trafico_voip)

--activas llamadas 2010 altas < 2010
select rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea ani, sum(t.cant)s, sum(e.cant) e, p.cd_party, p.nombre_cliente, fc_desde
from parque_voip p
	left join trafico_voip t on rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea = t.ani and t.anio = 2010
	left join trafico_voip_entrante e on rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea = e.ani and e.anio = 2010
where year(replace(fc_desde,'-','')) <= 2010 and fc_hasta = '?'
group by rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea, p.cd_party, p.nombre_cliente, fc_desde


--bajas
select rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea ani, sum(t.cant)s, sum(e.cant) e, p.cd_party, p.nombre_cliente, fc_desde, fc_hasta
from parque_voip p
	left join trafico_voip t on rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea = t.ani 
	left join trafico_voip_entrante e on rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea = e.ani 
where fc_hasta <> '?'
group by rtrim(p.cd_interurbano)+rtrim(p.cd_urbano)+p.cd_linea, p.cd_party, p.nombre_cliente, fc_desde, fc_hasta





select * from posventa.dbo.parque_voip
drop table trafico_voip

select case when a.cd_pedido_cliente is not null and a.cd_motivo_ingreso is null and s.cd_pedido_cliente is null then 'SI'
	 ELSE 'NO' END SPEEDY, c.tx_central, t.* 
from tb t 
	left join dt_central c 
		on t.cd_central = c.cd_central 
	left join bv_sin_navegacion s on t.cd_pedido_cliente = s.cd_pedido_cliente 
	left join adsl a on t.cd_pedido_cliente = a.cd_pedido_cliente  
where t.cd_producto in ('02100000000P4', '02100000000P7') and t.cd_central not in (select [cod central] from tic.visualizador.dbo.v_disp_voip)
and t.fc_cumplimiento is null 

select * from adsl where tx_producto like '%voip%' and cd_motivo_ingreso is not null



SELECT * FROM ANALISIS..MUSICA_VIP WHERE REPLACE(TELEFONO, '-', '') IN('1146124641',
'2614247890',
'1149118717',
'2974445756',
'2322424899',
'1146625390',
'29444940325',
'2994477313',
'1149516600',
'1143721838',
'2214616784',
'2284422077',
'1149410493',
'2627432544',
'1146652368',
'1148664215',
'2964427003',
'2473421759',
'2623433063',
'2994473781')

SELECT * FROM ANALISIS..MUSICA_PARA_ENVIAR WHERE RTRIM(CD_INTERURBANO)+RTRIM(CD_URBANO)+CD_LINEA IN ('1146124641',
'2614247890',
'1149118717',
'2974445756',
'2322424899',
'1146625390',
'29444940325',
'2994477313',
'1149516600',
'1143721838',
'2214616784',
'2284422077',
'1149410493',
'2627432544',
'1146652368',
'1148664215',
'2964427003',
'2473421759',
'2623433063',
'2994473781')

POSVENTA.DBO.sp_musica_para_enviar 'TELEMAR'

SELECT * FROM ADSL WHERE CD_PEDIDO_CLIENTE = 190627724

SELECT m.* FROM analisis..MUSICA_PARA_ENVIAR m
inner join analisis..musica_tramites t on m.cd_pedido_cliente = t.cd_pedido_cliente and t.fc_cumplimiento is null and t.cd_estado_tramite <> 'pu'
left join posventa..adsl a on a.cd_pedido_cliente = m.cd_pedido_cliente - 20000000000 
WHERE (m.TX_AGENTE_EXTERNO LIKE  @canal+'%' or m.tx_canal LIKE  @canal+'%')
and (a.cd_estado_tramite in ('fa','cu') or a.cd_pedido_cliente is null)
and m.cd_estado_tramite = 'AC'
and dbo.dmy(fc_generacion) >= dateadd(day, -7, dbo.dmy(getdate()))
order by fc_generacion desc



select * from voip_madre_hija