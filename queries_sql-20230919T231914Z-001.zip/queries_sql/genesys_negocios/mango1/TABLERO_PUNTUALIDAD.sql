delete from inbox
select * into inbox from openquery(dw, 'Select	fc_recepcion || '' '' || hr_recepcion fh_entrada, fc_accion_tomada || '' '' || hr_accion_tomada fh_accion, c.*
From	vwd_contactos.caso_bandeja c where cd_caso like ''35%'' and tx_bandeja_recibe in (select tx_inbox from tmp_usuarios.mango_rooster_bo) 
and year(fc_envio) = year(date)')



select cd_caso  from inbox i inner join rooster r on i.tx_bandeja_recibe = r.inbox and sup = 'roxana' group by by cd_caso
select * from rooster
select nombres, sum(1), avg(datediff(hour,fh_entrada, fh_accion)) tmr from inbox i left join rooster r on i.tx_bandeja_recibe = r.inbox 
group by nombres
select * from inbox where cd_caso = 350010655291 order by cd_secuencia_ba

SELECT * FROM CASOS WHERE CD_CASO = 350010655291

select * from inbox where cd_caso in (select cd_caso from casos where cd_estado_new = 57)

select * from 

select top 10 * from casos

select sup,month(fh_entrada), sum(1), 
avg(cast(datediff(hour,fh_entrada, fh_accion)as real)) tmr
from inbox i inner join rooster r 
	on i.tx_bandeja_recibe = r.inbox 
where tx_accion_tomada = 'gestionado'
group by sup,month(fh_entrada)--,nombres
order by sup,month(fh_entrada)--,nombres


use posventa
sp_helptext IND_HORA_ACT 'prod_diaria'

CREATE PROCEDURE ind_hora_act (@producto as varchar(12)) AS  
if @producto = 'TB'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_tb'  
end  
if @producto = 'VOIP'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_VOIP'  
end  
if @producto = 'ADSL'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act'  
end  
if @producto = 'CAM24'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_cam24'  
end  
if @producto = 'LAN'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_lan'  
end  
if @producto = 'VPN'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_vpn'  
end  
if @producto = 'MUSICA'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_musica'  
end  
if @producto = 'TB+ADSL'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'ind_act_tbadsl'  
end  
if @producto = 'PGC'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'PGC'  
end  
if @producto = 'CANCELADORES'  
begin  
 select max(timestamp) as [timestamp] from vitacora where app = 'CANCELADORES'  
end  
if @producto = 'PROD_DIARIA'  
begin  
 SELECT max(timestamp) as [timestamp] from vitacora where app = 'PD_IND' 
select * into vitacora_old from vitacora where year(timestamp)< 2010
delete from vitacora where year(timestamp)< 2010
end  
if @producto = 'LINEA400'  
begin  
 SELECT max(timestamp) as [timestamp] from vitacora where app = 'LINEA400'  
end  
if @producto = 'BIENVENIDA'  
begin  
 SELECT max(timestamp) as [timestamp] from vitacora where app = 'BIENVENIDA'  
end  
if @producto = 'ind_rangos'  
begin  
 SELECT max(timestamp) as [timestamp] from vitacora where app = 'ind_rangos'  
end
use posventa
DBCC CHECKTABLE ('vitacora')
select * from pd_indicadores
 sp_pd_listar 'tb',12,2010

select  
month(fh_entrada),sup,
SUM(CASE WHEN datediff(hour,fh_entrada, fh_accion) < 12 THEN 1 ELSE 0 END), SUM(1) 
from inbox i inner join rooster r on i.tx_bandeja_envia = r.inbox
WHERE tx_accion_tomada = 'GESTIONADO'
GROUP BY month(fh_entrada),sup
order by month(fh_entrada),sup
master..xp_cmdshell 'shutdown -r'

SELECT * FROM INBOX i inner join rooster r on i.tx_bandeja_envia = r.inbox 
WHERE tx_accion_tomada = 'GESTIONADO' 
AND SUP = 'BATISTA' 
AND CAST(FH_ENTRADA AS DATETIME) BETWEEN '01/11/2010' AND '30/11/2010'




select max(fh_entrada) from inbox i inner join rooster r 
	on i.tx_bandeja_recibe = r.inbox and sup = 'roxana' 






select avg(cast(datediff(hour,fh_entrada, fh_accion)as real)) from inbox i inner join rooster r 
	on i.tx_bandeja_recibe = r.inbox and sup = 'roxana'

print DBO.PD(DATEADD(MONTH,-12,GETDATE()))

select cd_caso from casos group by cd_caso having count(*) >3


t casos

select * from casos where cd_caso in 
	(select cd_caso from casos where cd_caso in (select cd_caso  from inbox i inner join rooster r on i.tx_bandeja_recibe = r.inbox and sup = 'roxana' and month(fh_entrada) = 4))

select distinct * from inbox i inner join rooster r on i.tx_bandeja_recibe = r.inbox and sup = 'roxana' and month(fh_entrada) = 4
and cd_caso  in (select cd_caso from casos)



