select * into #p from openquery([10.105.8.249], 
'select p.ani, c.cd_tipo_cliente
from visualizador..v_parque_tb_sp p 
	inner join rete..party c 
		on p.cd_party_titular = c.cd_party_titular')


SELECT p.cd_tipo_cliente, t1.tx_tipo_cliente, I.CODIGO_CLIENTE, t2.tx_tipo_cliente, *
FROM IVR I INNER JOIN #p P ON I.ANI_POSTDISCADO = P.ANI AND CODIGO_CLIENTE IS NOT NULL
	left join dt_tipo_cliente t1 on p.cd_tipo_cliente = t1.cd_tipo_cliente 
	left join dt_tipo_cliente t2 on I.CODIGO_CLIENTE = t2.cd_tipo_cliente
WHERE P.CD_TIPO_CLIENTE COLLATE Modern_Spanish_CI_AS <> I.CODIGO_CLIENTE

select * into dt_tipo_cliente from openquery(dw,'select * from tasa.party_tipo_cliente where cd_unidad_negocio = ''pym''')
select * from dt_tipo_cliente