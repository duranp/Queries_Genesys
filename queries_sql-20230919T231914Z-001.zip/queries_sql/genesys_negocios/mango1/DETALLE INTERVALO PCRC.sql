
select a.timestamp,pcrc,
convert(decimal(10,2),sum(loggedintime)/cast(900 as decimal(10,2)))as logueadosa,convert(decimal(10,2),(sum(loggedintime)-cast(isnull(sum(activity),0) as decimal(10,2)))/900) as 'logueados sin activity'
from SYMPOSIUM..iagentperformancestat as a
left join 
	(select timestamp,agentlogin, sum(activitytime) as activity 
	from SYMPOSIUM..iactivitycodestat 
	where activitycode not like '%0%'group by  timestamp,agentlogin) as i 
		on i.timestamp=a.timestamp and i.agentlogin=a.agentlogin
	inner join (select distinct supervisorsurname,supervisorgivenname,supervisortelsetloginid from agentes..supervisoragentassignment where type='p') as s 
		on supervisorlogin=supervisortelsetloginid
	inner join (select * from aplicaciones..supervisores_X_pcrc /*where pcrc=@pcrc */)as p on p.supervisor=s.supervisortelsetloginid
where datepart(dd,a.timestamp)=datepart(dd,getdate())and  
datepart(mm,a.timestamp)=datepart(mm,getdate()-1) and datepart(year,a.timestamp)=datepart(year,getdate()-1)and supervisortelsetloginid in (select supervisor from aplicaciones..supervisores_x_pcrc /*where pcrc=@pcrc*/)
group by a.timestamp,pcrc

select top 10 * from SYMPOSIUM..iagentperformancestat

select * from agentes..supervisoragentassignment


select timestamp, s.supervisorsurname, s.supervisorgivenname, i.agentsurname, i.agentgivenname, sum(loggedintime) l  from 
 SYMPOSIUM..iagentperformancestat i
inner join agentes..supervisoragentassignment s on type='p' and i.agentlogin = s.agenttelsetloginid
inner join aplicaciones..supervisores_x_pcrc on pcrc='nc mcd' and supervisor = s.supervisortelsetloginid
where timestamp = '02/02/2011 11:30:00'
group by timestamp, s.supervisorsurname, s.supervisorgivenname, i.agentsurname, i.agentgivenname
order by timestamp, s.supervisorsurname, s.supervisorgivenname, i.agentsurname, i.agentgivenname