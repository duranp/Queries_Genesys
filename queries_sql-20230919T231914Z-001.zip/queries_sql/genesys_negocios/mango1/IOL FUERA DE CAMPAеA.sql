select distinct tx_g_resultado from pgc_acciones
drop table borrar_pedidos_iol
select distinct p.cd_pedido, p.cd_sub_pedido, p.cd_central, e.timestamp
into borrar_pedidos_iol
from vw_pgc_estados e
	inner join pgc_pedidos p
		on p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		AND (tx_g_resultado like '%(aei)%' or tx_g_motivo_real like '%(aei)%')
		and timestamp = (select max(timestamp) from vw_pgc_estados  where 
							cd_pedido = p.cd_pedido
							and cd_sub_pedido = p.cd_sub_pedido
							AND (tx_g_resultado like '%(aei)%' or tx_g_motivo_real like '%(aei)%'))

select cd_pedido, cd_sub_pedido,sum(1) from borrar_pedidos_iol group by cd_pedido, cd_sub_pedido  having sum(1) >1 

select * from borrar_pedidos_iol where cd_pedido = 187514008

--infromados fuera de campa�a -- drop table #si
select distinct p.*,iol.timestamp, pip.tx_motivo 
into #no
from pgc_pedidos p 
	left join BORRAR_INFORMADOS_PEGASO pip 
		on p.cd_pedido = pip.cd_pedido 
		and p.cd_sub_pedido = pip.cd_sub_pedido
		and datepart(weekday,timestamp) not in (6,7)
	LEFT JOIN BORRAR_PEDIDOS_IOL IOL
		on p.cd_pedido = IOL.cd_pedido 
		and p.cd_sub_pedido = IOL.cd_sub_pedido
where 
p.cd_central in (select cd_central from borrar_pedidos_iol)
and p.cd_pedido not in (select cd_pedido from borrar_pedidos_iol)
and (pip.timestamp >= '22/03/2010' or iol.timestamp >= '22/03/2010')
and p.cd_producto_pgc in ('tb','tb mp') and fc_cumplimiento is not null and tx_estado = 'fa'


select distinct n.*, e.tx_central, e.tx_distrito_atc, e.tx_gerencia from #no n 
	left join dt_estructura e
		on n.cd_central = e.cd_central

select *from dt_estructura
select * from borrar_informados_pegaso where cd_pedido in (select cd_pedido from #no)


select avg(datediff(day,fc_emision,fc_cumplimiento)) from #no
select avg(datediff(day,fc_emision,fc_cumplimiento)) from #si
select* from #si

select sum(1) from borrar_informados_pegaso

select sum(1)--distinct cd_pedido, cd_sub_pedido, cd_tramite 
from pgc_pedidos where fc_emision >= '01/01/2010' and
cd_producto_pgc in (
'ADSL', 
'EQ VOIP',
'CAM24',
'FWT',
'LAN OFFICE',
'MIGR LAN',
'MIGR VOIP',
'PC',
'PDTI',
'SFT-MUSICA',
'SPD READY',
'TB',
'TB MP',
'VOIP',
'VPN')


tb no 19 si 17

