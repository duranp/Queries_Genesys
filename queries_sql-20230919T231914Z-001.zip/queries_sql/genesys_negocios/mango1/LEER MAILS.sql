--borrar mail
DECLARE @status int, @message_id varchar(255), @body varchar(7500), @timestamp varchar(255)
EXEC  @status = [10.244.65.234].master..xp_findnextmsg @msg_id = @message_id OUTPUT
while  isnull(@message_id,'carcamanchoclo') <> 'carcamanchoclo' and @status = 0
begin
	DECLARE @originator_address VARCHAR(1000)
	EXEC [10.244.65.234].master..XP_READMAIL @MSG_ID=@message_id, @originator_address = @originator_address OUTPUT, @message=@body OUT, @date_received=@timestamp OUT
	insert into e_mails  (tx_mail,tx_body, fc_mail) values (@originator_address, left(@body,7500),convert(datetime,@timestamp,101))
	EXEC [10.244.65.234].master..xp_sendmail @recipients = @originator_address, @subject = 'Satisfacci�n Telefonica Negocios', @message='<b>Estimado Cliente, esta casilla no esta configurada para recibir mails. Por favor tenga a bien comunicarse con el 0800-333-7733. gracais</b>'
	exec [10.244.65.234].master..xp_deletemail @msg_id = @message_id
	EXEC  @status = [10.244.65.234].master..xp_findnextmsg @msg_id = @message_id OUTPUT
end

select * from e_mails
select @@version

select convert(datetime,'13:02:11 2010-08-10', 101)


