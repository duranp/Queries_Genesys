



SELECT     top 5000  averias.cd_party_titular, averias.fh_ingreso, tipo_actuacion.tx_tipo_actuacion, averias.fh_cierre, tipo_actuacion_1.tx_tipo_actuacion AS Expr1, 
                      averias.cd_tipo_cliente, averias.tx_tipo_cliente, averias.ANI, averias.fl_imputable
FROM         averias inner JOIN
                      tipo_actuacion ON averias.cd_tipo_actuacion_apertura = tipo_actuacion.cd_tipo_actuacion left JOIN
                      tipo_actuacion AS tipo_actuacion_1 ON averias.cd_tipo_actuacion_cierre = tipo_actuacion_1.cd_tipo_actuacion
where 
year(fh_cierre) = 2011 
fh_cierre is null