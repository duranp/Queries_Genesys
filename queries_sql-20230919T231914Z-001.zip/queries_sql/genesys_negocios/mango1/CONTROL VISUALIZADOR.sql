
--DROP TABLE #P
select p.*, f.tx_fdv, c.tx_canal into #p from posventa.posventa.dbo.pgc_pedidos p 
	left join posventa.posventa.dbo.pgc_fdv f 
		on p.cd_fdv = f.cd_fdv
	left join posventa.posventa.dbo.pgc_canal c
		on '020'+p.cd_canal = c.cd_canal

select * into #v from tic.visualizador.dbo.v_vitacora where r_tb_pe is not null


select * from #p p inner join #v v on p.cd_central = v.cd_central and p.cd_manzana = v.cd_manzana and v.timestamp < p.fc_emision and (r_tb_pe = 'no' or r_tb_pi ='no' OR R_ZP IN ('PG','PI'))
and cd_producto_pgc IN ('tb','TB MP')

SELECT * FROM POSVENTA.POSVENTA.DBO.dt_canal WHERE CD_MOTIVO = 320
SELECT * FROM #V



select * from analisis..musica_para_enviar 
where rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea = '2234743310'
order by fc_generacion desc
select * from analisis..musica_tramites 
where rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea = '2234743310'
order by fc_emision desc

select * from analisis..musica_vip order by [fecha mov] desc


select * from 



select * from analisis..musica_para_enviar oder by fc_generacion desc