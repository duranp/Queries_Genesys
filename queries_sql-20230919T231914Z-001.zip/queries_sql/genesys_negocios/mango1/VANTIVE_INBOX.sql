
DROP TABLE #T
SELECT  datediff(hour,swdatereceived,swdateactiontaken)TMG, SUP,NOMBRES AG, MONTH(SWDATEACTIONTAKEN) MES 
INTO #T
FROM INBOX I inner join rooster r on i.swreceiver = r.inbox and swactiontaken = 'gestionado'
AND YEAR(SWDATEACTIONTAKEN) = 2011

SELECT * FROM ROOSTER
SELECT * FROM #T

--SUP
SELECT DISTINCT SUP,MES,
(select MAX(TMG) from 
	(select top 80 percent with ties TMG from #T where  SUP = T.SUP AND MES = T.MES order by TMG)A
)'80',
(SELECT SUM(1) FROM #T where  SUP = T.SUP AND MES = T.MES) Q,
(SELECT AVG(TMG) FROM #T WHERE SUP = T.SUP AND MES = T.MES) TMG
FROM #T T
ORDER BY SUP,MES

--AGENT
SELECT DISTINCT SUP,AG,MES,
(select MAX(TMG) from 
	(select top 80 percent with ties TMG from #T where  AG = T.AG AND MES = T.MES order by TMG)A
)'80',
(SELECT SUM(1) FROM #T where  AG = T.AG AND MES = T.MES) Q,
(SELECT AVG(TMG) FROM #T WHERE AG = T.AG AND MES = T.MES) TMG
FROM #T T
ORDER BY SUP,AG,MES

SELECT * FROM INBOX WHERE SWDATEACTIONTAKEN IS NULL











SELECT  datediff(hour,swdatereceived,swdateactiontaken)TMG,* FROM INBOX I inner join rooster r on i.swreceiver = r.inbox and swactiontaken = 'gestionado' 
AND SUP = 'BATISTA' AND MONTH(SWDATEACTIONTAKEN) = 6

select year(SWDATEACTIONTAKEN), month(SWDATEACTIONTAKEN) mes , avg(datediff(hour,swdatereceived,swdateactiontaken))tmg, sum(1)q, sup 
from inbox i inner join rooster_bo r 
	on i.swreceiver = r.inbox and swactiontaken = 'Gestionado' AND YEAR(SWDATEACTIONTAKEN) >= 2010
group by sup,month(SWDATEACTIONTAKEN),year(SWDATEACTIONTAKEN)
order by sup,year(SWDATEACTIONTAKEN),month(SWDATEACTIONTAKEN)


SELECT * FROM INBOX WHERE SWDATEACTIONTAKEN >= GETDATE()

DELETE FROM IVR WHERE MES = 10

select * from inbox_p where [tipo cliente tasa] not like 'temp%'

select * from rooster_bo


select [inbox tiene objeto], suM(1)
from inbox_p 
where [id de objeto] IN 
(select swobjectid from inbox i inner join rooster_bo r on r.inbox = swreceiver)
and year([fecha apertura]) >= 2010
group by [inbox tiene objeto]
order by suM(1) desc

select [mot/ev/tar], submotivo, sum(case when datediff(day,[fecha apertura],getdate()) > 15 then 1 else 0 end), sum(1)
from inbox_p i --inner join rooster_bo r on r.inbox = [inbox tiene objeto] 
where estado = 'abierto' 
group by [mot/ev/tar], submotivo
order by suM(1) desc

select clasificacion, solucion, sum(case when datediff(day,[fecha apertura],getdate()) > 15 then 1 else 0 end), sum(1)
from inbox_p i --inner join rooster_bo r on r.inbox = [inbox tiene objeto] 
where estado = 'abierto' and [mot/ev/tar] = ''
group by clasificacion, solucion
order by suM(1) desc

select * from inbox_p where CLASIFICACION LIKE '%VELOC%'

SELECT SUM(1) FROM CASOS WHERE SWSTATUS = 'ABIERTO'

select year([fecha apertura]), sum(1)  from inbox_p group by year([fecha apertura])
order by year([fecha apertura])

select year([fecha apertura]),year([fecha apertura])sup, sum(1)  
from inbox_p i inner join rooster_bo r on r.inbox = [inbox tiene objeto] 
group by sup,year([fecha apertura])
order by year([fecha apertura])

select * from inbox_p i inner join rooster_bo r on r.inbox = [inbox tiene objeto] and sup = 'blanco'



select top 1000 * from casos

select * from casos where swstatus = 'abierto'


--abiertos y en inbox
select *, 
case when exists(select * from inbox_p i inner join rooster_bo r on r.inbox = [inbox tiene objeto] and [id de objeto] = c.swcaseid) then 1 else 0 end en_inbox
into #p
 from vw_casos c where swstatus = 'abierto'

select motivo,submotivo,clasificacion, sum(1), 
sum(case when datediff(d,swdatecreated,getdate()) between 0 and 2  then 1 else 0 end) [0-2],
sum(case when datediff(d,swdatecreated,getdate()) between 3 and 7  then 1 else 0 end) [3-7],
sum(case when datediff(d,swdatecreated,getdate()) between 8 and 15  then 1 else 0 end) [8-15],
sum(case when datediff(d,swdatecreated,getdate()) between 16 and 365  then 1 else 0 end) [16-365],
sum(case when datediff(d,swdatecreated,getdate()) > 366 then 1 else 0 end) [>366],
sum(en_inbox)
from #p  --where en_inbox = 1
group by motivo,submotivo,clasificacion
order by sum(1) desc

select * from inbox_p

select  [mot/ev/tar], submotivo, clasificacion,  
sum(case when datediff(d,[fecha apertura],getdate()) between 0 and 2  then 1 else 0 end) [0-2],
sum(case when datediff(d,[fecha apertura],getdate()) between 3 and 7  then 1 else 0 end) [3-7],
sum(case when datediff(d,[fecha apertura],getdate()) between 8 and 15  then 1 else 0 end) [8-15],
sum(case when datediff(d,[fecha apertura],getdate()) between 16 and 365  then 1 else 0 end) [16-365],
sum(case when datediff(d,[fecha apertura],getdate()) > 366 then 1 else 0 end) [>366],
case when [inbox tiene objeto] in (select inbox from rooster_bo) then 1 else 0 end en_inbox
from inbox_p c
group by [mot/ev/tar], submotivo, clasificacion

t casos

select * from vw_casos where motivo = 'aver�as' and datediff(d,swdatecreated,getdate()) > 366 and swstatus = 'abierto'