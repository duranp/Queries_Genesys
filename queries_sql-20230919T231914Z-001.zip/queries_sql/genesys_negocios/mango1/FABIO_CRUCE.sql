use posventa
select distinct a.*, t.cd_estado_tramite, ad.cd_estado_tramite from analisis..fabio_cruzar a 
	left join tb t on a.pedido = t.cd_pedido_cliente and a.subpedido = t.cd_sub_pedido and a.tramite = t.cd_tramite
	left join adsl ad on a.pedido = ad.cd_pedido_cliente and a.subpedido = ad.cd_sub_pedido and a.tramite = ad.cd_tramite