select distinct max(len(tx_localidad)) FROM V_MANZANERO 

select top 10 tx_calle from (select distinct tx_calle from v_manzanero)a
select top 10 * from v_manzanero

SP_GET_LOCALIDAD_FULL

select * from v_manzanero where tx_localidad = 'godoy cruz' and tx_calle = 'san martin'


declare @tx_calle as varchar(50)
declare @numero as int
set @tx_calle = 'viamonte'
set @numero = 750

SELECT * FROM V_MANZANERO 
WHERE TX_CALLE LIKE '%' + @TX_CALLE + '%' 
--RANGO DE NUMERACION
AND @NUMERO BETWEEN NU_DESDE AND NU_HASTA 
--PARES CON PARES E IMPARES CON IMPARES
AND @NUMERO % 2 = NU_DESDE % 2
ORDER BY TX_LOCALIDAD

DELETE from v_manzanero where isnumeric(nu_desde) = 0


sp_get_localidad_full 

SELECT * FROM OPENQUERY(DW,'SELECT TOP 10 * FROM TASA.PARTY WHERE ISNUMERIC(CD_PARTY) = 0')

sp_get_localidad 'AMEGHINO F DR',1697
sp_get_manz_ady 361, 95, 'AMEGHINO F DR',1697
sp_helptext 'sp_get_manz_ady'

676, 32

select * from v_pe where cd_central = 361 and manzana = 95
TRUNCATE TABLE  V_PE
INSERT INTO V_PE
SELECT * FROM BCP_PE

select top 10 * from v_manzanero where tx_calle = 'itaqui' and 6918 between nu_desde and nu_hasta
sp_helptext 'sp_bv'

select * from v_parque_tb_sp where ani ='1143827089'

declare @central int, @manzana int, @ani VARCHAR(10), @calle varchar(100), @numero bigint
set @ani = '1142005331'
select @central = cd_central, @manzana = cd_manzana, @calle = tx_calle, @numero = nu_calle from v_parque_tb_sp where ani = @ani
print @central 
print @manzana

exec sp_get_manz_ady @central, @manzana, @calle, @numero

sp_helptext 'sp_get_manz_ady'
select count(*) from v_manzanero where isnumeric(nu_desde)=1 and isnumeric(nu_hasta)=1 

create procedure sp_get_manz_ady_ani (@ani as varchar(10))
as
declare @central int, @manzana int, @calle varchar(100), @numero bigint
select @central = cd_central, @manzana = cd_manzana, @calle = tx_calle, @numero = nu_calle from v_parque_tb_sp where ani = @ani
exec sp_get_manz_ady @central, @manzana, @calle, @numero
go

sp_get_manz_ady_ani '1142005331'

select * from cam24 WHERE CD_PRODUCTO LIKE ALL('%','1')

select * from v_vitacora order by timestamp desc
select * from BCP_manzanero where isnumeric(nu_desde) = 1

SELECT * FROM USUARIOS

SELECT * FROM PDTI_VOIP_IVR