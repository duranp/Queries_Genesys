select      tx_tipo_producto, dbo.dmy(fc_cumplimiento) fc_cumplimiento, dbo.dmy(timestamp) fc_outed, sum(1)
from  bv_outed o
            inner join bv_source s
                  on s.cd_pedido = o.cd_pedido
                  and s.cd_sub_pedido = o.cd_sub_pedido
where fc_cumplimiento  >= '20090901'
group by dbo.dmy(fc_cumplimiento), dbo.dmy(timestamp), timestamp, tx_tipo_producto


