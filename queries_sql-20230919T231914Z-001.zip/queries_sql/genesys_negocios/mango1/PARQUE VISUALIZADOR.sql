
checkpoint
EXEC sp_addumpdevice 'disk', 'CopiaPOSVENTA2', 'LogMiBase.bak'

BACKUP DATABASE POSVENTA TO CopiaPOSVENTA2
BACKUP LOG posventa TO CopiaPOSVENTA

DBCC SHRINKFILE (posventa_log,1,emptyfile)

SELECT GETDATE()

delete from v_parque_tb_sp 
select ani from v_parque_tb_sp group by ani having count(*)>1
1144531665
1149581053
2202456616
2202486310
2234730763
2234757115
2241430366
2293389166
2914517340

select * from v_parque_tb_sp where ani = '2914517340'

select * from syscolumns where name = 'ani'

select * from sysobjects where id = 709577566

select * from v_manzanero where cd_central = 34 and cd_manzana = 1446

select top 10 *from v_parque_tb_sp where ani ='1142924293'

select count(*), count(distinct ani) from (
select * from bcp_parque_tb_sp p 
where (len(tx_producto) = (select top 1 len(tx_producto) from bcp_parque_tb_sp where ani = p.ani)
or tx_producto is null)
and ani not in (select ani from bcp_parque_tb_sp where ani = p.ani and not(nu_calle=p.nu_calle))

)x
--4642427
select count(*), count(distinct ani) from v_parque_tb_sp
--4642490	4642418


