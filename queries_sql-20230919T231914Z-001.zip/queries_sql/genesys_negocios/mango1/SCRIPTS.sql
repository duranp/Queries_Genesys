
DELETE FROM v_reglas_scripts
insert into v_reglas_scripts values('TB','1,2,3,4,5',NULL,NULL,'7','7')
insert into v_reglas_scripts values('SP',NULL,'5',NULL,'6','7')
insert into v_reglas_scripts values('VOIP',NULL,NULL,'3','6','7')
insert into v_reglas_scripts values('TB+SP','1,2,3,4,5','4',NULL,'7','7')
insert into v_reglas_scripts values('SP+VOIP',NULL,'4','4','6','7')
SELECT * FROM v_reglas_scripts 


ALTER PROCEDURE SP_SCRIPTS (@CD_PRODUCTO AS VARCHAR(50), @TB BIT, @SP BIT, @VOIP BIT, @ZP CHAR(2))
AS
	SELECT CD_PRODUCTO,
	CASE WHEN (CASE WHEN TB   IS NOT NULL THEN 1 ELSE 0 END) = @TB   THEN TB   ELSE NULL END TB,
	CASE WHEN (CASE WHEN SP   IS NOT NULL THEN 1 ELSE 0 END) = @SP   THEN SP   ELSE NULL END SP,
	CASE WHEN (CASE WHEN VOIP IS NOT NULL THEN 1 ELSE 0 END) = @VOIP THEN VOIP ELSE NULL END VOIP,
	CASE WHEN @ZP IN ('PG','AM') AND ZP IS NOT NULL THEN ZP  
		 WHEN @ZP = 'PI'         AND ZI IS NOT NULL THEN ZI 
		 ELSE NULL END ZI
	FROM V_REGLAS_SCRIPTS WHERE CD_PRODUCTO = @CD_PRODUCTO 
GO

ALTER PROCEDURE SP_SCRIPTS (@CD_PRODUCTO AS VARCHAR(50), @TB BIT, @SP BIT, @VOIP BIT, @ZP CHAR(2))
AS
	SELECT CD_PRODUCTO,
	CASE WHEN (CASE WHEN TB   IS NOT NULL THEN 1 ELSE 0 END) = @TB   THEN TB   ELSE NULL END TB,
	CASE WHEN (CASE WHEN SP   IS NOT NULL THEN 1 ELSE 0 END) = @SP   THEN SP   ELSE NULL END SP,
	CASE WHEN (CASE WHEN VOIP IS NOT NULL THEN 1 ELSE 0 END) = @VOIP THEN VOIP ELSE NULL END VOIP,
	CASE WHEN @ZP IN ('PG','AM') AND ZP IS NOT NULL THEN ZP  
		 WHEN @ZP = 'PI'         AND ZI IS NOT NULL THEN ZI 
		 ELSE CASE WHEN (CASE WHEN VOIP IS NOT NULL THEN 1 ELSE null END) = @VOIP THEN VOIP ELSE 
				CASE WHEN (CASE WHEN SP IS NOT NULL THEN 1 ELSE null END) = @SP   THEN SP ELSE 
					CASE WHEN (CASE WHEN TB   IS NOT NULL THEN 1 ELSE null END) = @TB   THEN TB
						ELSE NULL    		 
	END END END 	
	END SCRIPTS
	FROM V_REGLAS_SCRIPTS WHERE CD_PRODUCTO = @CD_PRODUCTO 
GO


SP_SCRIPTS 'TB+SP',0,0,0,''

SELECT * FROM v_reglas_scripts 
SELECT * FROM V_SCRIPTS where tx_script like '%caso s%'


CREATE PROCEDURE SP_GET_SCRIPT (@CD_SCRIPT AS TINYINT)
AS
	SELECT * FROM V_SCRIPTS WHERE CD_SCRIPT = @CD_SCRIPT
GO

GRANT EXEC ON SP_GET_SCRIPT TO V
SP_GET_SCRIPT 5
 update v_scripts set tx_script = replace(cast(tx_script as varchar(8000)),'hablar?','hablar?<br>')


sp_scripts 'VOIP',1,0,1,'pg'

select * from v_retrabajos r left join v_parque_tb_sp p on r.cd_central = p.cd_central and r.cd_manzana = p.cd_manzana and r.vl_numero = p.nu_calle and r.tx_calle = p.tx_calle
select * from v_parque_tb_sp p left join v_zona_peligrosa z on p.cd_central = z.cd_central where Nu_longitud_linea > 4500 and z.cd_central is null

SELECT 

update v_scripts set tx_script = replace(cast(tx_script as varchar(8000)),'Buenos d�as/ tardes, mi nombre es (nombre y apellido) de Telef�nica Negocios.�Es Usted el responsable de la l�nea? �Con quien tengo el gusto de hablar?<br> Buenos d�as/ tardes, mi nombre es (nombre y apellido) de Telef�nica Negocios.�Es Usted el responsable de la l�nea? �Con quien tengo el gusto de hablar?<br> Me comunico con usted para informarle acerca de su solicitud de (producto que corresponda).  Debido a que su pedido se encuentra en un �rea donde nos encontramos actualmente sin capacidad, el mismo se vera demorado hasta que se realice la correspondiente obra. Este tipo de obra de ampliaci�n de red, suele tener tiempos extensos hasta su finalizaci�n y es por eso que nos comunicamos con usted para ofrecerle una alternativa que podr�amos brindarle sin la necesidad de que tenga que esperar a la finalizaci�n de la obra. La alternativa de la que le hablo se llama L�nea Vip, este producto es similar a la Telefon�a B�sica, la �nica diferencia es que utiliza la tecnolog�a de Internet para comunicarse. Hemos constatado que usted tiene la l�nea XXXXXXX en el mismo domicilio, de esta forma deber�amos instalar Speedy Lan Office + L�nea Vip para que usted contara con el servicio solicitado, con el beneficio adicional de que esta nueva l�nea tendr� llamadas locales ilimitadas y otros servicios gratuitos que en la Telefon�a B�sica no esta incluidos y contar�a con todas las ventajas de Internet.','<B>Buenos d�as/ tardes, mi nombre es (nombre y apellido) de Telef�nica Negocios.�Es Usted el responsable de la l�nea? �Con quien tengo el gusto de hablar?<br> Buenos d�as/ tardes, mi nombre es (nombre y apellido) de Telef�nica Negocios.�Es Usted el responsable de la l�nea? �Con quien tengo el gusto de hablar?<br> Me comunico con usted para informarle acerca de su solicitud de (producto que corresponda).  Debido a que su pedido se encuentra en un �rea donde nos encontramos actualmente sin capacidad, el mismo se vera demorado hasta que se realice la correspondiente obra. Este tipo de obra de ampliaci�n de red, suele tener tiempos extensos hasta su finalizaci�n y es por eso que nos comunicamos con usted para ofrecerle una alternativa que podr�amos brindarle sin la necesidad de que tenga que esperar a la finalizaci�n de la obra. La alternativa de la que le hablo se llama L�nea Vip, este producto es similar a la Telefon�a B�sica, la �nica diferencia es que utiliza la tecnolog�a de Internet para comunicarse. Hemos constatado que usted tiene la l�nea XXXXXXX en el mismo domicilio, de esta forma deber�amos instalar Speedy Lan Office + L�nea Vip para que usted contara con el servicio solicitado, con el beneficio adicional de que esta nueva l�nea tendr� llamadas locales ilimitadas y otros servicios gratuitos que en la Telefon�a B�sica no esta incluidos y contar�a con todas las ventajas de Internet.</B>')


sp_scripts 'SP',1,1,0,'NO'

select @@version


