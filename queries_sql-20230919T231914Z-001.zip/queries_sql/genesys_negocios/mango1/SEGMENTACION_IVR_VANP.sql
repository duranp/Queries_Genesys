use vtv

select producto, motivo, year(swdatecreated) anio, month(swdatecreated) mes, sum(1) 
from vw_casos 
where year(swdatecreated) >= 2010
group by producto, motivo, year(swdatecreated), month(swdatecreated) 
order by year(swdatecreated), month(swdatecreated) 

select top 10 * from vw_casos

select * into ivr from openquery(genesys,'select * from TABLERO.UNPRE_TOTAL')

select * from parque_basica where ANI = 1146621193
drop table #p


select * into #p from openquery([10.105.8.249], 
'select p.ani, c.cd_tipo_cliente
from visualizador..v_parque_tb_sp p 
	inner join rete..party c 
		on p.cd_party_titular = c.cd_party_titular')

select top 10 * from parque_basica

SELECT * FROM IVR

SELECT SUM(1) FROM IVR I INNER JOIN parque_basica P ON I.ANI_POSTDISCADO = P.ANI AND CODIGO_CLIENTE IS NOT NULL
WHERE P.CD_TIPO_CLIENTE COLLATE Modern_Spanish_CI_AS <> I.CODIGO_CLIENTE

select top 10 * from vanp
create table equi (cd_tip_cliente char(2), cctsegcli tinyint)

/*
insert into equi values('03',33)
insert into equi values('0J',27)
insert into equi values('0D',24)
insert into equi values('0F',31)
insert into equi values('0G',32)
insert into equi values('0R',28)
insert into equi values('0I',26)
insert into equi values('0L',29)
insert into equi values('0E',25)
insert into equi values('01',1)
insert into equi values('03',2)
insert into equi values('0K',3)
insert into equi values('0H',30)
insert into equi values('0P',22)
insert into equi values('0Q',21)
insert into equi values('0C',23)
insert into equi values('0A',12)
insert into equi values('05',11)
*/

drop table vanp_final

select v.cctani, p.cd_tipo_cliente, e.cd_tipo_cliente vanp, p.cd_tipo_cliente cota into vanp_final
from vanp v 
	inner join equi e 
		on v.cctsegcli = e.cctsegcli 
	inner join parque_basica p
		on p.ani = v.cctani
where e.cd_tipo_cliente <> p.cd_tipo_cliente

select v.*,t1.tx_tipo_cliente tipo_cliente_cota,t2.tx_tipo_cliente tipo_cliente_vanp  
from vanp_final v
	left join dt_tipo_cliente t1 on v.cota = t1.cd_tipo_cliente 
	left join dt_tipo_cliente t2 on v.vanp = t2.cd_tipo_cliente

select * from equi

select * from parque_basica where ani = 1143223937
sp_helptext dmy


CREATE FUNCTION DMY  (@DATE SMALLDATETIME)    
RETURNS SMALLDATETIME AS    
BEGIN   
  
-- RETURN right('0'+cast(day(@DATE) as varchar(2)),2) + '/' + right('0'+cast(month(@DATE) as varchar(2)),2) + '/' + cast(year(@DATE) as char(4))  
 RETURN convert(varchar(10), @date, 103)  
END  


select suM(1), count(distinct ani) from parque_basica
		



select * from vanp where cctani = 2293445656 
select * from parque_basica where ani = 2293445656

select top 10 * from parque_basica


select * into #v from [10.244.65.234].posventa.dbo.vanp
