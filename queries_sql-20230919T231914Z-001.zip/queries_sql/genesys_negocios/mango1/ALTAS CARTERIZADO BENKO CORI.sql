select * from tb a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio = 'pca'
where cd_estado_tramite in ('fa','cu') and fc_cumplimiento >= '01/01/2010'
union all
select * from cd a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio = 'pca'
where cd_estado_tramite in ('fa','cu') and fc_cumplimiento >= '01/01/2010'


select * from adsl a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio = 'pca'
and cd_motivo_ingreso is null
where cd_estado_tramite in ('fa','cu') and fc_cumplimiento >= '01/01/2010'


select * from pc a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente and t.cd_unidad_negocio = 'pca'
where cd_estado_tramite in ('fa','cu') and fc_cumplimiento >= '01/01/2010'