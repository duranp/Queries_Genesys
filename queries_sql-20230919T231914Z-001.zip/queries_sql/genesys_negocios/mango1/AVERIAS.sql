select sum(1) from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente where fh_cierre is null
select distinct revisador from analisis..borrar_averias_revisador 
drop table analisis..borrar_averias_revisador

select month(fh_cierre) mes, sum(case when revisador = 's' then 1 else 0 end) r, sum(1) t, sum(case when revisador = 's' then 1 else 0 end) /cast (sum(1) as  real) revisador 
from analisis..borrar_averias_revisador where ani in (select ani_madre from voip_madre_hija)
group by month(fh_cierre)
order by month(fh_cierre)

drop table analisis..borrar_averias_revisador

select tx_producto, month(fh_cierre) mes, sum(1) 
from cate..averias where tx_producto in ('CENTREX-RED PRIVADA VIRTUAL','CENTREX-RED PRIVADA VIRTUAL-LINEA INTERNA') and year(fh_cierre) = 2010
group by tx_producto, month(fh_cierre) 
order by tx_producto, month(fh_cierre) 




