select p.ani, t.* from tb t 
	left join adsl a on t.cd_pedido_cliente = a.cd_pedido_cliente and a.tx_producto like '%voip%'
	left join tic.visualizador.dbo.v_retrabajos tic on t.cd_pedido_cliente = tic.cd_pedido
	left join tic.visualizador.dbo.v_parque_tb_sp p 
		on tic.cd_central = p.cd_central
			and tic.cd_manzana = p.cd_manzana
			and tic.tx_calle = p.tx_calle
			and tic.vl_numero = p.nu_calle
where t.cd_producto like '%p%' and t.fc_cumplimiento is null and a.cd_pedido_cliente is null

select * from tic.visualizador.dbo.v_retrabajos 

select distinct [user] from vitacora where app not like '/tableros%' and [user] like 'tasa\%' and timestamp >= '01/06/2010'



select * from v_retrabajos_reglas
