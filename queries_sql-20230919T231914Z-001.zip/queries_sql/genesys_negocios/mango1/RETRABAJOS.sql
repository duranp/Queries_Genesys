select convert(varchar(10),timestamp, 103), sum(1) 
from v_vitacora 
where year(timestamp) = 2010
group by convert(varchar(10),timestamp, 103)

DROP TABLE v_retrabajos_dw
DROP TABLE V_RETRABAJOS ORDER BY FC_CUMPLIMIENTO DESC
drop table v_retrabajos

SELECT p.*, d.cd_manzana, d.tx_calle, d.vl_numero
into V_RETRABAJOS
FROM BCP_RETRABAJOS_PGC P LEFT JOIN BCP_RETRABAJOS_DW D ON P.CD_PEDIDO= D.CD_PEDIDO_CLIENTE AND P.CD_SUB_PEDIDO = D.CD_SUB_PEDIDO
WHERE cd_manzana is not null and isnumeric(vl_numero) =1
select * into v_retrabajos_dw from bcp_retrabajos_dw 

SELECT * FROM BCP_RETRABAJOS_DW WHERE CD_PEDIDO_CLIENTE  =185066766

select * from bcp_retrabajos_dw where cd_pedido_cliente = 185443504
DROP PROCEDURE sp_retrabajos 

CREATE PROCEDURE sp_retrabajos (@CD_CENTRAL SMALLINT, @CD_MANZANA SMALLINT, @CD_PARTY INT, @tx_calle varchar(200), @vl_numero smallint)
AS
select * from v_retrabajos 
where	cd_central = @cd_central 
and		cd_manzana = @cd_manzana 
and		(cd_party = @cd_party or @cd_party is null)
and		(tx_calle = @tx_calle or @tx_calle = '')
and		(vl_numero = @vl_numero or @vl_numero is null)
GO

drop table V_RETRABAJOS_DW
select top 10 * from v_parque_tb_sp

SP_GET_DOMICILIO_ANI 3414111366

select * from v_retrabajos where cd_central = 116 and cd_manzana = 108

SP_GET_DOMICILIO_ANI 2965444664

select * from v_retrabajos where cd_pedido = 177801740
select * from bcp_retrabajos_dw where cd_pedido_cliente = 186795984

sp_helptext SP_GET_DOMICILIO_ANI

select * from v_retrabajos inner join 

alter PROCEDURE SP_GET_DOMICILIO_ANI(@ANI BIGINT)    
AS    
SELECT distinct p.TX_CALLE, p.NU_CALLE, v.tx_localidad, p.cd_central, p.cd_manzana FROM V_PARQUE_TB_SP p   
 left join v_manzanero v   
  on p.cd_central = v.cd_central and v.cd_manzana = p.cd_manzana  
WHERE ANI = @ANI    
go



