select * into #tc from openquery(dw,'select * from tasa.party_tipo_cliente')

select * from #tc where cd_unidad_negocio = 'pym' order by tx_tipo_cliente

select * from (
select count(*) sp, tx_tipo_cliente from parque_speedy 
where ani  not like '11%'
group by tx_tipo_cliente)sp
left join (
select count(*) tb, tx_tipo_cliente from parque_BASICA p inner join dt_tipo_cliente t on p.cd_tipo_cliente = t.cd_tipo_cliente
where cd_interurbano not like '11%'
group by tx_tipo_cliente)tb on sp.tx_tipo_cliente = tb.tx_tipo_cliente