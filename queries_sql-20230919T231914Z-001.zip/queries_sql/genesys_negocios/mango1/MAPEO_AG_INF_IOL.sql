
select 
e1.tx_bandeja, E1.TX_G_RESULTADO, e2.tx_bandeja, E2.TX_G_RESULTADO, e3.tx_bandeja, E3.TX_G_RESULTADO, *--e2.tx_bandeja, sum(1)  
from pgc_estados_pedidos e1
	left join pgc_estados_pedidos e2
		on  e1.cd_pedido = e2.cd_pedido
		and e1.cd_sub_pedido = e2.cd_sub_pedido
		and e1.cd_tramite = e2.cd_tramite
		and e1.cd_orden = e2.cd_orden -1
	left join pgc_estados_pedidos e3
		on  e2.cd_pedido = e3.cd_pedido
		and e2.cd_sub_pedido = e3.cd_sub_pedido
		and e2.cd_tramite = e3.cd_tramite
		and e2.cd_orden = e3.cd_orden -1
where		e1.tx_bandeja = 'agenda gpym' 
		--and e2.tx_bandeja = 'RESULTADO MACRO GPYM'
--group by e2.tx_bandeja
