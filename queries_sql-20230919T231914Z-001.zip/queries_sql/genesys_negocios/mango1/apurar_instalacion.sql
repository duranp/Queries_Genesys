select * from borrar_ap a 
	left join pgc_pedidos p 
		on  a.concatenado = p.cd_ani and (p.cd_producto_pgc like 'tb%' or p.cd_producto_pgc = 'voip') and a.[fecha de apertura] >= p.fc_emision and (p.fc_cumplimiento >a.[fecha de apertura] or p.fc_cumplimiento is null)
	left join pgc_estados_pedidos e 
		on
			e.cd_pedido = p.cd_pedido
			and e.cd_sub_pedido = p.cd_sub_pedido 
			and e.cd_tramite = p.cd_tramite 
			and timestamp = (select max(timestamp) from pgc_estados_pedidos where 
							cd_pedido = p.cd_pedido 
							and cd_sub_pedido = p.cd_sub_pedido 
							and cd_tramite = p.cd_tramite 
							and timestamp < [fecha de apertura] and cd_usuario = 'cota')
	
select * from pgc_estados_pedidos e inner join pgc_pedidos  on
			e.cd_pedido = p.cd_pedido
			and e.cd_sub_pedido = p.cd_sub_pedido 
			and e.cd_tramite = p.cd_tramite
			where 
p.cd_ani = 2994436373 and cd_producto_pgc like 'tb%'

sp_helptext sp_pgc_load_lotes
select * from usuarios

 exec('BULK INSERT #ins FROM ''\\fslezica\PosVenta\bajadas\COTA\gcp_tram_pend_lote' + @a + '.txt''  



