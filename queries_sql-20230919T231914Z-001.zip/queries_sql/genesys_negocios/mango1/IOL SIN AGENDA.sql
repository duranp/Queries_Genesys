--CONTROL DEFINITIVO CON MOTIVOS CONSENSUADOS Y SIN AGENDA
select tx_motivo into #m_iol from indicadores.posventa.dbo.motivos_iol

--en pegaso1\sql2000 -- drop table borrar_noiol
select  e.cd_orden, e.cd_pedido, e.timestamp, e.tx_estado_pgc, ia.cd_orden,ia.tx_estado_pgc, ia.cd_pedido, iol.cd_orden, iol.tx_estado_pgc, iol.tx_accion, p.*
--into borrar_noiol
from pgc_pedidos p
inner join pgc_estados_pedidos e
	on p.cd_pedido = e.cd_pedido
	and p.cd_sub_pedido = e.cd_sub_pedido
	and p.cd_tramite = e.cd_tramite		
	and e.timestamp = (select max(timestamp) from pgc_estados_pedidos where
							e.cd_pedido = cd_pedido
							and e.cd_sub_pedido = cd_sub_pedido
							and e.cd_tramite = cd_tramite										
							and tx_estado_pgc = 'informado'
							and cd_usuario in('cota')
							)		
inner join dt_motivo m on m.cd_motivo = e.cd_motivo and m.tx_motivo in (select tx_motivo from #m_iol)
left join pgc_estados_pedidos ia 
	on p.cd_pedido = ia.cd_pedido
	and p.cd_sub_pedido = ia.cd_sub_pedido
	and p.cd_tramite = ia.cd_tramite				
	and ia.cd_orden = e.cd_orden-2	
	and ia.tx_estado_pgc = 'informar' 
left join pgc_estados_pedidos IOL 
	on p.cd_pedido = IOL.cd_pedido
	and p.cd_sub_pedido = IOL.cd_sub_pedido
	and p.cd_tramite = IOL.cd_tramite				
	and IOL.cd_orden = e.cd_orden-1
	and IOL.tx_G_accion = 'INFORMADOS ONLINE'
where --p.cd_producto_pgc in ('ADSL', 'EQ VOIP', 'CAM24', 'LAN OFFICE', 'TB', 'TB MP', 'VOIP')
 e.timestamp >= '01/05/2010'
and p.cd_pedido = 190836020

select * from pgc_estados_pedidos --where tx_estado_pgc = 'informar' order by timestamp desc
where cd_pedido = 190836020




--en indicadores
select *  from borrar_iol where ia 

select e1.tx_estado_pgc, *--distinct e1.tx_estado_pgc --top 1000 e.cd_orden, e1.cd_orden, e1.tx_estado_pgc,e.*  
from pgc_estados_pedidos e
left join pgc_estados_pedidos e1
	on e1.cd_pedido = e.cd_pedido
	and e1.cd_sub_pedido = e.cd_sub_pedido
	and e1.cd_tramite = e.cd_tramite	
	and e.cd_orden  -1= e1.cd_orden
inner join dt_motivo m on m.cd_motivo = e.cd_motivo --and m.tx_motivo in (select tx_motivo from #m_iol)
 where e.tx_estado_pgc = 'informado' and e.cd_usuario = 'cota' --and e.timestamp >= '01/05/2010'
and e.cd_pedido = 114028176

 and cd_producto_pgc = '' order by cd_orden
 select * from dt_motivo where cd_motivo = 128
 select top 100 cd_motivo, * from pgc_estados_pedidos e where e.cd_pedido = 114028176 and e.tx_estado_pgc = 'informado' and e.cd_usuario = 'cota'--tx_estado_pgc = 'informar'


select e.tx_estado_pgc, e1.tx_estado_pgc,*--e1.tx_estado_pgc, *--distinct e1.tx_estado_pgc --top 1000 e.cd_orden, e1.cd_orden, e1.tx_estado_pgc,e.*  
from pgc_estados e
left join pgc_estados e1
	on e1.cd_pedido = e.cd_pedido
	and e1.cd_sub_pedido = e.cd_sub_pedido
	and e1.cd_tramite = e.cd_tramite	
	and e.cd_orden  -2= e1.cd_orden
inner join dt_motivo m on m.cd_motivo = e.cd_motivo --and m.tx_motivo in (select tx_motivo from #m_iol)
 where e.tx_estado_pgc = 'informado' and e.cd_usuario = 'cota' --and e.timestamp >= '01/05/2010'
 and e.timestamp = (select max(timestamp) from pgc_estados where
							e.cd_pedido = cd_pedido
							and e.cd_sub_pedido = cd_sub_pedido
							and e.cd_tramite = cd_tramite										
							and tx_estado_pgc = 'informado'
							and cd_usuario in('cota')
							)		
and e1.tx_estado_pgc = 'informar'
and e.cd_pedido = 193239496


select * from pgc_estados where tx_estado_pgc = 'informar' and cd_pedido in (selec

INFORMAR
select * from pgc_estados where cd_pedido = 193239496