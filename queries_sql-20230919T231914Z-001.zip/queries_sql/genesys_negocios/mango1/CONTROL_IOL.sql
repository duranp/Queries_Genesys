truncate table motivos_iol
create table motivos_iol (tx_motivo varchar(100))


drop table #inf_adsl
drop table #inf_tb
select * into #enmano from [pegaso1\sql2000].posventa.dbo.borrar_enmano_mayo
--informados
select distinct cd_pedido_cliente - 20000000000 cd_pedido_cliente, cd_sub_pedido, cd_tramite into #inf_tb 
from tb_detalle where tx_motivo in 
	(select tx_motivo from motivos_iol)
and cd_accion = 'inf' 

select distinct cd_pedido_cliente - 20000000000 cd_pedido_cliente, cd_sub_pedido, [cd tramite]cd_tramite into #inf_adsl
from adsl_detalle where tx_motivo in 
	(select tx_motivo from motivos_iol)
and cd_accion = 'inf' 

--en mano
select top 10 * from tb_detalle where tx_canal_detalle = '02zi'

select distinct cd_canal_detalle, tx_canal_detalle from adsl_detalle where tx_canal_detalle like '%generico%'
	
select year(fc_cumplimiento) anio, month(t.fc_cumplimiento) mes, cd_estado_tramite, sum(1), sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) INF
	from tb t 
		left join #inf_tb i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
where t.fc_cumplimiento >= '01/06/2009' and cd_estado_tramite not in ('zz','xx','ac')
group by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 
order by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 

select year(fc_cumplimiento) anio, month(t.fc_cumplimiento) mes, cd_estado_tramite, sum(1), sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) INF
	from adsl t 
		left join #inf_adsl i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
where t.fc_cumplimiento >= '01/06/2009' and cd_estado_tramite not in ('zz','xx','ac')
group by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 
order by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 

drop table #iol
select distinct p.cd_pedido, p.cd_sub_pedido 
into #IOL
from [pegaso1\sql2000].posventa.dbo.pgc_pedidos p 
	inner join [pegaso1\sql2000].posventa.dbo.pgc_estados_pedidos e
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
		and (e.tx_g_resultado like '%(aei)%' or e.tx_g_motivo_real like '%(aei)%')


select 
year(fc_cumplimiento) anio, month(t.fc_cumplimiento) mes,
sum(case when i.cd_pedido_cliente is not null and o.cd_pedido is null then 1 else 0 end) no_paso,
sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) tot_inf,
sum(1) tot,
t.cd_estado_tramite
	from tb t 
		left join #inf_tb i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
		left join #iol o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido
where t.fc_cumplimiento >= '01/06/2009' and cd_estado_tramite not in ('zz','xx','ac')		
group by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 
order by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 

select 
year(fc_cumplimiento) anio, month(t.fc_cumplimiento) mes,
sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) tot_inf,
avg(case when i.cd_pedido_cliente is not null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_tot_inf,
sum(case when i.cd_pedido_cliente is not null and o.cd_pedido is null then 1 else 0 end) no_paso,
avg(case when i.cd_pedido_cliente is not null and o.cd_pedido is null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_no_paso,
sum(case when o.cd_pedido is not null then 1 else 0 end) iol,
avg(case when o.cd_pedido is not null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_iol,
sum(1) tot,
t.cd_estado_tramite
	from tb t 
		left join #inf_tb i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
		left join #enmano e on t.cd_pedido_cliente = e.cd_pedido and t.cd_sub_pedido = e.cd_sub_pedido and t.cd_tramite = e.cd_tramite
		left join #iol o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido
where t.fc_cumplimiento >= '01/06/2009' and cd_estado_tramite not in ('zz','xx','ac')		
group by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 
order by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 

select 
year(fc_cumplimiento) anio, month(t.fc_cumplimiento) mes,
sum(case when i.cd_pedido_cliente is not null then 1 else 0 end) tot_inf,
avg(case when i.cd_pedido_cliente is not null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_tot_inf,
sum(case when i.cd_pedido_cliente is not null and o.cd_pedido is null then 1 else 0 end) no_paso,
avg(case when i.cd_pedido_cliente is not null and o.cd_pedido is null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_no_paso,
sum(case when o.cd_pedido is not null then 1 else 0 end) iol,
avg(case when o.cd_pedido is not null then datediff(day,t.fc_emision, t.fc_cumplimiento) else null end) tmi_iol,
sum(1) tot,
t.cd_estado_tramite
	from adsl t 
		left join #inf_adsl i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
		left join #iol o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido
where t.fc_cumplimiento >= '01/06/2009' and cd_estado_tramite not in ('zz','xx','ac')		
group by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 
order by year(fc_cumplimiento), month(t.fc_cumplimiento), cd_estado_tramite 


select 
*	from adsl t 
		left join #inf_adsl i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
		left join #iol o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido
where t.fc_cumplimiento >= '01/04/2010' and cd_estado_tramite not in ('zz','xx','ac')		
and i.cd_pedido_cliente is not null and o.cd_pedido is null 

select 
*	from tb t 
		left join #inf_tb i on t.cd_pedido_cliente = i.cd_pedido_cliente and t.cd_sub_pedido = i.cd_sub_pedido
		left join #iol o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido
		--left join #enmano e on t.cd_pedido_cliente = e.cd_pedido and t.cd_sub_pedido = e.cd_sub_pedido and t.cd_tramite = e.cd_tramite
where t.fc_cumplimiento >= '01/05/2010' and cd_estado_tramite not in ('zz','xx','ac')		
and i.cd_pedido_cliente is not null and o.cd_pedido is null  --and e.cd_pedido is  null
AND T.CD_PEDIDO_CLIENTE NOT IN (SELECT CD_PEDIDO_CLIENTE FROM ADSL WHERE TX_PROD_ADSL = 'CAM24')


select * from dt_tipo_cliente order by cd_tipo_cliente
select * from openquery(dw,'select * from tasa.party_tipo_cliente where cd_unidad_negocio = ''pym'' order by cd_tipo_cliente')



select * from [pegaso1\sql2000].posventa.dbo.pgc_pendientes where cd_sector = 'GPM' and cd_ani = 0 and tx_estado <> 'PEND.-DE-LIBRAR'






select DISTINCT motivo from analisis..MOTIVOS_tb where cd_implicancia = 'c' and motivo not in (select motivo from motivos_red) ORDER BY MOTIVO

select DISTINCT tx_motivo from analisis..MOTIVOS_adsl where cd_implicancia = 'c' and tx_motivo not in (select motivo from motivos_red) ORDER BY TX_MOTIVO