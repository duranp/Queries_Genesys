------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[bv_temporal]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[bv_temporal]
GO

--TRAIGO OBS DE PEGASO
declare @sql varchar(500)
set @sql ='select * into bv_temporal from  openquery(tic, ''select * from posventa..pgc_pedidos where fc_cumplimiento is null or fc_cumplimiento >= ''''' + convert(varchar(10), dateadd(month, -2, getdate()), 103) + ''''''')'
exec(@sql)

--PRIMER CRUZADA select * from #posventa drop table #temp 
select DISTINCT
a.tx_prod_adsl tx_producto, a.cd_cuenta, a.cd_party cd_party_titular, u.cd_login, u.fc_alta,x.tx_obs_bo, x.tx_promocion, 
a.cd_pedido_cliente, a.cd_sub_pedido, a.tx_canal_venta + '|'+ isnull(a.tx_agente_externo,'') tx_canal_venta, a.fc_emision, a.fc_cumplimiento,
datediff(day,a.fc_emision, a.fc_cumplimiento) ti, a.tx_tipo_cliente, replace(a.ani,' ','') ani, 
case when a.tx_razon_social is null then a.tx_nombre + ' ' + a.tx_apellido else a.tx_razon_social end tx_razon_social
into #temp
from adsl a left join bv_temporal x
on a.cd_pedido_cliente = x.cd_pedido and a.cd_sub_pedido = x.cd_sub_pedido and a.[cd_tramite] = x.cd_tramite
left join (select * from bv_usuarios_conex where cd_login not like '%#%' and cd_estado_instancia <>'BA') u on replace(a.ani,' ','') = replace(u.[cd_interurbano]+u.[cd_urbano]+u.[cd_linea],' ','')
where a.fc_cumplimiento >= convert(varchar(10), dateadd(month, -2, getdate()), 103)  and a.cd_estado_tramite in ('fa','cu')
--and a.cd_motivo_ingreso is null

--CRUZO CON FACTURADOR --DROP TABLE #BV_BIENVENIDA
select distinct
t.tx_producto,
'default' facturador, 
t.cd_party_titular, 
t.tx_razon_social, 
t.ani, 
cd_login, 
tx_obs_bo, 
tx_promocion, 
cd_pedido_cliente, 
cd_sub_pedido, 
tx_canal_venta, 
tx_tipo_cliente, 
fc_emision, 
fc_cumplimiento,
ti dias_instalacion,
a.tx_tipo_servicio  
into #bv_bienvenida
from  #temp t
left join bv_antivirus a on t.cd_party_titular = a.cd_party_titular and t.fc_alta = a.fc_alta--and t.cd_cuenta = a.cd_cuenta_titular
left join bv_facturador f on t.cd_party_titular = f.cd_party
order by tx_tipo_servicio

--MULTI PETONDA
update #bv_bienvenida 
set TX_PRODUCTO = case when t.cd_pedido_cliente is not null and t.cd_producto <> '0210000000027' and tx_producto = 'cam24' then 'TB-'  + TX_PRODUCTO
		       when t.cd_pedido_cliente is not null and t.cd_producto =  '0210000000027' and tx_producto = 'cam24' then 'TBE-' + TX_PRODUCTO
		       when t.cd_pedido_cliente is not null and t.cd_producto =  '0210000000027' and tx_producto<> 'cam24' then 'TB-'  + TX_PRODUCTO
		       when t.cd_pedido_cliente is not null and t.cd_producto <> '0210000000027' and tx_producto<> 'cam24' then 'TB-'  + TX_PRODUCTO
		       else tx_producto end
	from #bv_bienvenida b 
	inner join tb t 
		on b.cd_pedido_cliente = t.cd_pedido_cliente and 
		   b.cd_sub_pedido = t.cd_sub_pedido and t.cd_producto not in ('02100000000P7', '02100000000P4','02100000000U4','02100000000U5')
where tx_producto <> 'migracion'

--SACO LOS VOIP (PARA PROCESAR LUEGO)
delete 
from #bv_bienvenida where cd_pedido_cliente in (select cd_pedido_cliente from tb t
						where t.cd_producto in ('02100000000P7', '02100000000P4','02100000000U4','02100000000U5') AND 
						T.CD_ESTADO_TRAMITE = 'FA')


--PDTI
update #bv_bienvenida 
SET TX_PRODUCTO = case when tx_producto = 'migracion' then 'PC-MIGRACION' ELSE 'PC-LAN-OFFICE' END 
from #bv_bienvenida A
INNER join PC 
	on  a.cd_pedido_cliente = pc.cd_pedido_cliente
		and a.cd_sub_pedido = pc.cd_sub_pedido


--INSERTO NOVEDADES
insert into bv_bienvenida 
select distinct b.*, 
CASE 	WHEN TX_PRODUCTO LIKE '%CAM24%' 	THEN CAST(c.cant as varchar(3))
	WHEN TX_PRODUCTO = 'PC-LAN-OFFICE'	THEN 'pc basica: ' + cast(isnull(pc.cant,0) as varchar(5)) + ' pc premium: ' + cast(isnull(pcp.cant,0) as varchar(5)) + ' Notebook: ' + cast(isnull(nt.cant,0) as varchar(5)) + ' Pc Clon: ' + cast(isnull(cl.cant,0) as varchar(5)) 
ELSE NULL END
cant_camaras 
from #bv_bienvenida b
	left join bv_bienvenida b2 
		on b.cd_pedido_cliente = b2.cd_pedido_cliente and 
		b.cd_sub_pedido = b2.cd_sub_pedido 
	left join (SELECT COUNT(*) cant, CD_PEDIDO_CLIENTE, CD_SUB_PEDIDO FROM CAMARAS GROUP BY CD_PEDIDO_CLIENTE, CD_SUB_PEDIDO)c
		on c.cd_pedido_cliente = b.cd_pedido_cliente and c.cd_sub_pedido = b.cd_sub_pedido
		
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044450')
		group by cd_pedido_cliente, cd_sub_pedido)pc
			on  B.cd_pedido_cliente = pc.cd_pedido_cliente
			and B.cd_sub_pedido = pc.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044451')
		group by cd_pedido_cliente, cd_sub_pedido)pcp
			on  B.cd_pedido_cliente = pcp.cd_pedido_cliente 
			and B.cd_sub_pedido = pcp.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044454')
		group by cd_pedido_cliente, cd_sub_pedido)nt
			on  B.cd_pedido_cliente = nt.cd_pedido_cliente 
			and B.cd_sub_pedido = nt.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044436')
		group by cd_pedido_cliente, cd_sub_pedido)cl
			on  B.cd_pedido_cliente = cl.cd_pedido_cliente 
			and B.cd_sub_pedido = cl.cd_sub_pedido
where b2.cd_pedido_cliente is null
AND B.TX_PRODUCTO <> 'MIGRACION'
/*and b.fc_cumplimiento < case when datepart(weekday,getdate()) = 1 then dateadd(day,-4, getdate()) 
else dateadd(day,-3, getdate()) 
end*/

--pc solas
select distinct
'PC' tx_producto,
null facturador, pc.cd_party_TITULAR cd_party_titular, case when pc.tx_razon_social is null then pc.tx_nombre + ' ' + pc.tx_apellido else pc.tx_razon_social end tx_razon_social,
pc.CD_ani ANI, null cd_login, x.tx_obs_bo, x.tx_promocion, pc.cd_pedido_cliente, pc.cd_sub_pedido, 
pc.tx_canal +'|'+ isnull(PC.tx_agente_externo, '') TX_CANAL_venta, Tc.tx_tipo_cliente, pc.fc_emision, pc.fc_cumplimiento, datediff(day, pc.fc_emision, PC.fc_cumplimiento) ti, null tx_tipo_servicio,
'pc basica: ' + cast(isnull(pc1.cant,0) as varchar(5)) + ' pc premium: ' + cast(isnull(pcp.cant,0) as varchar(5)) + ' Notebook: ' + cast(isnull(nt.cant,0) as varchar(5)) + ' Pc Clon: ' + cast(isnull(cl.cant,0) as varchar(5)) cant_camaras 
into #pc
from adsl A
right join PC 
	on  a.cd_pedido_cliente = pc.cd_pedido_cliente
		and a.cd_sub_pedido = pc.cd_sub_pedido 
left join bv_temporal x
	on pc.cd_pedido_cliente = x.cd_pedido and 
		pc.cd_sub_pedido = x.cd_sub_pedido and 
		pc.[cd_tramite] = x.cd_tramite
	left join (SELECT COUNT(*) cant, CD_PEDIDO_CLIENTE, CD_SUB_PEDIDO FROM CAMARAS GROUP BY CD_PEDIDO_CLIENTE, CD_SUB_PEDIDO)c
		on c.cd_pedido_cliente = pc.cd_pedido_cliente and c.cd_sub_pedido = pc.cd_sub_pedido	
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044450')
		group by cd_pedido_cliente, cd_sub_pedido)pc1
			on  pc.cd_pedido_cliente = pc1.cd_pedido_cliente
			and pc.cd_sub_pedido = pc1.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044451')
		group by cd_pedido_cliente, cd_sub_pedido)pcp
			on  pc.cd_pedido_cliente = pcp.cd_pedido_cliente 
			and pc.cd_sub_pedido = pcp.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044454')
		group by cd_pedido_cliente, cd_sub_pedido)nt
			on  pc.cd_pedido_cliente = nt.cd_pedido_cliente 
			and pc.cd_sub_pedido = nt.cd_sub_pedido
	left join 
		(select cd_pedido_cliente, cd_sub_pedido, count(*) cant 
		from pc where  pc.cd_estado_tramite in ('fa', 'cu') and cd_producto_es in ('0220000044436')
		group by cd_pedido_cliente, cd_sub_pedido)cl
			on  pc.cd_pedido_cliente = cl.cd_pedido_cliente 
			and pc.cd_sub_pedido = cl.cd_sub_pedido
INNER JOIN DT_TIPO_CLIENTE TC ON PC.CD_TIPO_CLIENTE = TC.CD_TIPO_CLIENTE
where a.cd_pedido_cliente is null and pc.cd_estado_tramite in ('fa', 'cu')

insert into bv_bienvenida
select p.* from #pc p left join bv_bienvenida b2 
		on p.cd_pedido_cliente = b2.cd_pedido_cliente and 
		   p.cd_sub_pedido = b2.cd_sub_pedido
where b2.cd_pedido_cliente is null and p.fc_cumplimiento >= '20081001' /*and p.fc_cumplimiento < 
case when datepart(weekday,getdate()) = 1 then dateadd(day,-4, getdate()) 
else dateadd(day,-3, getdate()) 
end
*/
-------VOIP

------PARQUizado LOCO!!
select cast(cd_pedido_cliente as bigint) cd_pedido_cliente, ani, CAST(null AS VARCHAR(8000)) grp_parque
into #v
from tb t
where t.cd_producto in ('02100000000P7', '02100000000P4') AND T.CD_ESTADO_TRAMITE = 'FA'
AND T.FC_CUMPLIMIENTO > = '21/10/2008'
ORDER BY CD_PEDIDO_CLIENTE, ANI

DECLARE grp CURSOR FOR

SELECT cd_pedido_cliente, ani
FROM #v order by CD_PEDIDO_CLIENTE, ANI

declare @ped_a bigint
declare @grp varchar(8000)
declare @ped bigint
declare @ani bigint
set @ped_a = 0
OPEN grp
    	FETCH NEXT FROM grp into @ped, @ani
	WHILE @@FETCH_STATUS = 0
	BEGIN
		if @ped = @ped_a
			begin
				set @grp = @grp + ',' + cast(@ani as varchar(10))
				update #v set grp_parque = @grp where cd_pedido_cliente = @ped
			end
		else
			begin
				update #v set grp_parque = @grp where cd_pedido_cliente = @ped_a
				set @grp = @ani
			end
		set @ped_a = @ped		
	    	FETCH NEXT FROM grp into @ped, @ani
	END
CLOSE grp
DEALLOCATE grp	

--voip con alta de adsl separada en -15 a 0 dias antes ----- DROP TABLE #BV_VOIP
select distinct t.cd_pedido_cliente 
into #voip
from tb t 
inner join iad i on t.cd_pedido_cliente = i.cd_pedido_cliente
inner join adsl a on a.ani = i.ani and a.fc_cumplimiento between dateadd(day,-15, t.fc_emision) and t.fc_emision
where t.cd_producto in ('02100000000P7', '02100000000P4')

select distinct
case 	when a.cd_pedido_cliente is null and v.cd_pedido_cliente is null then 'VOIP' 
	when v.cd_pedido_cliente is not null then 'VOIP-LAN-SEPARADO'
	else 'VOIP-LAN OFFICE' END tipo_producto,
'default' facturador, 
t.cd_party cd_party_titular, 
isnull(t.tx_razon_social, t.tx_nombre + ' ' + t.tx_apellido) tx_razon_social, 
ISNULL(V2.GRP_PARQUE, V2.ANI) ANI, 
NULL cd_login, 
o.tx_obs_bo, 
t.tx_promocion, 
t.cd_pedido_cliente, 
111 cd_sub_pedido, 
t.tx_canal_venta + '|'+ isnull(t.tx_agente_externo,'') tx_canal_venta, 
t.tx_tipo_cliente, 
t.fc_emision, 
t.fc_cumplimiento,
datediff(day, t.fc_emision, t.fc_cumplimiento) dias,
NULL tx_tipo_servicio,
(SELECT COUNT(*) FROM TB WHERE CD_PEDIDO_CLIENTE = T.CD_PEDIDO_CLIENTE AND CD_ESTADO_TRAMITE = 'FA') cant_camaras
into #bv_voip
from  tb t 
left join bv_temporal o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido 
left join adsl a on t.cd_pedido_cliente = a.cd_pedido_cliente and a.cd_motivo_ingreso is null
left join #voip v on t.cd_pedido_cliente = v.cd_pedido_cliente
LEFT JOIN #V V2 ON T.CD_PEDIDO_CLIENTE = V2.CD_PEDIDO_CLIENTE
where t.cd_producto in ('02100000000P7', '02100000000P4') AND T.CD_ESTADO_TRAMITE = 'FA'
AND T.FC_CUMPLIMIENTO > = '21/10/2008'


--CENTRAL VOIP DROP TABLE #C
declare @dias tinyint
set @dias = 20

--PARQUIZO CENTRAL 
select cast(CD_PARTY AS bigint) CD_PARTY, ani, CAST(null AS VARCHAR(8000)) grp_parque
into #C
from tb t
where t.cd_producto in ('02100000000U4', '02100000000U5') AND T.CD_ESTADO_TRAMITE = 'FA'
AND CD_PARTY IN (SELECT CD_PARTY FROM c_voip where cd_estado_tramite in ('fa','cu') and fc_cumplimiento < dateadd(day,-1*@DIAS, getdate()))
AND EXISTS(SELECT * FROM C_VOIP WHERE CD_PARTY = T.CD_PARTY AND FC_CUMPLIMIENTO BETWEEN DATEADD(DAY,-1*@DIAS, T.FC_CUMPLIMIENTO) AND T.FC_CUMPLIMIENTO AND CD_ESTADO_TRAMITE IN ('FA','CU'))


DECLARE grp CURSOR FOR

SELECT CD_PARTY, ani
FROM #C order by CD_PARTY, ANI

declare @grp varchar(8000)
DECLARE @ANI BIGINT
declare @CD_PARTY bigint
DECLARE @CD_PARTY_A BIGINT
set @CD_PARTY_A = 0
OPEN grp
    	FETCH NEXT FROM grp into @CD_PARTY, @ani
	WHILE @@FETCH_STATUS = 0
	BEGIN
		if @CD_PARTY = @CD_PARTY_A
			begin
				set @grp = @grp + ',' + cast(@ani as varchar(10))
				update #C set grp_parque = @grp where CD_PARTY = @CD_PARTY
			end
		else
			begin
				update #C set grp_parque = @grp where CD_PARTY = @CD_PARTY_A
				set @grp = @ani
			end
		set @CD_PARTY_A = @CD_PARTY
	    	FETCH NEXT FROM grp into @CD_PARTY, @ANI
	END
CLOSE grp
DEALLOCATE grp	

--cruzo central con parque
declare @dias tinyint
set @dias = 20
SELECT 
DISTINCT
'CENTRAL_VOIP' TIPO_producto,
'default' facturador,
t.cd_party cd_party_titular,
isnull(t.tx_razon_social, t.tx_nombre + ' ' + t.tx_apellido) tx_razon_social, 
ISNULL(P.GRP_PARQUE, t.cd_ani) ani,
null cd_login,
o.tx_obs_bo, 
NULL tx_promocion, 
t.cd_pedido_cliente, 
t.cd_sub_pedido, 
t.tx_canal + '|'+ isnull(t.tx_agente_externo,'') tx_canal_venta, 
tc.tx_tipo_cliente, 
t.fc_emision, 
t.fc_cumplimiento,
datediff(day, t.fc_emision, t.fc_cumplimiento) dias,
NULL tx_tipo_servicio,
--(select count(*) from tb where cd_party = t.cd_party and fc_CUMPLIMIENTO BETWEEN t.fc_cumplimiento and getdate() and cd_producto in ('02100000000U4', '02100000000U5') and CD_ESTADO_TRAMITE in ('FA','CU'))cant_camaras
0 cant_camaras
into #c_voip
from  c_voip t inner join dt_tipo_cliente tc on t.cd_tipo_cliente = tc.cd_tipo_cliente
	left join bv_temporal o on t.cd_pedido_cliente = o.cd_pedido and t.cd_sub_pedido = o.cd_sub_pedido 
	LEFT JOIN (SELECT DISTINCT CD_PARTY, GRP_PARQUE FROM #C) P ON T.CD_PARTY = P.CD_PARTY 
where cd_estado_tramite in ('fa','cu')
and t.fc_cumplimiento < dateadd(day,-1*@dias, getdate())

--masive inserts!
insert into bv_bienvenida
select v.* 
from #c_voip v 
	left join bv_bienvenida b2 
		on v.cd_pedido_cliente = b2.cd_pedido_cliente and 
		   v.cd_sub_pedido = b2.cd_sub_pedido
where b2.cd_pedido_cliente is null 

insert into bv_bienvenida
select v.* from #bv_voip v left join bv_bienvenida b2 
		on v.cd_pedido_cliente = b2.cd_pedido_cliente and 
		   v.cd_sub_pedido = b2.cd_sub_pedido
where b2.cd_pedido_cliente is null and not exists (select * from bv_bienvenida where cd_party_titular = v.cd_party_titular and tipo_producto = 'central_voip' and fc_cumpliento between dateadd(day,-1*@dias, t.fc_cumplimiento) and t.fc_cumplimiento)
--saco los LAN OFFICE que tiene registro VOIP-LAN OFFICE
delete from bv_bienvenida where cd_pedido_cliente in (select cd_pedido_cliente from #bv_voip where tipo_producto = 'voip-lan office') and tipo_producto = 'lan office'

update bv_bienvenida
set tipo_producto = tipo_producto +'_SN'
from bv_bienvenida b inner join bv_sin_navegacion sn on b.cd_pedido_cliente = sn.cd_pedido_cliente 
where tipo_producto not like '%_sn'

delete from bv_bienvenida where tipo_producto = 'LAN OFFICE_SN'

drop table bv_temporal
drop table #bv_bienvenida
drop table #bv_voip
drop table #v
drop table #c
drop table #c_voip
drop table #temp
drop table #pc












