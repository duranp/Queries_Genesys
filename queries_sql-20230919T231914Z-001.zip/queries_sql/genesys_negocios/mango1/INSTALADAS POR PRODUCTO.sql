select month(fc_cumplimiento), sum(1) cant 
from adsl 
where tx_prod_adsl = 'lan office' and cd_motivo_ingreso is null
and cd_estado_tramite = 'cu' and year(fc_cumplimiento) = 2009
group by month(fc_cumplimiento) 
order by month(fc_cumplimiento) 

select month(fc_cumplimiento), sum(1) cant 
from adsl 
where tx_prod_adsl = 'cam24' and cd_motivo_ingreso is null
and cd_estado_tramite = 'cu' and year(fc_cumplimiento) = 2009
group by month(fc_cumplimiento) 
order by month(fc_cumplimiento) 

select month(fc_cumplimiento), sum(1) cant 
from tb
where cd_producto in('02100000000P7','02100000000P4') --and cd_motivo_ingreso is null
and cd_estado_tramite = 'fa' and year(fc_cumplimiento) = 2009
group by month(fc_cumplimiento) 
order by month(fc_cumplimiento) 

select month(fc_cumplimiento), sum(1) cant 
from pc
where cd_estado_tramite = 'cu' and year(fc_cumplimiento) = 2009
group by month(fc_cumplimiento) 
order by month(fc_cumplimiento) 




