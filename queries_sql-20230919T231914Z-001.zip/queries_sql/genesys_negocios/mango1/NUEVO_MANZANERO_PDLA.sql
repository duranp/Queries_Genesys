--DROP TABLE #T
select manz_nro cd_manzana, manz_cent_id cd_central, velocidad
into #t
from prefa_ani_adsl p
	left join v_velocidades2 v on p.praa_long_pdla between v.minima and v.maxima

/*select * from #t where cd_manzana = 4231 and cd_central = 628
select * from prefa_ani_adsl where manz_nro = 4231 and manz_cent_id = 628*/

--drop table #t2
select distinct cd_manzana, cd_central, 
(select max(velocidad) from (select top 80 percent with ties velocidad from #t where cd_central = t.cd_central and cd_manzana = t.cd_manzana order by velocidad)x) ochenta
into #t2
from #t t

select *, (select max(velocidad) from v_velocidades2 where velocidad < t.ochenta) final from #t2 t


select * from pc where cd_estado_tramite = 'cu' and fc _Cumplimiento between '01/07/2010' and '31/07/2010'
.

dbo.sp_get_tmi 2, '01/08/2010', 'tb'

alter procedure sp_get_central (@q as varchar(100)=null)
as
select distinct cd_central, tx_central from dt_central where tx_central like '%'+ isnull(@q,cd_central) +'%'
go

sp_get_central 'alb'

select * from v_cupo_adsl

select distinct cd_central, tx_localidad into #cl from v_manzanero

select count(*), cd_central from #cl group by cd_central

select * from #cl where cd_central = 276

select * from v_tmi_central where [80] > 50

select * from dt_central where cd_central = 219

select * from v_parque_tb_sp where cd_central = 219
select * into dt_central_provincia from [10.244.65.234].posventa.dbo.dt_central_provincia

select c.cd_central, t.tx_central, p.tx_provincia, c.tx_localidad into dt_central_lp from dt_central_provincia p inner join (select distinct cd_central, tx_localidad from v_manzanero)c on p.cd_central = c.cd_central left join dt_central t on c.cd_central = t.cd_central



drop table dt_central_lp

alter procedure sp_get_cent_lp (@tx_provincia varchar(100)=null, @tx_central varchar(100)=null, @tx_localidad varchar(100)=null)
as
	select * from dt_central_lp 
	where tx_provincia like '%'+ isnull(@tx_provincia,tx_provincia)+ '%'
	and tx_localidad like '%'+ isnull(@tx_localidad,tx_localidad)+ '%'
	and tx_central like '%'+ isnull(@tx_central,tx_central)+ '%'
go

sp_get_cent_lp @tx_provincia = 'bue', @tx_localidad = 'lomas', @tx_central = 'tres'


sp_helptext sp_get_central

select distinct cd_central, tx_central from dt_central where tx_central like '%'+ isnull(@q,cd_central) +'%'  


