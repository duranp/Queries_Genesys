use vtv
drop table borrar_parque
select * into borrar_parque from [10.244.65.234].posventa.dbo.parque_basica

select sum(1), suM(case when cctsubmotivoid =4146 then 1 else 0 end) reclamo, suM(case when cctsubmotivoid =4147 then 1 else 0 end) consulta
from casos c 
	inner join borrar_parque p on c.ccttelefonoreclamo = rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea 
	inner join borrar_ciclo2 c2 on p.cd_party_titular -20000000000 = c2.party and p.cd_cuenta - 200000000 = c2.[cd cuenta]
where cctmotivoid = 93.00000 
and swdatecreated between '27/12/2010' and '18/01/2011'


 