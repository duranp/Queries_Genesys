drop table analisis..mails
select * into analisis..mails from openquery(dw,
'SELECT      
al4.cd_unidad_negocio,al2.cd_login||''@''||al2.cd_dominio tx_mail
FROM   TASA.PRODUCTO_INSTANCIA AL1, TASA.PRODUCTO_INSTANCIA AL2, TASA.PARTY_NOMBRE AL3, TASA.party_tipo_cliente AL4
WHERE (AL1.cd_producto_instancia=AL2.cd_producto_instancia_prd
        AND      AL3.cd_party=AL1.cd_party_titular
        AND      AL4.cd_tipo_cliente=AL3.cd_tipo_cliente)
        AND      (AL2.cd_producto_instancia LIKE ''36SV%''
        AND      AL1.cd_producto_instancia LIKE ''36pl%''
        AND      AL2.cd_producto=''36SV000000003'')
	AND AL2.CD_ESTADO_INSTANCIA<>''BA''')