--select * from pgc_estados where tx_bandeja = 'pv gestion fr' and timestamp >= '24/06/2009' and tx_estado_pgc like 'anular%'
select e.tx_bandeja, s.TX_G_MOTIVO_REAL, s.TX_G_RESULTADO, s.TX_ESTADO_PGC, s.TX_bandeja, COUNT(*) 
from vw_pgc_estados e 
	inner join vw_pgc_estados s 
		on  e.cd_pedido		= s.cd_pedido and 
			e.cd_sub_pedido = s.cd_sub_pedido and
			e.cd_tramite	= s.cd_tramite
and e.cd_orden  = s.cd_orden - 1
where e.tx_bandeja like 'pv%' and e.tx_bandeja <> 'PV INST GFC' and s.timestamp >= '24/06/2009' --and tx_estado_pgc like 'anular%'
GROUP BY e.tx_bandeja, s.TX_G_MOTIVO_REAL, s.TX_G_RESULTADO, s.TX_ESTADO_PGC, s.TX_bandeja


--
select 
sum(case when s.tx_g_resultado = 'fwt' then 1 else 0 end) fwt, 
sum(case when s.tx_g_resultado = 'voip' then 1 else 0 end) voip, 
sum(case when s.tx_g_resultado = 'ADSL mas VOIP' then 1 else 0 end) adsl_mas_voip, 
sum(case when s.tx_g_motivo_real like 'no se pudo%' then 1 else 0 end) FDC,
sum(case when s.tx_g_motivo_real like 'desiste%' or s.tx_g_motivo_real like 'nunca%' then 1 else 0 end) desiste,
sum(case when s.tx_g_motivo_real like 'duplic%' then 1 else 0 end) duplic,
sum(case when s.tx_g_motivo_real = 'CTE ESPERA INST' then 1 else 0 end) ocra,
COUNT(*) 
from vw_pgc_estados e 
	inner join vw_pgc_estados s 
		on  e.cd_pedido		= s.cd_pedido and 
			e.cd_sub_pedido = s.cd_sub_pedido and
			e.cd_tramite	= s.cd_tramite
and e.cd_orden  = s.cd_orden - 1
where e.tx_bandeja =  'PV Informados FR' and s.timestamp >= '24/06/2009' --and tx_estado_pgc like 'anular%'

select distinct s.tx_g_resultado
from vw_pgc_estados e 
	inner join vw_pgc_estados s 
		on  e.cd_pedido		= s.cd_pedido and 
			e.cd_sub_pedido = s.cd_sub_pedido and
			e.cd_tramite	= s.cd_tramite
and e.cd_orden  = s.cd_orden - 1
where e.tx_bandeja =  'PV Informados FR' and s.timestamp >= '24/06/2009' --and tx_estado_pgc like 'anular%'

select * from pgc_acciones where tx_parent = 'ACEPTA PROPUESTA'


select avg(datediff(day, p.fc_emision, e.timestamp))
from vw_pgc_estados e 
	inner join vw_pgc_estados s 
		on  e.cd_pedido		= s.cd_pedido and 
			e.cd_sub_pedido = s.cd_sub_pedido and
			e.cd_tramite	= s.cd_tramite
	inner join pgc_pedidos p
		on  e.cd_pedido		= p.cd_pedido and 
			e.cd_sub_pedido = p.cd_sub_pedido and
			e.cd_tramite	= p.cd_tramite	
and e.cd_orden  = s.cd_orden - 1
where e.tx_bandeja =  'PV Informados FR' and e.tx_bandeja <> 'PV INST GFC' and s.timestamp >= '24/06/2009' --and tx_estado_pgc like 'anular%'



select * from analisis..le_vieja




drop table borrar_ocra
select distinct cd_pedido 
into borrar_ocra
from vw_pgc_estados where tx_g_motivo_real = 'CTE ESPERA INST' and timestamp >= '24/06/2009' --and cd_tipo_tramite = 1

select  from vw_pgc_estados 

select * from vitacora where app = 'ind_FWT'


--pedidos que pasaron por pv drop table borrar_pv
DROP TABLE BORRAR_PV
select distinct p.* 
into borrar_pv
from pgc_pedidos p
	inner join pgc_estados_pedidos pe
				on  pe.cd_pedido		= p.cd_pedido and 
					pe.cd_sub_pedido = p.cd_sub_pedido and
					pe.cd_tramite	= p.cd_tramite and
					pe.tx_bandeja = 'PV Informados FR'
					--AND P.CD_PRODUCTO_PGC IN ('TB','TB MULTI')


SELECT *, MONTH(FC_CUMPLIMIENTO) MES FROM BORRAR_PV




					
					
		