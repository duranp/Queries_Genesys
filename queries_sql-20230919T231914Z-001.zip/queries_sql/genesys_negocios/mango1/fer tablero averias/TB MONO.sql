	--TB MONO
--tmi, instalaciones en plazo
select 
month(t.fc_cumplimiento) mes,
avg(cast(datediff(day, t.fc_emision, t.fc_cumplimiento) as real)) tmi, count(*) inst,
sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) <=7 then 1 else 0 end) dentro,
sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) >7 then 1 else 0 end) fuera,
cast(sum(case when datediff(day, t.fc_emision, t.fc_cumplimiento) <=7 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from tb t left join adsl a on t.cd_pedido_cliente = a.cd_pedido_cliente
where 
t.cd_estado_tramite in('fa', 'cu')
and year(t.fc_cumplimiento) = year(getdate())
and a.cd_pedido_cliente is  null
group by month(t.fc_cumplimiento)
order by month(t.fc_cumplimiento)


--averias en garantia
select month(v.fc_cumplimiento) mes,
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END 'T_CLIENTE',
sum(case when a.cd_averia is not null then 1 else 0 end) 'no',
sum(case when a.cd_averia is null then 1 else 0 end) 'si',
cast(sum(case when a.cd_averia is NOT null then 1 else 0 end) as real)/ cast(count(*) as real)*100 '%_av_gtia',
count(distinct v.ani)
from tb v 
	left join cate..averias a on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
	left join adsl ad on v.cd_pedido_cliente = ad.cd_pedido_cliente
where 
v.CD_estado_tramite in('fa', 'cu') 
and ad.cd_pedido_cliente is null
and year(v.fc_cumplimiento) = year(getdate())
group by month(v.fc_cumplimiento),
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END
ORDER BY month(v.fc_cumplimiento),
case when v.tx_tipo_cliente like 'nyp%' or v.tx_tipo_cliente like 'nuevos%' then 'NO CART' ELSE 'CART' END						