--todos
select 
distinct cd_tipo_tramite,
cd_central, tx_estado, tx_g_motivo_real,cd_party, cd_producto_pgc, 
P.cd_pedido, P.CD_TRAMITE, P.cd_sub_PEDIDO, FC_EMISION, FC_CUMPLIMIENTO, 
c.tx_canal, f.tx_fdv, m.tx_motivo--,* 
from pgc_pedidos p 
	left join vw_pgc_estados e 
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
		and e.timestamp = (select max(timestamp) from vw_pgc_estados where
								cd_pedido = e.cd_pedido
								and cd_sub_pedido = e.cd_sub_pedido
								and cd_tramite = e.cd_tramite
								and cd_usuario not in ('cota','pgc_sys','ferre�o','lacherra') 
								and tx_g_motivo_real is not null
								and tx_g_estado_pgc = 'informado')								
left join pgc_canal c on '02'+p.cd_canal = c.cd_canal
left join pgc_fdv f on p.cd_fdv = f.cd_fdv
LEFT JOIN dt_motivo m on p.cd_motivo = m.cd_motivo
where p.cd_producto_pgc in ('voip','tb','tb mp', 'adsl','lan office', 'kit adsl', 'fwt', 'musica lan','pc', 'pg(pdti)','rural','SFT-MUSICA')
and (p.fc_cumplimiento>= dateadd(day,-35,convert(varchar(10), getdate(),112))
or p.fc_cumplimiento is null)

select dateadd(day,-35,convert(varchar(10), getdate(),112))