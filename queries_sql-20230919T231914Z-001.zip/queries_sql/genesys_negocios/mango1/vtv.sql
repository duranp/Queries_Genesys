--PRINT GETDATE()
delete from casos where FC_LLAMADA >= DBO.PD(DATEADD(MONTH,-1,GETDATE()))

insert INTO CASOS select * from openquery(dw,'Select	ce.fc_cambio||'' ''||ce.hr_cambio fh_cierre, ce.cd_estado_new, c.cd_caso, c.cd_contacto, CO.CD_PARTY, co.cd_interurbano, co.cd_urbano, co.cd_linea, c.fc_llamada, c.cd_motivo_contacto, c.cd_submotivo_contacto, c.cd_gestion_contacto, c.fc_final, c.cd_usuario, c.cd_estado_posible 
From	vwd_contactos.caso c Inner Join vwd_contactos.contacto co
	On	c.cd_contacto = co.cd_contacto
left join vwd_contactos.caso_estado_his ce on c.cd_caso = ce.cd_caso 
and ce.fc_cambio||'' ''||ce.hr_cambio= (select max(fc_cambio||'' ''||hr_cambio) from vwd_contactos.caso_estado_his where cd_caso = c.cd_caso)
Where	c.cd_caso like ''35%''
	And	c.fc_llamada >= ''01/''||TRIM(EXTRACT(MONTH FROM add_months(date, -1)))||''/''||TRIM(EXTRACT( YEAR FROM add_months(date, -1) ))
 and C.cd_usuario <> ''CANAL_ONLI''')

--PRINT GETDATE()
delete from instancias where FC_LLAMADA >= DBO.PD(DATEADD(MONTH,-1,GETDATE()))
insert into instancias select * from openquery(dw,'select * from vwd_contactos.instancia Where	cd_caso like ''35%'' AND cd_usuario <> ''CANAL_ONLI'' AND FC_LLAMADA >= ''01/''||TRIM(EXTRACT(MONTH FROM add_months(date, -1)))||''/''||TRIM(EXTRACT( YEAR FROM add_months(date, -1) ))')
--PRINT GETDATE()

delete from inbox where year(fh_entrada) = year(getdate())
insert into inbox select * from openquery(dw, 'Select	fc_recepcion || '' '' || hr_recepcion fh_entrada, fc_accion_tomada || '' '' || hr_accion_tomada fh_accion, c.*
From	vwd_contactos.caso_bandeja c where cd_caso like ''35%'' and tx_accion_tomada = ''gestionado'' and tx_bandeja_recibe in (select tx_inbox from tmp_usuarios.mango_rooster_bo) 
and year(fc_envio) = year(date)')

select * from openquery (dw,'select * from tmp_usuarios.mango_rooster_bo')

SELECT TOP 10 * FROM CASOS
select * from casos c where cd_motivo_contacto = '350000000078' and cd_submotivo_contacto = '350000006452' and fc_llamada in ('15/11/2010','16/11/2010')
and cd_usuario like 'dns%'
select * from motivo_contacto where tx_motivo_contacto = 'Campa�a'
select * from submotivo_contacto where tx_submotivo_contacto = 'Cierre Procesos Reclamos'
select * from visualizador..v_parque_tb_sp where ani = 1149821229

select * into borrar_me_dw from openquery(dw,'Select	p.*, t.fc_emision, t.fc_Cumplimiento, t.cd_estado_tramite, pc.cd_estado
From	 tmp_usuarios.mango p 	left Join tasa.sub_pedido s 
	On	p.p = s.cd_pedido_cliente -20000000000
	And	p.s = s.cd_sub_pedido
left join tasa.tramites t on 
	s.cd_pedido_cliente = t.cd_pedido_cliente 
	And	p.s = t.cd_sub_pedido
	And	p.t = t.cd_tramite
left join tasa.pedido_cliente pc on pc.cd_pedido_cliente = s.cd_pedido_cliente')
exec ('select * from tasa.party_tipo_cliente') at dw

select distinct p,s,t,fc_emision, fc_cumplimiento, cd_estado_tramite, cd_estado, linea, modulo, cliente_cota, tipo_cliente_descripcion, c.cd_caso, c.fc_llamada, i.fc_llamada+' '+i.hr_llamada fc_instancia  
from (SELECT DISTINCT * FROM BORRAR_ME_DW) B LEFT JOIN BORRAR_ME D ON D.PEDIDO = B.P AND D.SUB_PEDIDO = B.S AND D.TSPD_ID = B.T
LEFT JOIN CASOS c on d.linea = rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea and c.fc_llamada between b.fc_emision and dateadd(month,12,b.fc_emision) and d.cliente_cota = c.cd_party -20000000000
left join instancias i on c.cd_caso = i.cd_caso

select top 10 * from casos


select * from borrar_me
SELECT TOP 10 * FROM CASOS

select top 20 rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea, * from casos




alter view vw_casos 
as
select      casos.fh_cierre, isnull(casos.cd_estado_new, , casos.cd_caso, casos.cd_usuario, motivo_contacto.tx_motivo_contacto, submotivo_contacto.tx_submotivo_contacto, gestion_contacto.tx_gestion_contacto,  rtrim(cd_interurbano)+rtrim(cd_urbano)+cd_linea ani
FROM         casos INNER JOIN
                      motivo_contacto ON casos.cd_motivo_contacto = motivo_contacto.cd_motivo_contacto INNER JOIN
                      gestion_contacto ON casos.cd_motivo_contacto = gestion_contacto.cd_motivo_contacto AND 
                      casos.cd_submotivo_contacto = gestion_contacto.cd_submotivo_contacto AND casos.cd_gestion_contacto = gestion_contacto.cd_gestion_contacto INNER JOIN
                      submotivo_contacto ON casos.cd_motivo_contacto = submotivo_contacto.cd_motivo_contacto AND 
                      casos.cd_submotivo_contacto = submotivo_contacto.cd_submotivo_contacto

CREATE AGGREGATE [dbo].[Concatenate]
(@input [nvarchar](4000))
RETURNS[nvarchar](4000)
EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.Concatenate]


set nocount on
	insert
set nocount off
select @@identity


