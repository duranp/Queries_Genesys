drop table #d
drop table #rani

SELECT distinct ani, D.[GRUPO UNIFICADO], d.dictamen_gral, b1.TX_SEGMENTO, case when b1.tx_segmento = b2.tx_segmento then 1 else 0 end mismo
into #d
FROM d09 D 
	LEFT JOIN BO b1 ON D.[GRUPO UNIFICADO] = B1.TX_GRUPO 
	left join bo b2 on D.grupo_ingreso = B2.TX_GRUPO 
where b1.tx_segmento is not null 

drop table #d
select c.*, case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between dateadd(day,1,c.swdateresolved) and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID = 4147 and cctclasificacionid <> 5262 ) then 1 else 0 end r
, D.DICTAMEN_GRAL, d.tx_segmento, [grupo unificado], d.ani, d.mismo
into #rani 
from (select * from vtv_casos where cctmotivoid = 93 AND CCTSUBMOTIVOID = 4146 and swdateresolved between '01/09/2010' and '30/09/2010') c 	
	full JOIN #d D 
		ON D.ANI = C.CCTTELEFONORECLAMO 


--rehabilitados vtv 
drop table #rh
select *,
case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,2,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 83 AND CCTSUBMOTIVOID in(3822,3823)) then 1 else 0 end r
into #rh
from vtv_casos c
where cctmotivoid = 83 and cctsubmotivoid in(3822,3823) and year(swdatecreated) = 2010

select month(swdatecreated), sum(r)r, sum(1) t
from #rh
group by month(swdatecreated)
order by month(swdatecreated)

--DEUDA
drop table #RD
select *,
case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,7,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 83 AND CCTSUBMOTIVOID in(6310)) then 1 else 0 end r
into #rD
from vtv_casos c
where cctmotivoid = 83 and cctsubmotivoid in(6310) and year(swdatecreated) = 2010

select month(swdatecreated), sum(r)r, sum(1) t
from #rD
group by month(swdatecreated)
order by month(swdatecreated)

--instalacion -tecnico
drop table #rIT
select *,
case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,7,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 3 and cctsubmotivoid in( 4787,2888,4758,2890,2891,2892,2893,2895,2896,3887,3888)) then 1 else 0 end r
into #rIT
from vtv_casos c
where cctmotivoid = 3 and cctsubmotivoid in( 4787,2888,4758,2890,2891,2892,2893,2895,2896,3887,3888) and year(swdatecreated) = 2010

select month(swdatecreated), sum(r)r, sum(1) t
from #rIT
group by month(swdatecreated)
order by month(swdatecreated)

--instalacion -tecnico
drop table #rIC
select *,
case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,7,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 103 and cctsubmotivoid = 4392) then 1 else 0 end r
into #rIC
from vtv_casos c
where cctmotivoid = 103 and cctsubmotivoid = 4392 and year(swdatecreated) = 2010

select month(swdatecreated), sum(r)r, sum(1) t
from #rIC
group by month(swdatecreated)
order by month(swdatecreated)

--Convenio
drop table #rCo
select *,
case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,7,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 83 and cctsubmotivoid = 3819) then 1 else 0 end r
into #rCo
from vtv_casos c
where cctmotivoid = 83 and cctsubmotivoid = 3819 and year(swdatecreated) = 2010

select month(swdatecreated), sum(r)r, sum(1) t
from #rCo
group by month(swdatecreated)
order by month(swdatecreated)

--modulo error
select * from  submotivo where cctmotivoid = 93 and cctsubmotivoid in (4146,4147)
select * from me
select *, (select suM(1) from  from vtv_casos where  from me
drop table #l_me
select linea, min(fc_cumplimiento) fc into #l_me from me group by linea 


--cruzado vtv total
select m.linea, m.fc, sum(1) q from #l_me m inner join vtv_casos c on m.linea = c.ccttelefonoreclamo and c.swdatecreated > m.fc
group by m.linea, m.fc

--cruzado vtv motivo facturacion.
select sum(1) q from #l_me m inner join vtv_casos c on m.linea = c.ccttelefonoreclamo and c.swdatecreated > m.fc and cctmotivoid = 93 --and cctsubmotivoid in (4146,4147)
group by m.linea, m.fc
--sin reclamos


select count(distinct linea),sum(1) q from #l_me m 
	left join vtv_casos c on m.linea = c.ccttelefonoreclamo and c.swdatecreated > m.fc and cctmotivoid = 93 
where c.swcaseid is   null--and cctsubmotivoid in (4146,4147) 
and linea in (select ani from #rf)

SELECT * FROM #RF

select DISTINCT R.ANI, M.LINEA from #rf R LEFT JOIN ME M ON R.ANI = M.LINEA WHERE M.LINEA IS NOT NULL

select * from #l_me 

select * from motivo order by cctmotivoid
SELECT * FROM ME WHERE LINEA = 2320423408
select cast(cast(swcaseid as bigint) as varchar(10))+',',* from vtv_casos where ccttelefonoreclamo = '1149513253' and cctmotivoid = 93

select * from openquery(d,'select * from SWBAPPS.CCT_INSTANCIA where cctcaseid in(10974769,
8915406,
9172014,
9183123,
10123342,
10441194,
10441206,
10739614,
8763611,
8877215,
9040443,
9118113) order by cctfechacontacto')

select * from me where

select top 10 * from vtv_casos

select suM(1) from #l_me where fc is null
select * from me where linea = '2320423408'

drop table #l_me
select distinct linea,fc_cumplimiento  into #l_me from me

select * from #l_me l inner join 

select * from vtv_casos where swdatecreated > '16/02/2010' and ccttelefonoreclamo = '1146998831'
















select cctmotivoid, sum(1) SWBAPPS.SW_CASE
from vtv_casos
group by cctmotivoid
order by sum(1) desc

select * from motivo where cctmotivoid = 45

select * from openquery(d,'select C.SWCASEID,TC.* from SWBAPPS.SW_CASE C, SWBAPPS.SW_CUSTOMER TC   where C.SWCUSTOMERID = TC.SWCUSTOMERID AND rownum<100')

select sum(1),count(distinct swcaseid) from vtv_casos where swdatecreated between '01/09/2010' and '30/09/2010'
--and cctmotivoid in (select cctmotivoid from motivo where cctdescripcion in ('Aver�as','Bajas','Campa�a','Cobros','Facturaci�n','Gestion Comercial','Quejas','Telefonica on Line','Ventas'))
select * from motivo

select * from #d
select distinct cctdescsubmotivo from vtv_casos v left join submotivo s on v.cctsubmotivoid = s.cctsubmotivoid where v.cctmotivoid = 93

select * from submotivo where cctdescsubmotivo = 'consulta'

select sum(1) from #rani where ani is not null
select * from bo
drop table d09
select * from #d
select * from #rani
select * from d09 d where D.[GRUPO UNIFICADO] is null
SELECT CAST ('30/09/2010' AS DATETIME)
drop table #d
SWBAPPS.CCT_INSTANCIA


--consulta instancias
select r.swcaseid,r.swdatecreated,* from vtv_casos c
	inner join vtv_casos r on r.ccttelefonoreclamo = c.ccttelefonoreclamo and r.swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and r.swcaseid <> c.swcaseid and r.cctmotivoid = 93 AND r.CCTSUBMOTIVOID = 4147
where c.swcaseid = 10816253
select * from openquery(d,'select * from SWBAPPS.CCT_INSTANCIA where cctcaseid = 10816253.00000')
select * from openquery(d,'select * from SWBAPPS.CCT_INSTANCIA where cctcaseid = 10971725.00000')
select * from d09 where ani = '1146872424'

select * from clasificacion where cctsubmotivoid = 4147 order by cctdescripcion


(cctmotivoid = 3 and cctsubmotivoid = 4787,2888,4758,2890,2891,2892,2893,2895,2896,3887,3888) or
(cctmotivoid = 103 and cctsubmotivoid = 4392)

select * from motivo where cctactivo = 1
select * from submotivo where cctmotivoid = 103

select cast(cast(cctsubmotivoid as bigint) as varchar(10))+',',* from submotivo where cctmotivoid = 3 and cctactivo = 1 
and cctdescsubmotivo like 'inst%'
order by cctdescsubmotivo


1146375685
select * from #d


select * from d09
/*

DROP TABLE #RANI
select * from vtv_casos c where 
exists (select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) 
and swdateresolved between '01/07/2010' and '31/07/2010'
and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148
DROP TABLE #RANI

SELECT DISTINCT CCTDESCSUBMOTIVO FROM #RANI R INNER JOIN SUBMOTIVO S ON R.CCTSUBMOTIVOID = S.CCTSUBMOTIVOID

SELECT * FROM SUBMOTIVO WHERE CCTDESCSUBMOTIVO = 'Campa�a'


DROP TABLE #RANI
select c.*, case when exists (select ccttelefonoreclamo from vtv_casos where ccttelefonoreclamo = c.ccttelefonoreclamo and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) then 1 else 0 end r
, D.DICTAMEN
into #rani 
from vtv_casos c 	LEFT JOIN (SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO) D 
		ON D.ANI = C.CCTTELEFONORECLAMO 
where cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148
and swdateresolved between '01/09/2010' and '30/09/2010'

select month(swdateresolved), sum(r)r,  sum(1)t, DICTAMEN from #rani
group by month(swdateresolved), DICTAMEN
order by month(swdateresolved), DICTAMEN


SELECT *, CASE WHEN EXISTS(SELECT * FROM #RANI WHERE D.ANI = CCTTELEFONORECLAMO AND R=1 AND SWDATECREATED BETWEEN '01/09/2010' AND '30/09/2010') THEN 1 ELSE 0 END R FROM #D D


select top 100 * from vtv_casos


select * from openquery(d,'select * from SWBAPPS.SW_CASE where SWCASEID = 10396917.00000')
select * from openquery(d,'select * from SWBAPPS.SW_CUSTOMER where rownum <100')

select * from vtv_casos c where 
exists (select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93) 

and swdateresolved between '01/09/2010' and '30/09/2010'
and cctmotivoid = 93





SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO


DROP TABLE #RANI
select * from vtv_casos c 
	LEFT JOIN (SELECT distinct ani, dictamen_gral, TX_SEGMENTO FROM d09 D LEFT JOIN BO ON D.[GRUPO UNIFICADO] = BO.TX_GRUPO) D 
		ON D.ANI = C.CCTTELEFONORECLAMO 
where exists 
	(select swcustomerid from vtv_casos where swcustomerid = c.swcustomerid and swdatecreated between c.swdateresolved and dateadd(day,20,c.swdateresolved) and swcaseid <> c.swcaseid and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148) 
and swdateresolved between '01/07/2010' and '31/07/2010'
and cctmotivoid = 93 AND CCTSUBMOTIVOID <> 4148



SELECT TOP 10 * FROM vtv_casos

select distinct ani, dictamen_gral, [grupo unificado]  from d09 A where ani  in (select ani from d09 where [grupo unificado] <> a.[grupo unificado] and ani = a.ani)
ORDER BY ANI
*/

select sum(1) from vtv_casos where swdatecreated between '01/09/2010' and '30/09/2010' 

select * from submotivo where cctmotivoid =83


select distinct tasa_tipo_cliente from vtv_casos where year(swdatecreated) = 2010


--reclamos modulo de error
select sum(1) q  from #rf m inner join vtv_casos c on m.ani = c.ccttelefonoreclamo and cctmotivoid = 93 --and cctsubmotivoid in (4146,4147)
and year(swdatecreated) = 2010
group by m.ani

select * from #l_me where linea in (select ani from #rf)

create table #rf (ani bigint)
insert into #rf values(1137200036)
insert into #rf values(1137503691)
insert into #rf values(1137504584)
insert into #rf values(1137504627)
insert into #rf values(1137507700)
insert into #rf values(1137508551)
insert into #rf values(1142004933)
insert into #rf values(1142008188)
insert into #rf values(1142010961)
insert into #rf values(1142017385)
insert into #rf values(1142022584)
insert into #rf values(1142023361)
insert into #rf values(1142026947)
insert into #rf values(1142027155)
insert into #rf values(1142039118)
insert into #rf values(1142042796)
insert into #rf values(1142049951)
insert into #rf values(1142052050)
insert into #rf values(1142056552)
insert into #rf values(1142057105)
insert into #rf values(1142061210)
insert into #rf values(1142079465)
insert into #rf values(1142090153)
insert into #rf values(1142090878)
insert into #rf values(1142098877)
insert into #rf values(1142101923)
insert into #rf values(1142106543)
insert into #rf values(1142106795)
insert into #rf values(1142122444)
insert into #rf values(1142144225)
insert into #rf values(1142144226)
insert into #rf values(1142163560)
insert into #rf values(1142165378)
insert into #rf values(1142170059)
insert into #rf values(1142180118)
insert into #rf values(1142180864)
insert into #rf values(1142183008)
insert into #rf values(1142183587)
insert into #rf values(1142185555)
insert into #rf values(1142221503)
insert into #rf values(1142222324)
insert into #rf values(1142227644)
insert into #rf values(1142228105)
insert into #rf values(1142232989)
insert into #rf values(1142241022)
insert into #rf values(1142244815)
insert into #rf values(1142245968)
insert into #rf values(1142249948)
insert into #rf values(1142250999)
insert into #rf values(1142257967)
insert into #rf values(1142263288)
insert into #rf values(1142273165)
insert into #rf values(1142278807)
insert into #rf values(1142279800)
insert into #rf values(1142281126)
insert into #rf values(1142306277)
insert into #rf values(1142313609)
insert into #rf values(1142314440)
insert into #rf values(1142319004)
insert into #rf values(1142360557)
insert into #rf values(1142364709)
insert into #rf values(1142368726)
insert into #rf values(1142369978)
insert into #rf values(1142374285)
insert into #rf values(1142404241)
insert into #rf values(1142405224)
insert into #rf values(1142407389)
insert into #rf values(1142410915)
insert into #rf values(1142417766)
insert into #rf values(1142423650)
insert into #rf values(1142425292)
insert into #rf values(1142434798)
insert into #rf values(1142435107)
insert into #rf values(1142452592)
insert into #rf values(1142468653)
insert into #rf values(1142471457)
insert into #rf values(1142476516)
insert into #rf values(1142479575)
insert into #rf values(1142497005)
insert into #rf values(1142501026)
insert into #rf values(1142502377)
insert into #rf values(1142512133)
insert into #rf values(1142534561)
insert into #rf values(1142537559)
insert into #rf values(1142544315)
insert into #rf values(1142545004)
insert into #rf values(1142548030)
insert into #rf values(1142549090)
insert into #rf values(1142564564)
insert into #rf values(1142570162)
insert into #rf values(1142571129)
insert into #rf values(1142574637)
insert into #rf values(1142577751)
insert into #rf values(1142578585)
insert into #rf values(1142601136)
insert into #rf values(1142612750)
insert into #rf values(1142620586)
insert into #rf values(1142620964)
insert into #rf values(1142641259)
insert into #rf values(1142641815)
insert into #rf values(1142675389)
insert into #rf values(1142686492)
insert into #rf values(1142698940)
insert into #rf values(1142704345)
insert into #rf values(1142707058)
insert into #rf values(1142720441)
insert into #rf values(1142725296)
insert into #rf values(1142765283)
insert into #rf values(1142767217)
insert into #rf values(1142800670)
insert into #rf values(1142804118)
insert into #rf values(1142807138)
insert into #rf values(1142810861)
insert into #rf values(1142818544)
insert into #rf values(1142822507)
insert into #rf values(1142823025)
insert into #rf values(1142832899)
insert into #rf values(1142840351)
insert into #rf values(1142878180)
insert into #rf values(1142878184)
insert into #rf values(1142879610)
insert into #rf values(1142879801)
insert into #rf values(1142893837)
insert into #rf values(1142896050)
insert into #rf values(1142896356)
insert into #rf values(1142902903)
insert into #rf values(1142908835)
insert into #rf values(1142924765)
insert into #rf values(1142926243)
insert into #rf values(1142927755)
insert into #rf values(1142931339)
insert into #rf values(1142943480)
insert into #rf values(1142945396)
insert into #rf values(1142945402)
insert into #rf values(1142968984)
insert into #rf values(1142982186)
insert into #rf values(1142983010)
insert into #rf values(1142991768)
insert into #rf values(1143001417)
insert into #rf values(1143009757)
insert into #rf values(1143011753)
insert into #rf values(1143016037)
insert into #rf values(1143016077)
insert into #rf values(1143016840)
insert into #rf values(1143022503)
insert into #rf values(1143023520)
insert into #rf values(1143025706)
insert into #rf values(1143026976)
insert into #rf values(1143031585)
insert into #rf values(1143042948)
insert into #rf values(1143047311)
insert into #rf values(1143054048)
insert into #rf values(1143056262)
insert into #rf values(1143072359)
insert into #rf values(1143076227)
insert into #rf values(1143076387)
insert into #rf values(1143083855)
insert into #rf values(1143226210)
insert into #rf values(1143251043)
insert into #rf values(1143251782)
insert into #rf values(1143263102)
insert into #rf values(1143264662)
insert into #rf values(1143264721)
insert into #rf values(1143266134)
insert into #rf values(1143280836)
insert into #rf values(1143284034)
insert into #rf values(1143285750)
insert into #rf values(1143285890)
insert into #rf values(1143286235)
insert into #rf values(1143310629)
insert into #rf values(1143312419)
insert into #rf values(1143312734)
insert into #rf values(1143313964)
insert into #rf values(1143314970)
insert into #rf values(1143315034)
insert into #rf values(1143315217)
insert into #rf values(1143317636)
insert into #rf values(1143347891)
insert into #rf values(1143421866)
insert into #rf values(1143422644)
insert into #rf values(1143425857)
insert into #rf values(1143426636)
insert into #rf values(1143427067)
insert into #rf values(1143427892)
insert into #rf values(1143428011)
insert into #rf values(1143435743)
insert into #rf values(1143437343)
insert into #rf values(1143439992)
insert into #rf values(1143456837)
insert into #rf values(1143551334)
insert into #rf values(1143562390)
insert into #rf values(1143611087)
insert into #rf values(1143612030)
insert into #rf values(1143614315)
insert into #rf values(1143619627)
insert into #rf values(1143672553)
insert into #rf values(1143678729)
insert into #rf values(1143678951)
insert into #rf values(1143679890)
insert into #rf values(1143687409)
insert into #rf values(1143710798)
insert into #rf values(1143711307)
insert into #rf values(1143714547)
insert into #rf values(1143715764)
insert into #rf values(1143724298)
insert into #rf values(1143728000)
insert into #rf values(1143728374)
insert into #rf values(1143732441)
insert into #rf values(1143734555)
insert into #rf values(1143741747)
insert into #rf values(1143815206)
insert into #rf values(1143819633)
insert into #rf values(1143820058)
insert into #rf values(1143820449)
insert into #rf values(1143822057)
insert into #rf values(1143830117)
insert into #rf values(1143834922)
insert into #rf values(1143837452)
insert into #rf values(1143845186)
insert into #rf values(1143892583)
insert into #rf values(1143910837)
insert into #rf values(1143930069)
insert into #rf values(1143930913)
insert into #rf values(1143931118)
insert into #rf values(1143931304)
insert into #rf values(1143931944)
insert into #rf values(1143933925)
insert into #rf values(1144314328)
insert into #rf values(1144336255)
insert into #rf values(1144410920)
insert into #rf values(1144423005)
insert into #rf values(1144429122)
insert into #rf values(1144434740)
insert into #rf values(1144439212)
insert into #rf values(1144439449)
insert into #rf values(1144505442)
insert into #rf values(1144506103)
insert into #rf values(1144506835)
insert into #rf values(1144508250)
insert into #rf values(1144517130)
insert into #rf values(1144521040)
insert into #rf values(1144522195)
insert into #rf values(1144533062)
insert into #rf values(1144538622)
insert into #rf values(1144541229)
insert into #rf values(1144559977)
insert into #rf values(1144570168)
insert into #rf values(1144578537)
insert into #rf values(1144579602)
insert into #rf values(1144586010)
insert into #rf values(1144600448)
insert into #rf values(1144602385)
insert into #rf values(1144606091)
insert into #rf values(1144606343)
insert into #rf values(1144614440)
insert into #rf values(1144616391)
insert into #rf values(1144620415)
insert into #rf values(1144678001)
insert into #rf values(1144818503)
insert into #rf values(1144820230)
insert into #rf values(1144823292)
insert into #rf values(1144823486)
insert into #rf values(1144823637)
insert into #rf values(1144824130)
insert into #rf values(1144825983)
insert into #rf values(1144830158)
insert into #rf values(1144833258)
insert into #rf values(1144842491)
insert into #rf values(1144846974)
insert into #rf values(1144847259)
insert into #rf values(1144848768)
insert into #rf values(1144848960)
insert into #rf values(1144869370)
insert into #rf values(1144872903)
insert into #rf values(1144875212)
insert into #rf values(1144880757)
insert into #rf values(1144884106)
insert into #rf values(1144884771)
insert into #rf values(1144889304)
insert into #rf values(1144891945)
insert into #rf values(1144894169)
insert into #rf values(1145550482)
insert into #rf values(1145663954)
insert into #rf values(1145681510)
insert into #rf values(1146000156)
insert into #rf values(1146000638)
insert into #rf values(1146001174)
insert into #rf values(1146002383)
insert into #rf values(1146002570)
insert into #rf values(1146003120)
insert into #rf values(1146004098)
insert into #rf values(1146005403)
insert into #rf values(1146005705)
insert into #rf values(1146008141)
insert into #rf values(1146018698)
insert into #rf values(1146025775)
insert into #rf values(1146050754)
insert into #rf values(1146052027)
insert into #rf values(1146052512)
insert into #rf values(1146056996)
insert into #rf values(1146057077)
insert into #rf values(1146110500)
insert into #rf values(1146112087)
insert into #rf values(1146114713)
insert into #rf values(1146114867)
insert into #rf values(1146124708)
insert into #rf values(1146130198)
insert into #rf values(1146134878)
insert into #rf values(1146191384)
insert into #rf values(1146214112)
insert into #rf values(1146220448)
insert into #rf values(1146221562)
insert into #rf values(1146229547)
insert into #rf values(1146231653)
insert into #rf values(1146233782)
insert into #rf values(1146235730)
insert into #rf values(1146236224)
insert into #rf values(1146237957)
insert into #rf values(1146262515)
insert into #rf values(1146273049)
insert into #rf values(1146275344)
insert into #rf values(1146278720)
insert into #rf values(1146279258)
insert into #rf values(1146281818)
insert into #rf values(1146283979)
insert into #rf values(1146286865)
insert into #rf values(1146292987)
insert into #rf values(1146293258)
insert into #rf values(1146299085)
insert into #rf values(1146310817)
insert into #rf values(1146313990)
insert into #rf values(1146317246)
insert into #rf values(1146319186)
insert into #rf values(1146329006)
insert into #rf values(1146357391)
insert into #rf values(1146357468)
insert into #rf values(1146373227)
insert into #rf values(1146395383)
insert into #rf values(1146411662)
insert into #rf values(1146414367)
insert into #rf values(1146421360)
insert into #rf values(1146423691)
insert into #rf values(1146451848)
insert into #rf values(1146470289)
insert into #rf values(1146502891)
insert into #rf values(1146503739)
insert into #rf values(1146510324)
insert into #rf values(1146511637)
insert into #rf values(1146513592)
insert into #rf values(1146515136)
insert into #rf values(1146517007)
insert into #rf values(1146522156)
insert into #rf values(1146536043)
insert into #rf values(1146544569)
insert into #rf values(1146547472)
insert into #rf values(1146551023)
insert into #rf values(1146560071)
insert into #rf values(1146564301)
insert into #rf values(1146566302)
insert into #rf values(1146601486)
insert into #rf values(1146601928)
insert into #rf values(1146603499)
insert into #rf values(1146615223)
insert into #rf values(1146616235)
insert into #rf values(1146621926)
insert into #rf values(1146624539)
insert into #rf values(1146643176)
insert into #rf values(1146661621)
insert into #rf values(1146666450)
insert into #rf values(1146670126)
insert into #rf values(1146681202)
insert into #rf values(1146692237)
insert into #rf values(1146710105)
insert into #rf values(1146720348)
insert into #rf values(1146821035)
insert into #rf values(1146824282)
insert into #rf values(1146834011)
insert into #rf values(1146837986)
insert into #rf values(1146862232)
insert into #rf values(1146905699)
insert into #rf values(1146936997)
insert into #rf values(1146945536)
insert into #rf values(1146947464)
insert into #rf values(1146961353)
insert into #rf values(1146982226)
insert into #rf values(1146984118)
insert into #rf values(1146991326)
insert into #rf values(1146991498)
insert into #rf values(1146992806)
insert into #rf values(1146993149)
insert into #rf values(1146994269)
insert into #rf values(1147312722)
insert into #rf values(1148116097)
insert into #rf values(1148130095)
insert into #rf values(1148131531)
insert into #rf values(1148137082)
insert into #rf values(1148152645)
insert into #rf values(1148156747)
insert into #rf values(1148157088)
insert into #rf values(1148157842)
insert into #rf values(1148160070)
insert into #rf values(1148161747)
insert into #rf values(1148162224)
insert into #rf values(1148162361)
insert into #rf values(1148615581)
insert into #rf values(1148619200)
insert into #rf values(1148629547)
insert into #rf values(1148634055)
insert into #rf values(1148640513)
insert into #rf values(1148646775)
insert into #rf values(1148656036)
insert into #rf values(1148666400)
insert into #rf values(1148673077)
insert into #rf values(1149013167)
insert into #rf values(1149026449)
insert into #rf values(1149026623)
insert into #rf values(1149029387)
insert into #rf values(1149030000)
insert into #rf values(1149031753)
insert into #rf values(1149038039)
insert into #rf values(1149038084)
insert into #rf values(1149040437)
insert into #rf values(1149040803)
insert into #rf values(1149112052)
insert into #rf values(1149116305)
insert into #rf values(1149127220)
insert into #rf values(1149192834)
insert into #rf values(1149195337)
insert into #rf values(1149199449)
insert into #rf values(1149225909)
insert into #rf values(1149228553)
insert into #rf values(1149233578)
insert into #rf values(1149240085)
insert into #rf values(1149261067)
insert into #rf values(1149312955)
insert into #rf values(1149314196)
insert into #rf values(1149321113)
insert into #rf values(1149323537)
insert into #rf values(1149323550)
insert into #rf values(1149325223)
insert into #rf values(1149424339)
insert into #rf values(1149427948)
insert into #rf values(1149513253)
insert into #rf values(1149514943)
insert into #rf values(1149515121)
insert into #rf values(1149515411)
insert into #rf values(1149515522)
insert into #rf values(1149517639)
insert into #rf values(1149519433)
insert into #rf values(1149521547)
insert into #rf values(1149524029)
insert into #rf values(1149524768)
insert into #rf values(1149525337)
insert into #rf values(1149528161)
insert into #rf values(1149528228)
insert into #rf values(1149536365)
insert into #rf values(1149588555)
insert into #rf values(1149818738)
insert into #rf values(1149821389)
insert into #rf values(1149839600)
insert into #rf values(1150830289)
insert into #rf values(1157871668)
insert into #rf values(1157881375)
insert into #rf values(2202420850)
insert into #rf values(2202424486)
insert into #rf values(2202425866)
insert into #rf values(2202432681)
insert into #rf values(2202439713)
insert into #rf values(2202440662)
insert into #rf values(2202445324)
insert into #rf values(2202447916)
insert into #rf values(2202455523)
insert into #rf values(2204762176)
insert into #rf values(2204773326)
insert into #rf values(2204777066)
insert into #rf values(2204820345)
insert into #rf values(2204830268)
insert into #rf values(2204830835)
insert into #rf values(2204850947)
insert into #rf values(2204856775)
insert into #rf values(2204860181)
insert into #rf values(2204860185)
insert into #rf values(2204860192)
insert into #rf values(2204862059)
insert into #rf values(2204863975)
insert into #rf values(2204872659)
insert into #rf values(2204970678)
insert into #rf values(2204975932)
insert into #rf values(2204977012)
insert into #rf values(2214140128)
insert into #rf values(2214219666)
insert into #rf values(2214224242)
insert into #rf values(2214224685)
insert into #rf values(2214228752)
insert into #rf values(2214233968)
insert into #rf values(2214234937)
insert into #rf values(2214255529)
insert into #rf values(2214511073)
insert into #rf values(2214520443)
insert into #rf values(2214525192)
insert into #rf values(2214532252)
insert into #rf values(2214537729)
insert into #rf values(2214617806)
insert into #rf values(2214645317)
insert into #rf values(2214646304)
insert into #rf values(2214647094)
insert into #rf values(2214693507)
insert into #rf values(2214693832)
insert into #rf values(2214702801)
insert into #rf values(2214722904)
insert into #rf values(2214724133)
insert into #rf values(2214803585)
insert into #rf values(2214825854)
insert into #rf values(2214827852)
insert into #rf values(2214831432)
insert into #rf values(2214839222)
insert into #rf values(2214839823)
insert into #rf values(2214847547)
insert into #rf values(2214870277)
insert into #rf values(2214871824)
insert into #rf values(2215881815)
insert into #rf values(2223442802)
insert into #rf values(2224425992)
insert into #rf values(2224427181)
insert into #rf values(2224427480)
insert into #rf values(2224472210)
insert into #rf values(2224475313)
insert into #rf values(2224477447)
insert into #rf values(2224479224)
insert into #rf values(2224490021)
insert into #rf values(2224491109)
insert into #rf values(2225482892)
insert into #rf values(2227424128)
insert into #rf values(2229452093)
insert into #rf values(2234510447)
insert into #rf values(2234514592)
insert into #rf values(2234516035)
insert into #rf values(2234518862)
insert into #rf values(2234519568)
insert into #rf values(2234703541)
insert into #rf values(2234722540)
insert into #rf values(2234723864)
insert into #rf values(2234730879)
insert into #rf values(2234742023)
insert into #rf values(2234753176)
insert into #rf values(2234758667)
insert into #rf values(2234759572)
insert into #rf values(2234763506)
insert into #rf values(2234765468)
insert into #rf values(2234781490)
insert into #rf values(2234781536)
insert into #rf values(2234782368)
insert into #rf values(2234789228)
insert into #rf values(2234802079)
insert into #rf values(2234816745)
insert into #rf values(2234817048)
insert into #rf values(2234828409)
insert into #rf values(2234841684)
insert into #rf values(2234860485)
insert into #rf values(2234861287)
insert into #rf values(2234872933)
insert into #rf values(2234890191)
insert into #rf values(2234891567)
insert into #rf values(2234894639)
insert into #rf values(2234912222)
insert into #rf values(2234915943)
insert into #rf values(2234916462)
insert into #rf values(2234916817)
insert into #rf values(2234917165)
insert into #rf values(2234919458)
insert into #rf values(2234921174)
insert into #rf values(2234923145)
insert into #rf values(2234930265)
insert into #rf values(2234932455)
insert into #rf values(2234933108)
insert into #rf values(2234940610)
insert into #rf values(2234941372)
insert into #rf values(2234943426)
insert into #rf values(2234954274)
insert into #rf values(2234954769)
insert into #rf values(2234954928)
insert into #rf values(2234955054)
insert into #rf values(2234957245)
insert into #rf values(2234957279)
insert into #rf values(2234959963)
insert into #rf values(2234964002)
insert into #rf values(2241424607)
insert into #rf values(2241431938)
insert into #rf values(2245441891)
insert into #rf values(2246420847)
insert into #rf values(2257424120)
insert into #rf values(2257430026)
insert into #rf values(2262428994)
insert into #rf values(2262453674)
insert into #rf values(2266424976)
insert into #rf values(2281423623)
insert into #rf values(2281428700)
insert into #rf values(2281429601)
insert into #rf values(2281430578)
insert into #rf values(2281434423)
insert into #rf values(2284421093)
insert into #rf values(2291420274)
insert into #rf values(2291422183)
insert into #rf values(2291430034)
insert into #rf values(2293422605)
insert into #rf values(2293423400)
insert into #rf values(2293424109)
insert into #rf values(2293427416)
insert into #rf values(2293428848)
insert into #rf values(2293430840)
insert into #rf values(2293430926)
insert into #rf values(2293433434)
insert into #rf values(2293435869)
insert into #rf values(2293437697)
insert into #rf values(2293438426)
insert into #rf values(2293443878)
insert into #rf values(2293444157)
insert into #rf values(2302422403)
insert into #rf values(2302423424)
insert into #rf values(2302423732)
insert into #rf values(2302431428)
insert into #rf values(2302432459)
insert into #rf values(2302433200)
insert into #rf values(2314420422)
insert into #rf values(2314421307)
insert into #rf values(2317426965)
insert into #rf values(2317427563)
insert into #rf values(2317433496)
insert into #rf values(2320422441)
insert into #rf values(2320423408)
insert into #rf values(2320423424)
insert into #rf values(2320428717)
insert into #rf values(2320431907)
insert into #rf values(2322420250)
insert into #rf values(2322428008)
insert into #rf values(2322428101)
insert into #rf values(2322498947)
insert into #rf values(2323425763)
insert into #rf values(2323430489)
insert into #rf values(2323432713)
insert into #rf values(2323438509)
insert into #rf values(2323438600)
insert into #rf values(2323439354)
insert into #rf values(2324428889)
insert into #rf values(2324431377)
insert into #rf values(2324434003)
insert into #rf values(2324435804)
insert into #rf values(2335495270)
insert into #rf values(2342421701)
insert into #rf values(2342427670)
insert into #rf values(2344451511)
insert into #rf values(2346423007)
insert into #rf values(2346423417)
insert into #rf values(2346431257)
insert into #rf values(2346433508)
insert into #rf values(2346433917)
insert into #rf values(2346435960)
insert into #rf values(2352432428)
insert into #rf values(2362428772)
insert into #rf values(2374627129)
insert into #rf values(2374664154)
insert into #rf values(2374666031)
insert into #rf values(2374666574)
insert into #rf values(2374688889)
insert into #rf values(2374813411)
insert into #rf values(2374814559)
insert into #rf values(2374817385)
insert into #rf values(2374832336)
insert into #rf values(2374832616)
insert into #rf values(2374843766)
insert into #rf values(2374851221)
insert into #rf values(2392422144)
insert into #rf values(2392423002)
insert into #rf values(2392424649)
insert into #rf values(2392424922)
insert into #rf values(2392433129)
insert into #rf values(2395451080)
insert into #rf values(2396471043)
insert into #rf values(2396472580)
insert into #rf values(2396472739)
insert into #rf values(2396477244)
insert into #rf values(2474423158)
insert into #rf values(2474425417)
insert into #rf values(2475465677)
insert into #rf values(2477428009)
insert into #rf values(2477432190)
insert into #rf values(2477438318)
insert into #rf values(2478452498)
insert into #rf values(2478456018)
insert into #rf values(2614122404)
insert into #rf values(2614122870)
insert into #rf values(2614200198)
insert into #rf values(2614204213)
insert into #rf values(2614205187)
insert into #rf values(2614220787)
insert into #rf values(2614225105)
insert into #rf values(2614230874)
insert into #rf values(2614232152)
insert into #rf values(2614234345)
insert into #rf values(2614235436)
insert into #rf values(2614235704)
insert into #rf values(2614236399)
insert into #rf values(2614238092)
insert into #rf values(2614239074)
insert into #rf values(2614244914)
insert into #rf values(2614247042)
insert into #rf values(2614252250)
insert into #rf values(2614254693)
insert into #rf values(2614255566)
insert into #rf values(2614256326)
insert into #rf values(2614259546)
insert into #rf values(2614264501)
insert into #rf values(2614266511)
insert into #rf values(2614272655)
insert into #rf values(2614295237)
insert into #rf values(2614297647)
insert into #rf values(2614298233)
insert into #rf values(2614298543)
insert into #rf values(2614299843)
insert into #rf values(2614300574)
insert into #rf values(2614302897)
insert into #rf values(2614314301)
insert into #rf values(2614314883)
insert into #rf values(2614321195)
insert into #rf values(2614323288)
insert into #rf values(2614325616)
insert into #rf values(2614325960)
insert into #rf values(2614340193)
insert into #rf values(2614372880)
insert into #rf values(2614392894)
insert into #rf values(2614395807)
insert into #rf values(2614399090)
insert into #rf values(2614443356)
insert into #rf values(2614456066)
insert into #rf values(2614523017)
insert into #rf values(2614527462)
insert into #rf values(2614632541)
insert into #rf values(2614813311)
insert into #rf values(2614930463)
insert into #rf values(2614932228)
insert into #rf values(2614970122)
insert into #rf values(2614970174)
insert into #rf values(2614972788)
insert into #rf values(2614985643)
insert into #rf values(2614988948)
insert into #rf values(2622426091)
insert into #rf values(2623424968)
insert into #rf values(2623431364)
insert into #rf values(2623443950)
insert into #rf values(2623492943)
insert into #rf values(2627422342)
insert into #rf values(2627423878)
insert into #rf values(2627434161)
insert into #rf values(2627436056)
insert into #rf values(2627439380)
insert into #rf values(2627446803)
insert into #rf values(2627447620)
insert into #rf values(2627447719)
insert into #rf values(2627447977)
insert into #rf values(2644201821)
insert into #rf values(2644203760)
insert into #rf values(2644203996)
insert into #rf values(2644216310)
insert into #rf values(2644217355)
insert into #rf values(2644222526)
insert into #rf values(2644222684)
insert into #rf values(2644222899)
insert into #rf values(2644229109)
insert into #rf values(2644230361)
insert into #rf values(2644236630)
insert into #rf values(2644241080)
insert into #rf values(2644242875)
insert into #rf values(2644243322)
insert into #rf values(2644250045)
insert into #rf values(2644250620)
insert into #rf values(2644264734)
insert into #rf values(2644267249)
insert into #rf values(2644272780)
insert into #rf values(2644274226)
insert into #rf values(2644277328)
insert into #rf values(2644285531)
insert into #rf values(2644286047)
insert into #rf values(2644343790)
insert into #rf values(2644345548)
insert into #rf values(2644933824)
insert into #rf values(2652426142)
insert into #rf values(2657421834)
insert into #rf values(2657425681)
insert into #rf values(2657428098)
insert into #rf values(2657431888)
insert into #rf values(2901421209)
insert into #rf values(2901422161)
insert into #rf values(2901423811)
insert into #rf values(2901425525)
insert into #rf values(2901431546)
insert into #rf values(2901432873)
insert into #rf values(2901445699)
insert into #rf values(2901492034)
insert into #rf values(2914502404)
insert into #rf values(2914510908)
insert into #rf values(2914511301)
insert into #rf values(2914515656)
insert into #rf values(2914516221)
insert into #rf values(2914517822)
insert into #rf values(2914518115)
insert into #rf values(2914518842)
insert into #rf values(2914524766)
insert into #rf values(2914537356)
insert into #rf values(2914557615)
insert into #rf values(2914563377)
insert into #rf values(2914570037)
insert into #rf values(2914819960)
insert into #rf values(2914884557)
insert into #rf values(2920423363)
insert into #rf values(2920424200)
insert into #rf values(2920425529)
insert into #rf values(2920426785)
insert into #rf values(2920429992)
insert into #rf values(2920464166)
insert into #rf values(2920465388)
insert into #rf values(2922462026)
insert into #rf values(2922464908)
insert into #rf values(2926422230)
insert into #rf values(2926422231)
insert into #rf values(2926424000)
insert into #rf values(2926431620)
insert into #rf values(2932421452)
insert into #rf values(2932421836)
insert into #rf values(2932422695)
insert into #rf values(2932430645)
insert into #rf values(2932431461)
insert into #rf values(2932432342)
insert into #rf values(2934497066)
insert into #rf values(2936432327)
insert into #rf values(2941424727)
insert into #rf values(2941425080)
insert into #rf values(2941432345)
insert into #rf values(2941463246)
insert into #rf values(2941464360)
insert into #rf values(2944423384)
insert into #rf values(2944424488)
insert into #rf values(2944425580)
insert into #rf values(2944425953)
insert into #rf values(2944434797)
insert into #rf values(2944494060)
insert into #rf values(2944494874)
insert into #rf values(2944721840)
insert into #rf values(2945453625)
insert into #rf values(2945454508)
insert into #rf values(2945455105)
insert into #rf values(2945456586)
insert into #rf values(2954428814)
insert into #rf values(2962454431)
insert into #rf values(2964420516)
insert into #rf values(2964422293)
insert into #rf values(2964422758)
insert into #rf values(2964425969)
insert into #rf values(2964427178)
insert into #rf values(2964427327)
insert into #rf values(2964427932)
insert into #rf values(2965420159)
insert into #rf values(2965423336)
insert into #rf values(2965424124)
insert into #rf values(2965428084)
insert into #rf values(2965429236)
insert into #rf values(2965443175)
insert into #rf values(2965454191)
insert into #rf values(2965470157)
insert into #rf values(2965472714)
insert into #rf values(2965472872)
insert into #rf values(2965475206)
insert into #rf values(2965481940)
insert into #rf values(2965483834)
insert into #rf values(2966437910)
insert into #rf values(2966440147)
insert into #rf values(2966457813)
insert into #rf values(2974452447)
insert into #rf values(2974461051)
insert into #rf values(2974461942)
insert into #rf values(2974462938)
insert into #rf values(2974468031)
insert into #rf values(2974468522)
insert into #rf values(2974474475)
insert into #rf values(2974479117)
insert into #rf values(2974483830)
insert into #rf values(2974484768)
insert into #rf values(2974486580)
insert into #rf values(2974486727)
insert into #rf values(2974486818)
insert into #rf values(2983428309)
insert into #rf values(2983429056)
insert into #rf values(2994413251)
insert into #rf values(2994422463)
insert into #rf values(2994422925)
insert into #rf values(2994422985)
insert into #rf values(2994423095)
insert into #rf values(2994425768)
insert into #rf values(2994428810)
insert into #rf values(2994429632)
insert into #rf values(2994438732)
insert into #rf values(2994438849)
insert into #rf values(2994450309)
insert into #rf values(2994453333)
insert into #rf values(2994462832)
insert into #rf values(2994468579)
insert into #rf values(2994469452)
insert into #rf values(2994473490)
insert into #rf values(2994474637)
insert into #rf values(2994475100)
insert into #rf values(2994475140)
insert into #rf values(2994477090)
insert into #rf values(2994479704)
insert into #rf values(2994486873)
insert into #rf values(2994488541)
insert into #rf values(2994774720)
insert into #rf values(2994776708)
insert into #rf values(2994777509)
insert into #rf values(2994778399)
insert into #rf values(2994791681)
insert into #rf values(2994823874)
insert into #rf values(2994855105)
insert into #rf values(2994949268)
insert into #rf values(3414111514)
insert into #rf values(3414521222)
insert into #rf values(3476422965)
insert into #rf values(3514115847)
insert into #rf values(3874245568)


select * from me