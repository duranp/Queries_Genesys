

SELECT * FROM OPENQUERY(DW,'SELECT * FROM TASA.CENTRAL')
SELECT distinct * FROM #IOL WHERE upper(RTRIM(LTRIM(TX_CENTRAL))) NOT IN (SELECT upper(RTRIM(LTRIM(TX_CENTRAL))) FROM DT_CENTRAL)
select * from tb t inner join dt_central c on t.cd_central = c.cd_central
where fc_Cumplimiento >= '01/01/2010'

select * into dt_central2 from OPENQUERY(DW,'SELECT * FROM TASA.CENTRAL')
select * from dt_central2

--tb
select avg(datediff(day,fc_emision, fc_Cumplimiento)),sum(case when cd_estado_tramite = 'fa' then 1 else 0 end)fa, sum(case when cd_estado_tramite = 'an' then 1 else 0 end)an
from tb t 
	inner join [pegaso1\sql2000].posventa.dbo.borrar_pedidos_iol i 
		on t.cd_pedido_cliente = i.cd_pedido and t.cd_sub_pedido = i.cd_sub_pedido
		where cd_estado_tramite = 'fa'

select avg(datediff(day,fc_emision, fc_Cumplimiento)),sum(case when cd_estado_tramite = 'fa' then 1 else 0 end)fa, sum(case when cd_estado_tramite = 'an' then 1 else 0 end)an
from tb t 
	WHERE CD_PEDIDO_CLIENTE IN (SELECT CD_PEDIDO FROM [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO)
	and cd_pedido_cliente not in (select cd_pedido from [pegaso1\sql2000].posventa.dbo.borrar_pedidos_iol)
	and fc_cumplimiento >= '01/02/2010'
	and cd_estado_tramite = 'fa'
			
		select * from tb where cd_pedido_cliente in (select cd_pedido from [pegaso1\sql2000].posventa.dbo.borrar_pedidos_iol)
--adsl		
select avg(datediff(day,fc_emision, fc_Cumplimiento)),sum(case when cd_estado_tramite = 'CU' then 1 else 0 end)fa, sum(case when cd_estado_tramite = 'an' then 1 else 0 end)an
from ADSL t 
	inner join [pegaso1\sql2000].posventa.dbo.borrar_pedidos_iol i 
		on t.cd_pedido_cliente = i.cd_pedido and t.cd_sub_pedido = i.cd_sub_pedido
	and cd_estado_tramite = 'cu'	
	
select avg(datediff(day,fc_emision, fc_Cumplimiento)),sum(case when cd_estado_tramite = 'cu' then 1 else 0 end)fa, sum(case when cd_estado_tramite = 'an' then 1 else 0 end)an
from adsl t 
	WHERE CD_PEDIDO_CLIENTE IN (SELECT CD_PEDIDO FROM [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO)
	and cd_pedido_cliente not in (select cd_pedido from [pegaso1\sql2000].posventa.dbo.borrar_pedidos_iol)
	and fc_cumplimiento >= '01/02/2010'
	and cd_estado_tramite = 'cu'
	
	
select distinct cd_central from tb WHERE CD_PEDIDO_CLIENTE IN (SELECT CD_PEDIDO FROM [pegaso1\sql2000].posventa.dbo.BORRAR_pedidos_iol)

--emitidos informado tb zona iol o no_iol
select sum(1) from adsl where cd_central  in (select cd_central from [pegaso1\sql2000].posventa.dbo.BORRAR_pedidos_iol)
and cd_pedido_cliente in (SELECT CD_PEDIDO FROM [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO)
and fc_emision >= '01/02/2010'


sp_helptext dmy
select year(fc_cumplimiento), month(fc_cumplimiento),day(fc_Cumplimiento), 
sum(case when cd_estado_tramite in ('fa','cu') then 1 else 0 end) fa, 
sum(case when cd_estado_tramite = 'an' then 1 else 0 end) an
from tb where cd_producto not like '%p%' and fc_cumplimiento is not null
group by year(fc_cumplimiento), month(fc_cumplimiento),day(fc_Cumplimiento)
order by year(fc_cumplimiento), month(fc_cumplimiento),day(fc_Cumplimiento)

select * from pd_indicadores where tx_producto = 'lan' and fc_dia >= '01/04/2010' 

select 



select top 10 * from [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO 

select * into #inf from [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO 

select distinct t.* from tb t 
	inner join #inf i
		on t.cd_pedido_cliente = i.cd_pedido and t.cd_sub_pedido = i.cd_sub_pedido and t.cd_tramite = i.cd_tramite
where fc_cumplimiento between '01/03/2010' and '31/03/2010' 
and cd_estado_tramite  = 'fa' and cd_producto not like '%p%'

select * from v_tb where fc_cumplimiento between '01/03/2010' and '31/03/2010' 
and tx_estado_tramite  = 'facturado' and tx_producto not like '%voip%'

and cd_pedido_cliente in (select cd_pedido from [pegaso1\sql2000].posventa.dbo.BORRAR_INFORMADOS_PEGASO where cd_producto_pgc in ('tb','tb mp'))

select sum(1) FROM #mc --INDICADORES.ANALISIS.DBO.MOTIVOS_tb WHERE CD_IMPLICANCIA = 'C'
select * from #mc
drop table BORRAR_INFORMADOS_PEGASO
select p.cd_pedido, p.cd_sub_pedido, p.cd_tramite, p.cd_producto_pgc, e.timestamp, M.TX_MOTIVO
INTO BORRAR_INFORMADOS_PEGASO
from pgc_pedidos p 
	inner join vw_pgc_estados e
		on  p.cd_pedido = e.cd_pedido
		and p.cd_sub_pedido = e.cd_sub_pedido
		and p.cd_tramite = e.cd_tramite
	INNER JOIN DT_MOTIVO M
		ON E.CD_MOTIVO = M.CD_MOTIVO
where 
e.cd_usuario in ('cota') and e.tx_estado_pgc = 'informado' and p.cd_producto_pgc in ('ADSL', 
'EQ VOIP',
'CAM24',
'FWT',
'LAN OFFICE',
'MIGR LAN',
'MIGR VOIP',
'PC',
'PDTI',
'SFT-MUSICA',
'SPD READY',
'TB',
'TB MP',
'VOIP',
'VPN'
)