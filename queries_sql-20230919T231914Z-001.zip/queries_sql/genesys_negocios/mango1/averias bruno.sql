SELECT 
distinct
case when p.tx_producto is null then 'SIN ADSL' 
	 when P.tx_producto like '%lan%' then 'LAN' 
	 when P.tx_producto like '%cam%'then 'CAM' 
	 else 'SPEEDY'  
end PRODUCTO, 	
case when cd_tipo_actuacion_cierre in (334,344) then 'si' else 'no' end robo, 
case when v.cd_pedido_cliente is not null or v2.cd_pedido_cliente is not null  then 'si' else 'no' end en_garantia,
a.*
FROM CATE..AVERIAS A 
	left JOIN PARQUE_SPEEDY P ON A.ANI = P.ANI and p.TX_PRODUCTO NOT LIKE 'MEGA%'
	inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
	left join adsl v on v.ani = a.ani and a.fh_ingreso between v.fc_cumplimiento and dateadd(day, 30, v.fc_cumplimiento)
	left join tb v2 on v2.ani = a.ani and a.fh_ingreso between v2.fc_cumplimiento and dateadd(day, 30, v2.fc_cumplimiento)
where a.fh_cierre	>= dbo.pd(dateadd(month,-11,getdate()))





select * from bv_bienvenida where fc_cumplimiento = '01/06/2010'

select top 10 * from [pegaso1\sql2000].posventa.dbo.bv_source where fc_cumplimiento = '01/06/2010'

where cd_pedido = '193192512'