--control de actualizacion
select max(fc_Cumplimiento),tx_producto from vw_cumplidos group by tx_producto



--PORCENTAJE EN AGENDA -- Roleo, Ventas terminadas (F o C) con ag / Tot Vtas
select	s, tx_tipo_cliente, sum(1) total, sum(CASE WHEN agenda = 'SI' THEN 1 ELSE 0 END) agenda, replace(1.0*sum(CASE WHEN agenda = 'SI' THEN 1 ELSE 0 END)/sum(1),'.',',') ag
from
	(		
	select	cast(month(fc_cumplimiento) as varchar(10)) + '-' + cast(datepart(wk,fc_cumplimiento) as varchar(2)) s,
			CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
			CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA
	from	vw_cumplidos p
			--left join dt_tipo_cliente tc				on tc.cd_tipo_cliente = p.cd_tipo_cliente
	where	fc_emision >= '2010-08-01'
			/*and cd_producto_pgc in ('ADSL VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
			and cd_unidad_negocio in ('PCA','PNC')*/
			and fc_cumplimiento is not null --and fc_cumplimiento < dbo.dmy(dateadd(day,-1*datepart(weekday,getdate()),getdate()))
	) x 
group by  s, tx_tipo_cliente
with rollup
order by s, tx_tipo_cliente


--PORCENTAJE EN AGENDA mensual
	select	m, tx_tipo_cliente, sum(1) total, sum(CASE WHEN agenda = 'SI' THEN 1 ELSE 0 END) agenda, replace(1.0*sum(CASE WHEN agenda = 'SI' THEN 1 ELSE 0 END)/sum(1),'.',',') ag
	from
		(		
		select	month(fc_cumplimiento) m,
				CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
				CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA
		from	vw_cumplidos p
				--left join dt_tipo_cliente tc				on tc.cd_tipo_cliente = p.cd_tipo_cliente
		where	fc_emision >= '2010-08-01'
				/*and cd_producto_pgc in ('ADSL VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
				and cd_unidad_negocio in ('PCA','PNC')*/
				and fc_cumplimiento is not null and fc_cumplimiento < dbo.dmy(dateadd(day,-1*datepart(weekday,getdate()),getdate()))
		) x 
	group by  m, tx_tipo_cliente
	with rollup
	order by m, tx_tipo_cliente

--TMI
select	q, agenda, avg(TI*1.0) TMI
from
	(		
	select	cast(month(fc_cumplimiento) as varchar(10)) + '-' + cast(datepart(wk,fc_Cumplimiento) as varchar(2)) q,
			CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
			CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA,
			datediff(day, fc_emision, fc_cumplimiento) TI
	from	vw_cumplidos p
			--lft join dt_tipo_cliente tc				on tc.cd_tipo_cliente = p.cd_tipo_cliente
	where	fc_emision >= '2010-08-01' and tx_estado in ('fa','cu')
			/*and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
			and cd_unidad_negocio in ('PCA','PNC')*/
			and fc_cumplimiento is not null
	) x
group by  q, agenda
with rollup
order by q, agenda



	--tmi mensual
	select	q, agenda, avg(TI*1.0) TMI, sum(1)
	from
		(		
		select	cast(month(fc_cumplimiento) as varchar(10)) q,
				CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
				CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA,
				datediff(day, fc_emision, fc_cumplimiento) TI
		from	vw_cumplidos p
				--left join dt_tipo_cliente tc					on tc.cd_tipo_cliente = p.cd_tipo_cliente
		where	fc_emision >= '2010-08-01' and tx_estado in ('fa','cu')
				/*and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
				and cd_unidad_negocio in ('PCA','PNC')*/
				and fc_cumplimiento is not null and fc_Cumplimiento < dbo.dmy(dateadd(day,-1*datepart(weekday,getdate()),getdate()))
		) x
	group by  q, agenda
	with rollup
	order by q, agenda

--EFICIENCIA

select	ms,/* cd_producto_pgc,*/ agenda, sum(1) TOTAL, sum(CASE WHEN tx_estado IN ('CU','FA') THEN 1 ELSE 0 END) CU,
		round(100 * cast(sum(CASE WHEN tx_estado IN ('CU','FA') THEN 1 ELSE 0 END) as float) / sum(1),1) EF,
		avg(CASE WHEN tx_estado IN ('CU','FA') THEN datediff(day,fc_emision,fc_cumplimiento) ELSE null END) TMI,
		avg(CASE WHEN tx_estado IN ('CU','FA') THEN null ELSE datediff(day,fc_emision,fc_cumplimiento) END) TMC
from
	(		
	select	cast(month(fc_cumplimiento) as varchar(10)) + '-' + cast(datepart(wk,fc_Cumplimiento) as varchar(2))ms,*, 
	CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA
	from	vw_cumplidos p
	where	fc_cumplimiento >= '2010-07-01' 
			--and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
	) x
where fc_cumplimiento is not null--tx_estado in ('CU','FA','AN')
group by ms/*, cd_producto_pgc*/, agenda
order by ms/*, cd_producto_pgc*/, agenda

	--Eficiencia mensual
	select	cast(month(fc_cumplimiento) as varchar(10)) m,/* cd_producto_pgc,*/ agenda, sum(1) TOTAL, sum(CASE WHEN tx_estado IN ('CU','FA') THEN 1 ELSE 0 END) CU,
			round(100 * cast(sum(CASE WHEN tx_estado IN ('CU','FA') THEN 1 ELSE 0 END) as float) / sum(1),1) EF,
			avg(CASE WHEN tx_estado IN ('CU','FA') THEN datediff(day,fc_emision,fc_cumplimiento) ELSE null END) TMI,
			avg(CASE WHEN tx_estado IN ('CU','FA') THEN null ELSE datediff(day,fc_emision,fc_cumplimiento) END) TMC
	from
		(		
		select	*, CASE WHEN EXISTS (select cd_pedido from vw_pgc_estados e where e.timestamp > '20100601' and e.cd_pedido = p.cd_pedido and e.cd_sub_pedido = p.cd_sub_pedido and e.cd_tramite = p.cd_tramite and e.tx_estado_pgc = 'ESPERANDO ATADO') THEN 'SI' ELSE 'NO' END AGENDA
		from	vw_cumplidos p
		where	fc_cumplimiento >= '2010-07-01' --and fc_cumplimiento < '20101012'
				--and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
		) x
	where fc_cumplimiento is not null and fc_cumplimiento < dbo.dmy(dateadd(day,-1*datepart(weekday,getdate()),getdate()))
	group by cast(month(fc_cumplimiento) as varchar(10))/*, cd_producto_pgc*/, agenda
	order by cast(month(fc_cumplimiento) as varchar(10)) /*, cd_producto_pgc*/, agenda


--facturado / le 
select sum(1) 	le
from	pgc_pendientes p
	where	 cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')

select sum(1) facturado
	from	pgc_pedidos p
	where	tx_estado in ('fa','cu')
			and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
	and datepart(wk,fc_cumplimiento) = datepart(wk,getdate()) 

	--facturado / le mensual
	select sum(1) 	le
	from	pgc_pendientes p
		where	 cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')

	select sum(1) facturado
		from	pgc_pedidos p
		where	tx_estado in ('fa','cu')
				and cd_producto_pgc in ('ADSL VOIP','EQ VOIP','LAN OFFICE','MIGR LAN','MIGR VOIP','TB','TB MP','VOIP')
		and datepart(wk,fc_cumplimiento) = datepart(wk,getdate()) 

select * from pgc_pendientes where cd_producto_pgc = 'tb mp' and cd_pedido in (select cd_pedido from pgc_pendientes where cd_producto_pgc = 'voip')

select * from pgc_pendientes where cd_pedido = 187480426





/*
--CUMPLIMIENTO DE CITAS / PEDIDOS 
select	cast(month(fc_cita) as varchar(10)) + '-' + cast(datepart(wk,fc_cita) as varchar(2)) q, sum(1),
		CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
 		replace(1.0*sum(CASE WHEN datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3) THEN 1 ELSE 0 END)/sum(1),'.',',') puntualidad,
		replace(1.0*sum(CASE WHEN franqueo_2 = 'CUMPLIDO' and (datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3)) THEN 1 ELSE 0 END)/(sum(CASE WHEN datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3) THEN 1 ELSE 0 END)+0.000000001),'.',',') cumplimiento_puntual
from	pgc_citas_gpym c
		left join pgc_actuaciones a
			on a.cd_ot = c.cd_ot
		left join pgc_pedidos p
			on p.cd_pedido = c.cd_pedido
			and p.cd_sub_pedido = c.cd_sub_pedido
			and p.cd_tramite = c.cd_tramite
		left join dt_tipo_cliente tc
			on tc.cd_tipo_cliente = p.cd_tipo_cliente
		left join VW_PGC_ESTADOS IOL
			ON IOL.CD_PEDIDO = c.CD_PEDIDO
			AND IOL.CD_SUB_PEDIDO = c.CD_SUB_PEDIDO
			AND IOL.CD_TRAMITE = c.CD_TRAMITE
			AND TX_G_ACCION = 'INFORMADOS ONLINE'
			AND datediff(day,FC_CITA, IOL.Timestamp) = 0
where	c.cd_ot is not null and datediff(day,a.fc_ingreso_gaudi,c.fc_cita)>=1
		and c.fc_cita < dateadd(day,-1,getdate())
group by cast(month(fc_cita) as varchar(10)) + '-' + cast(datepart(wk,fc_cita) as varchar(2)) , CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END
with rollup
order by cast(month(fc_cita) as varchar(10)) + '-' + cast(datepart(wk,fc_cita) as varchar(2)) , CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END

	--mes actual
	select	cast(month(fc_cita) as varchar(10))  q,
			CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END tx_tipo_cliente,
 			replace(1.0*sum(CASE WHEN datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3) THEN 1 ELSE 0 END)/sum(1),'.',',') puntualidad,
			replace(1.0*sum(CASE WHEN franqueo_2 = 'CUMPLIDO' and (datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3)) THEN 1 ELSE 0 END)/(sum(CASE WHEN datediff(day,c.fc_cita,a.fc_fin_real) = 0 or (IOL.cd_pedido is not null and datediff(day,c.fc_cita,a.fc_fin_real) between 0 and 3) THEN 1 ELSE 0 END)+0.000000001),'.',',') cumplimiento_puntual
	from	pgc_citas_gpym c
			left join pgc_actuaciones a
				on a.cd_ot = c.cd_ot
			left join pgc_pedidos p
				on p.cd_pedido = c.cd_pedido
				and p.cd_sub_pedido = c.cd_sub_pedido
				and p.cd_tramite = c.cd_tramite
			left join dt_tipo_cliente tc
				on tc.cd_tipo_cliente = p.cd_tipo_cliente
			left join VW_PGC_ESTADOS IOL
				ON IOL.CD_PEDIDO = c.CD_PEDIDO
				AND IOL.CD_SUB_PEDIDO = c.CD_SUB_PEDIDO
				AND IOL.CD_TRAMITE = c.CD_TRAMITE
				AND TX_G_ACCION = 'INFORMADOS ONLINE'
				AND datediff(day,FC_CITA, IOL.Timestamp) = 0
	where	c.cd_ot is not null and datediff(day,a.fc_ingreso_gaudi,c.fc_cita)>=1
			and c.fc_cita < dateadd(day,-1,getdate()) and fc_cita < dbo.dmy(dateadd(day,-1*datepart(weekday,getdate()),getdate()))
	group by cast(month(fc_cita) as varchar(10))  , CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END
	with rollup
	order by cast(month(fc_cita) as varchar(10)) , CASE WHEN tx_tipo_cliente like 'ALTO %' THEN 'AV-AR' WHEN tx_tipo_cliente like 'TOP %' THEN 'TOP' ELSE 'MASIVO-COMP' END
*/