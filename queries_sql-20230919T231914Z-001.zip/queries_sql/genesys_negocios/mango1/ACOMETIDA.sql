select * from motivos_red


select * from v_vitacora where timestamp >= '01/04/2010'

select cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4) ani,* 
from analisis..acometidas a
	inner join cate..averias on ani = cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4) 
	and fh_cierre between dateadd(month,-4,mes) and mes

select cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4) ani,* 
from analisis..acometidas a
	inner join cate..averias on ani = cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4) 
	and fh_cierre between dateadd(month,1,mes) and dateadd(month,4,mes)
	
select (
	select sum(1) from cate..averias 
	where ani = cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4)
	and  fh_cierre between dateadd(month,-4,mes) and mes) pres
,
(
	select sum(1) from cate..averias 
	where ani = cast(interurbano as varchar(4))+cast(urbano as varchar(4))+right('0'+cast(linea as varchar(4)),4)
	and fh_cierre between dateadd(month,1,mes) and dateadd(month,5,mes)) post
,
* 
from analisis..acometidas a
	
/*

select * from iad where cd_producto_es = '0220000044212' and fc_cumplimiento = '08/04/2010' and cd_estado_tramite = 'cu'
select * from tb where fc_cumplimiento = '08/04/2010' and cd_estado_tramite = 'fa' and cd_producto like '%p%' and


select * from tb where cd_pedido_cliente in (188489536,186071172,188489536,186071172)

select * from iad i inner join tb t on i.cd_pedido_cliente = t.cd_pedido_cliente and i.fc_cumplimiento <> t.fc_cumplimiento
and i.fc_cumplimiento > = '01/04/2010'


select * from iad where fc_cumplimiento = '08/04/2010' and cd_estado_tramite = 'cu' and tx_motivo_canc is  null
*/

select (
	select sum(1) from cate..averias 
	where ani = a.ani
	and  fh_cierre between dateadd(month,-4,mes) and mes) pres
,
(
	select sum(1) from cate..averias 
	where ani = a.ani
	and fh_cierre between dateadd(month,1,mes) and dateadd(month,5,mes)) post
,
* 
from analisis..acometidas a


select ani, count(*) from cate..averias where tx_tipo_cliente like '%valor%' and year(fh_cierre) = 2010
and month(fh_cierre) = 3
group by ani



SELECT * 
	FROM ACOMETIDAS_FINAL F 
		LEFT JOIN VTV_AVE V 
			ON F.ANI = V.ANI
			AND CD_CASO = (SELECT MAX(CD_CASO) FROM VTV_AVE WHERE ANI = F.ANI AND FC_LLAMADA<MES)
			
			