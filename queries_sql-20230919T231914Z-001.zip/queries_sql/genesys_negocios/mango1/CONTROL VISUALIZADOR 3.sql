select distinct month(timestamp) mes, v.cd_central, v.cd_manzana, v.tx_calle, v.vl_numero, cd_estado_tramite, r_tb_pe, r_tb_pi
	from v_vitacora v 
		left join tramites_domicilio r  
			on v.cd_central = r.cd_central and v.cd_manzana = r.cd_manzana and v.tx_calle = r.tx_calle
			and cast(replace(fc_emision,'-','') as datetime) between timestamp and dateadd(day,10,timestamp)
			and v.vl_numero = r.vl_numero
where 
(r_zp = 'no' and r_tb_pe = 'si' and r_tb_pi = 'si') and len(v.vl_numero) <7 
and year(timestamp) = 2010


select * from v_parque_tb_sp where ani = '1142712164'

select distinct r.*, case when v.timestamp is not null then 'si' else 'no' end v,
case when r_tb_pe = 'si' and r_tb_pi = 'si' and r_zp = 'no' then 'si' else 'no' end res
	from v_vitacora v 
		right join tramites_domicilio r  
			on v.cd_central = r.cd_central and v.cd_manzana = r.cd_manzana and v.tx_calle = r.tx_calle
			and cast(replace(fc_emision,'-','') as datetime) between timestamp and dateadd(day,10,timestamp)
			--and v.vl_numero = r.vl_numero
where r.cd_pedido_cliente in (select cd_pedido_cliente from  [10.244.65.234].posventa.dbo.tb)
and cast(replace(r.fc_emision,'-','') as smalldatetime) >= '01/01/2010'

/*
select * from v_parque_tb_sp where tx_calle = 'BALANCINI VIUDA DE RODRIGUEZ' and nu_calle between '03600' and '03700'
and cd_central = 56

select * from v_manzanero where 
--tx_calle = 'BALANCINI VIUDA DE RODRIGUEZ' --and nu_desde between '03600' and '03700'and 
cd_central = 56 and cd_manzana = 85

select * from v_pe where cd_central = 56 and manzana in (84,85)
select * from v_pi where [cntcd]= 56 
select * from v_zona_peligrosa where cd_central = 56 and cd_manzana in (84,85)

*/
drop table #t
drop table #t2
