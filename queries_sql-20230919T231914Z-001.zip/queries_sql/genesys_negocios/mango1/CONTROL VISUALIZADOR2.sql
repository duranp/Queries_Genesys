select distinct v.cd_manzana,v.cd_central, v.tx_calle, v.vl_numero--, r.cd_pedido, r.tx_estado, r.tx_motivo 
from 
v_vitacora v inner join v_retrabajos r on v.cd_manzana = r.cd_manzana and v.cd_central = r.cd_central and v.tx_calle = r.tx_calle and v.vl_numero = r.vl_numero
and timestamp >= '01/02/2010' and v.timestamp < r.fc_emision 
 and cd_producto_pgc in ('tb','tb mp')
 and r.tx_estado  in ('an')
 and (r_tb_pe = 'no' or r_tb_pi ='no' or r_zp = 'si')
 and fc_cumplimiento is not null
 
 --select min(timestamp) from v_vitacora
