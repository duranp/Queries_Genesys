--adaptacion 
update analisis..averias_gpym set tarea_gpym = null where tarea_gpym = '?'


drop table #a

select distinct *,isnull(tarea_gpym,tx_tipo_actuacion) fr into #a from analisis..averias_gpym  
where ani not in (select ani from analisis..averias_gpym  where tx_tipo_actuacion like '%tups%' or tx_tipo_actuacion like '%autofranqueo%' )

select ani,sum(1) cant into #ranking from #a group by ani order by sum(1) desc
select * from #ranking 

select sum(1) from #ranking where cant > 3

select * from #a where ani = '1142389320' order by cd_averia

select * from #a where ani in (select ani from #ranking where cant > 3)


select * from #a where fr = 'informar' and ani in (select ani from #ranking where cant > 3)
select * from #a where ani = '2202445762'

select * from #ranking where ani = '1146528675'

SELECT DISTINCT TX_AGENTE_EXTERNO FROM ADSL WHERE TX_CANAL_VENTA = 'ALTO RIESGO T-NGC'
/*

drop table #a
select a.*
--,g.tx_tipo_actuacion, g.tarea_gpym 
select a.*, isnull(tarea_gpym,tx_tipo_actuacion) fr				
into #a
from cate..averias a inner join dt_tipo_cliente tc on a.cd_tipo_cliente = tc.cd_tipo_cliente and tc.cd_unidad_negocio in ('pca','pnc') 
inner join analisis..averias_gpym g on a.cd_averia = g.cd_averia

select * from cate..averias a inner join dt_tipo_cliente tc on a.cd_tipo_cliente = tc.cd_tipo_cliente and tc.cd_unidad_negocio in ('pca','pnc') 
where cd_averia not in (select cd_averia from analisis..averias_gpym)
and fh_cierre between '01/10/2009' and '31/03/2010'

select cd_averia from analisis..averias_gpym group by cd_averia having count(*) >1

where fh_cierre between '01/10/2009' and '31/03/2010'

select * from analisis..averias_gpym where cd_averia = '2010000015676042'


select top 100 * from adsl where fc_cumplimiento is null and cd_estado_tramite <>'an'

select top 10 * from analisis..averias_gpym group by cd_averia having count(*) >1



select 
*/