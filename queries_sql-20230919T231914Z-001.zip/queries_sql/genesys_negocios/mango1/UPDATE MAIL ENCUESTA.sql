use cate
update e_usuarios_j set tx_mail = 'martin.contreras@telefonica.com' where tx_mail = 'martin.contreras@telefonica.com.ar'

DECLARE @MAIL AS VARCHAR(100)
SET @MAIL = 'ivan.fortunesky@teleperformance.coma.r'

select 'AG' ROL, * from e_usuarios_j where tx_mail = @MAIL
UNION ALL
select 'SUP' ROL, * from e_usuarios_j where id_usuario = (
select id_parent from e_usuarios_j where tx_mail = @MAIL)