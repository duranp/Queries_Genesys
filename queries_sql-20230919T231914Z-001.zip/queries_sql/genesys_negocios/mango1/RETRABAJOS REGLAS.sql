select * from v_retrabajos_reglas where motivo_real like  'NUNCA FUE%'

select distinct tx_g_motivo_real from v_retrabajos p left join v_retrabajos_reglas r on p.tx_g_motivo_real = r.motivo_real
where r.motivo_real is not null

select distinct tx_motivo from v_retrabajos p left join v_retrabajos_reglas r on p.tx_motivo = r.motivo_cota
where r.motivo_cota is null and tx_estado = 'an'

select DISTINCT TX_ESTADO

/*
ISNULL(R.[ACCI�N RECOMENDADA], R2.[ACCI�N RECOMENDADA]) ACCION_RECOMENDADA,
ISNULL(R.[ACCION DEL CANAL], R2.[ACCION DEL CANAL]) ACCION_DEL_CANAL,
P.* 
*/

from v_retrabajos p 
	left join v_retrabajos_reglas r on p.tx_g_motivo_real = r.motivo_real
	left join v_retrabajos_reglas r2 on p.tx_motivo = r2.motivo_cota
where cd_central = 348 and cd_manzana = 19


