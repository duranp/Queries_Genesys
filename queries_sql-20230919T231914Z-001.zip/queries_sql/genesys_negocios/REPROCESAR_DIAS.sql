insert into reprocesos values('ppp','01/01/2013',0)
insert into reprocesos values('ppp','03/01/2013',0)
insert into reprocesos values('ppp','04/01/2013',0)
insert into reprocesos values('ppp','05/01/2013',0)
insert into reprocesos values('ppp','06/01/2013',0)
insert into reprocesos values('ppp','07/01/2013',0)
insert into reprocesos values('ppp','08/01/2013',0)
insert into reprocesos values('ppp','09/01/2013',0)
insert into reprocesos values('ppp','10/01/2013',0)
insert into reprocesos values('ppp','11/01/2013',0)
insert into reprocesos values('ppp','12/01/2013',0)
insert into reprocesos values('ppp','13/01/2013',0)
insert into reprocesos values('ppp','14/01/2013',0)
insert into reprocesos values('ppp','15/01/2013',0)
insert into reprocesos values('ppp','16/01/2013',0)
insert into reprocesos values('ppp','17/01/2013',0)
insert into reprocesos values('ppp','19/01/2013',0)
insert into reprocesos values('ppp','20/01/2013',0)
insert into reprocesos values('ppp','21/01/2013',0)

insert into reprocesos values('agentes','01/01/2013',0)
insert into reprocesos values('agentes','10/01/2013',0)
insert into reprocesos values('agentes','11/01/2013',0)
insert into reprocesos values('agentes','12/01/2013',0)
insert into reprocesos values('agentes','13/01/2013',0)
insert into reprocesos values('agentes','14/01/2013',0)
insert into reprocesos values('agentes','15/01/2013',0)
insert into reprocesos values('agentes','21/01/2013',0)


insert into reprocesos values('agentes','03/01/2013',0)
insert into reprocesos values('agentes','04/01/2013',0)
insert into reprocesos values('agentes','05/01/2013',0)
insert into reprocesos values('agentes','06/01/2013',0)
insert into reprocesos values('agentes','07/01/2013',0)
insert into reprocesos values('agentes','08/01/2013',0)
insert into reprocesos values('agentes','09/01/2013',0)
insert into reprocesos values('agentes','16/01/2013',0)
insert into reprocesos values('agentes','17/01/2013',0)
insert into reprocesos values('agentes','19/01/2013',0)
insert into reprocesos values('agentes','20/01/2013',0)

insert into reprocesos values('agentes','02/01/2013',0)
insert into reprocesos values('agentes','10/01/2013',0)
insert into reprocesos values('agentes','11/01/2013',0)
insert into reprocesos values('agentes','13/01/2013',0)
insert into reprocesos values('agentes','16/01/2013',0)
insert into reprocesos values('agentes','17/01/2013',0)
insert into reprocesos values('agentes','18/01/2013',0)
insert into reprocesos values('agentes','20/01/2013',0)
insert into reprocesos values('agentes','21/01/2013',0)
insert into reprocesos values('agentes','22/01/2013',0)
insert into reprocesos values('agentes','23/01/2013',0)
insert into reprocesos values('agentes','24/01/2013',0)
insert into reprocesos values('agentes','25/01/2013',0)
insert into reprocesos values('agentes','26/01/2013',0)

insert into reprocesos values('ppp','02/01/2013',0)
insert into reprocesos values('ppp','10/01/2013',0)
insert into reprocesos values('ppp','11/01/2013',0)
insert into reprocesos values('ppp','13/01/2013',0)
insert into reprocesos values('ppp','16/01/2013',0)
insert into reprocesos values('ppp','17/01/2013',0)
insert into reprocesos values('ppp','18/01/2013',0)
insert into reprocesos values('ppp','20/01/2013',0)
insert into reprocesos values('ppp','21/01/2013',0)
insert into reprocesos values('ppp','22/01/2013',0)
insert into reprocesos values('ppp','23/01/2013',0)
insert into reprocesos values('ppp','24/01/2013',0)
insert into reprocesos values('ppp','25/01/2013',0)
insert into reprocesos values('ppp','26/01/2013',0)

select * from reprocesos where bl_procesado = 0

select * from agent_freeze where fecha in 
--select * from agent_day where fecha IN 
('02/01/2013'
,'10/01/2013'
,'11/01/2013'
,'13/01/2013'
,'16/01/2013'
,'17/01/2013'
,'18/01/2013'
,'20/01/2013'
,'21/01/2013'
,'22/01/2013'
,'23/01/2013'
,'24/01/2013'
,'25/01/2013'
,'26/01/2013') and asistente = 'WAYAR KAIRUZ, CESAR MARCELO (ATT976)'

select max(fecha) from agent_day where fecha is null