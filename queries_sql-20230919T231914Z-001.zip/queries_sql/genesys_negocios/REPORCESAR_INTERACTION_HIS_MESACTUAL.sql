insert into interaction_his select 
INTERACTION_ID, FECHA_INICIO, TIPO_INTERACTION, SERVICIO, APLICACION_IVR, ORIGEN, DESTINO, PSEUDOSKILL, ULTIMO_RECURSO, 
                      TERMINADA_EN_COLA, TIPO_RECURSO, POSICION, SITIO, ROL_RECURSO, CORTA_AGENTE, RESULTADO_TECNICO, TIEMPO_TOTAL, TIEMPO_IVR, 
                      TIEMPO_RP, TIEMPO_QUEUE, TIEMPO_AGENTE, ATENCION_TOTAL, ATENCION_AGENTE, ATENCION_CLIENTE, ESPERA_CLIENTE, 
                      GVP_POSTDISCADO, GVP_FIN_LLAMADA, GVP_OPCION_SELECCIONADA, GVP_CATEG_CLIENTE, GVP_ENCUESTA, GVP_TRF_CDN, GVP_COMERCIAL, 
                      GVP_SEGMENTO_ID, GVP_MASIVA, GVP_CARRIER, GVP_UNIDAD_NEGOCIO, GVP_RECLAMO, FECHA_FIN, DATE_KEY_INTERNA, ACTIVA, 
                      GVP_CONSULTA_MQ, GVP_SECTOR_ESTADO, GVP_LLAVE_IPDLA, GVP_AVISO_PAGO, PAD_VANTIVE_CONTACTO, PAD_VANTIVE_USUARIO, CAST(null AS DATETIME) FECHA, 
                      CAST(null AS DATETIME) FECHA_F, NULL LOGIN, CAST(null AS BIT)FCR2, CAST(null AS BIT)FCR7, null ANI, MEDIA_SERVER_IXN_GUID
 from openquery(ge,'select * from contact_unpre.interaction_201205')
DELETE FROM INTERACTION_HIS WHERE FECHA >= DBO.PD(GETDATE())



--CAMPOS AUXILIARES
UPDATE GENESYS..INTERACTION_HIS SET 
login = dbo.usr(ultimo_recurso),
fecha = dbo.f(FECHA_INICIO), 
FECHA_F = dbo.f(FECHA_FIN)
where login is null
go

UPDATE GENESYS..INTERACTION_HIS SET ANI =  replace(origen,'+54','') WHERE ORIGEN  like '+54%' and ani is null
go 

update interaction_his set gvp_categ_cliente = replace(gvp_categ_cliente,'-','') where gvp_categ_cliente like '%-%'
go


--ARREGLO AGENTES QUE CAMBIARON
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'palaciofa','DNS381') WHERE AGENT LIKE '%palaciofa%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'machicadoj','DNS382') WHERE AGENT LIKE '%machicadoj%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'perezjavi','DNS377') WHERE AGENT LIKE '%perezjavi%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'escalantej','DNS373') WHERE AGENT LIKE '%escalantej%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'vannuccig','DNS378') WHERE AGENT LIKE '%vannuccig%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'fernamariae','DNS379') WHERE AGENT LIKE '%fernamariae%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'quintanae','DNS380') WHERE AGENT LIKE '%quintanae%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'ayejesg','DNS375') WHERE AGENT LIKE '%ayejesg%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'marinov','DNS374') WHERE AGENT LIKE '%marinov%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'floresst','DNS376') WHERE AGENT LIKE '%floresst%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'fariasga','DDE068') WHERE AGENT LIKE '%fariasga%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'anselminoe','DDE065') WHERE AGENT LIKE '%anselminoe%'
UPDATE AGENT_DAY SET AGENT = REPLACE(AGENT,'paredesrom','DDE067') WHERE AGENT LIKE '%paredesrom%'

indicadores.master.dbo.xp_sendmail @recipients='cintia.contreras@saberonline.com.ar;federico.ramirez@saberonline.com.ar; Calidad Argentina; sebastian mangisch; Perez Carmen Amelia', @subject='Encuesta de calidad',@message='Les paso el archivo correspondiente a los ultimos 4 dias',@attachments='\\t-negocios\d$\COMPARTIDO\publico\Encuesta Calidad.rar'
select * from grabaciones

select distinct pcrc from roster_cm where name = 'DDE058'
select * from vtv..pendientes where swcaseid = 15477344

select * from vtv..roster_bo where inbox = 'Asist_Cat_BOSQUEC'

select * from roster_cm where pcrc = 'VAG_PCRC_RETENCION_ALTOS'


s sp_verint_neg

  
ALTER PROCEDURE sp_verint_neg  
AS  
  
insert into verint_neg (CID, audio_start_time, duracion, CallID, interaction_id, i.login)  
select v.CID, v.audio_start_time, duracion, v.CallID, i.interaction_id, i.login  
from verint as v  
  inner join interaction_his as i on v.Media_Server collate database_default =i.id_verint collate database_default  
where v.CID not in (select CID from verint_neg)    
  
Delete from verint  
where audio_start_time < dateadd(week,-1,getdate())  
  
select * from roster_cm where name ='RND093'