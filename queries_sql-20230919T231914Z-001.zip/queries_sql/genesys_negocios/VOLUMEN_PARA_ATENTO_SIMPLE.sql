
drop table #t2
drop table #t
Declare @fi SMALLDATETIME  
Declare @ff SMALLDATETIME   
Declare @SEGMENTO VARCHAR(40)                
Declare @Intervalo int  
Set @intervalo= 15    
Set @fi =getdate()-16--'20120401'  
Set @ff =getdate()--'20120522'    
--set @segmento='NEG_cate_monoskill_atento'  
--set @segmento='NEG_Comercial_No_Personalizado'
set @segmento=null


select  
	CASE WHEN p.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE p.pcrc end  pcrc,
	fecha,
	sum(answered)at, 
	sum(answered+abandoned)ofr
	into #t
	from skill_his s inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill and p.atencion in ('tec','com','rete')          
	Where pcrc =isnull(@SEGMENTO,pcrc) and (dbo.f(date_time) between @fi and (@ff+1)) and((entered)<>0)  
	group by CASE WHEN p.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE p.pcrc end,
	fecha


SELECT dbo.tohour(fecha) fecha,  
	CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end pcrc,   
	SUM(TALKTIME+NRR5) TT,
	sum(answered-shortcalls) ans         
    into #t2
	FROM AGENT_HIS A INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME   	
   	Where fecha between @fi and @ff
	GROUP BY dbo.tohour(fecha), 
    CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end  

select t.*, case when ans = 0 then 0 else CAST(tt/ans AS INT) end at 
	from #T t 
		left join #t2 t2 
		on t.pcrc = t2.pcrc and 
		dbo.tohour(t.fecha) = t2.fecha
order by t.pcrc, t.fecha



--ppp DIA ACTUAL
DECLARE @DESDE DATETIME, @HASTA DATETIME
SET @DESDE = dbo.dmy(getdate()) 
SET @HASTA = getdate()
DELETE FROM BRUTA WHERE FECHA between @DESDE and @HASTA
INSERT INTO BRUTA 
SELECT isnull(isnull(s.fecha, a.fecha),w.date) fecha, upper(ISNULL(ISNULL(S.PCRC,A.PCRC),W.PCRC))PCRC, S.OFR, S.AT, S.AB, S.ANS_20, S.ANS_40, S.ABN_20, S.ABN_40,  
A.ANSWERED, A.TT Tiempo_operativo, A.L logueados, a.util, a.ocup, W.[REC_PROY] volumen_proy, [TMO_PROY], e.req_stf Requerido, capa
--INTO BRUTA 
FROM 
(
 select  CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END PCRC,           
   fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40, sum(ABN_20)  ABN_20, sum(ABN_40) ABN_40
 from skill_his s                                   
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
where fecha    between @DESDE and @HASTA AND PCRC IS NOT NULL
 group by CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END , fecha  
)S
FULL JOIN
(
 SELECT A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END pcrc
, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
Else       
100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup,
sum(nrr2+nrr3+nrr7) capa
 FROM AGENT_HIS A     
  INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
 WHERE FECHA  between @DESDE and @HASTA AND PCRC <> ''   
 GROUP BY  A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END 
)A
ON S.PCRC = A.PCRC AND S.FECHA = A.FECHA
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc, * from WFM_LLAMADAS) W 
	ON W.pcrc= s.pcrc AND W.DATE = S.FECHA and w.date < getdate()
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc,* from TRAE_ERLANG) E
	on e.pcrc= W.pcrc and e.date = w.date and e.date < getdate()
where  isnull(isnull(s.fecha, a.fecha),w.date) between @DESDE and @HASTA

DECLARE @DESDE DATETIME, @HASTA DATETIME
SET @DESDE = dbo.dmy(getdate()-61) 
SET @HASTA = dbo.dmy(getdate()) 
EXEC SP_FREEZE_PPP @DESDE, @HASTA

CREATE PROCEDURE SP_FREEZE_PPP (@DESDE DATETIME , @HASTA DATETIME)
AS
--Nueva tabla bruta
--DECLARE @DESDE DATETIME, @HASTA DATETIME
--SET @DESDE = dbo.dmy(getdate()-60) 
--SET @HASTA = dbo.dmy(getdate()+1) 
DELETE FROM BRUTA WHERE FECHA between @DESDE and @HASTA
INSERT INTO BRUTA 
select e.date fecha, upper(e.pcrc), S.OFR, S.AT, S.AB, S.ANS_20, S.ANS_40, S.ABN_20, S.ABN_40,  
A.ANSWERED, A.TT Tiempo_operativo, A.L logueados, a.util, a.ocup, W.[REC_PROY] volumen_proy, [TMO_PROY], e.req_stf Requerido, capa
--INTO BRUTA 
from 
	(select 'VAG_PCRC_'+ segmento pcrc,date, req_stf from TRAE_ERLANG) e

left join 
	(
		SELECT A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END pcrc
		, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
		(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
		Else       
		100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
		(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
		CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup,
		sum(nrr2+nrr3+nrr7) capa
		FROM AGENT_HIS A INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
		WHERE FECHA  between @DESDE and @HASTA AND PCRC <> ''   
		GROUP BY  A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END 
	)a 
	on a.fecha = e.date and a.pcrc = e.pcrc

left join 
	(
		select  
		CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END PCRC,           
		fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40, sum(ABN_20)  ABN_20, sum(ABN_40) ABN_40
		from skill_his s                                   
		inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
		where fecha    between @DESDE and @HASTA AND PCRC IS NOT NULL
		group by CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END , fecha  
	)s
	on s.fecha = e.date and s.pcrc = e.pcrc

left JOIN 
	(select 'VAG_PCRC_'+ segmento pcrc, * from WFM_LLAMADAS where date between @desde and @hasta) W 
	on W.pcrc= s.pcrc AND W.DATE = S.FECHA  
where e.date between @desde and getdate()
and (e.pcrc NOT like '%mcd%' AND e.pcrc like '%atto%')
UNION ALL
select e.date fecha, upper(e.pcrc), S.OFR, S.AT, S.AB, S.ANS_20, S.ANS_40, S.ABN_20, S.ABN_40,  
A.ANSWERED, A.TT Tiempo_operativo, A.L logueados, a.util, a.ocup, W.[REC_PROY] volumen_proy, [TMO_PROY], e.req_stf Requerido, capa
--INTO BRUTA 
from 
	(select 'VAG_PCRC_'+ segmento pcrc,date, req_stf from TRAE_ERLANG) e

left join 
	(
		SELECT A.FECHA, 
		CASE	WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' 
				when vag like '%atento%'	and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_atto' 
				when vag like '%mercedes%'	and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_mcd' 
		ELSE pcrc END pcrc
		, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
		(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
		Else       
		100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
		(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
		CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup,
		sum(nrr2+nrr3+nrr7) capa
		FROM AGENT_HIS A INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
		WHERE FECHA  between @DESDE and @HASTA AND PCRC <> ''   
		GROUP BY  A.FECHA, 
		CASE	WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' 
				when vag like '%atento%'	and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_atto' 
				when vag like '%mercedes%'	and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_mcd' 
		ELSE pcrc END
	)a 
	on a.fecha = e.date and a.pcrc = e.pcrc

left join 
	(
		select  
		CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END PCRC,           
		fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40, sum(ABN_20)  ABN_20, sum(ABN_40) ABN_40
		from skill_his s                                   
		inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
		where fecha    between @DESDE and @HASTA AND PCRC IS NOT NULL
		group by CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END , fecha  
	)s
	on s.fecha = e.date and s.pcrc = e.pcrc
and (e.pcrc like '%pcrc%' or e.pcrc like '%attp%')

left JOIN 
	(select 'VAG_PCRC_'+ segmento pcrc, * from WFM_LLAMADAS where date between @desde and @hasta) W 
	on W.pcrc= s.pcrc AND W.DATE = S.FECHA  
where e.date between @desde and getdate()
and (e.pcrc like '%mcd%' or e.pcrc like '%atto%')


--ADAPTAZAO ARCHIVOS

insert into wfm_llamadas
SELECT PCRC, round(replace([Vol Proy CP],',','.'),0), round(replace([TMO Proy CP],',','.'),0),
CAST(REPLACE(LEFT(FECHA,10),'-','')+ ' ' + SUBSTRING(INTERVALO,12,5) AS DATETIME)
FROM ['Volumen CP Junio$']

delete from trae_erlang where date >= '01/06/2012'
INSERT INTO TRAE_ERLANG (segmento, date, hora, req_stf)
SELECT pcrc, convert(varchar(10),fecha,112)+ ' ' + convert(varchar(10),intervalo,114), left(convert(varchar(10),intervalo,114),5) , round(replace(REQ,',','.'),2) 
FROM [REQ_Junio]


SELECT * FROM BRUTA WHERE FECHA >= '11/06/2012'
select distinct segmento from trae_erlang where date >= '01/06/2012'

delete from trae_erlang where date >= '01/06/2012' and datepart(hour,date) >=19 and req_STF = 0 
--and datepart(hour,date) >14
and segmento like '%retencion%'



select * from bruta where fecha = '20120611 13:30:00' and segmento like '%comercial_altos%'
select * from agent_his a inner join roster_cm r on a.login = r.name 
where fecha = '2012-06-11 10:45:00' and pcrc = 'VAG_PCRC_COMERCIAL_ALTOS'

S SP_GET_COMBO_PCRC

  
ALTER PROCEDURE sp_get_combo_pcrc    
as    
select distinct 'VAG_PCRC_' + SEGMENTO PCRC from TRAE_ERLANG WHERE DATE >= DBO.PD(GETDATE()-60) AND SEGMENTO NOT LIKE 'NEG%'
ORDER BY 'VAG_PCRC_' + SEGMENTO 

s sp_adh_control

--Nueva tabla bruta
DECLARE @DESDE DATETIME, @HASTA DATETIME
SET @DESDE = dbo.dmy(getdate()-61) 
SET @HASTA = getdate()+1
EXEC SP_FREEZE_PPP @DESDE, @HASTA

s sp_adh

ALTER PROCEDURE sp_adh_control (@pcrc varchar(100), @intervalo smalldatetime)          
as          
 select  A.FECHA, AGENT, LOGINTIME, NOTREADYTIME-NRR4-NRR5 [nr SIN NRR4,NRR5],R.SUP, R.VAG, R.SUP, R.PCRC          
 from agent_his a                                   
  left join roster_cm r on a.login = r.name                              
 where fecha = @intervalo and  CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS'   
    when vag like '%atento%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_atto'   
    when vag like '%mercedes%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_mcd'
	when R.PCRC in ('VAG_PCRC_TECNICO_MONOSKILL','VAG_PCRC_TECNICO_MULTISKILL') AND @PCRC = 'VAG_PCRC_TECNICO_TOTAL' THEN 'VAG_PCRC_TECNICO_TOTAL' 
  ELSE pcrc END= @pcrc           
order by r.sup 


exec genesys..SP_ADH_CONTROL 'VAG_PCRC_TECNICO_TOTAL','20120612 16:30:00:0'

DECLARE @pcrc varchar(100)
SET @PCRC = 'VAG_PCRC_TECNICO_TOTAL'
SELECT DISTINCT 
CASE --WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS'   
    when vag like '%atento%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_atto'   
    when vag like '%mercedes%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_mcd'
	when vag in ('VAG_PCRC_TECNICO_MONOSKILL','VAG_PCRC_TECNICO_MULTISKILL') AND @PCRC = 'VAG_PCRC_TECNICO_TOTAL' THEN 'VAG_PCRC_TECNICO_TOTAL' 
  ELSE pcrc END
 from  roster_cm r
WHERE 
CASE --WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS'   
    when vag like '%atento%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_atto'   
    when vag like '%mercedes%' and r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' then 'VAG_PCRC_COMERCIAL_ALTOS_mcd'
	when vag in ('VAG_PCRC_TECNICO_MONOSKILL','VAG_PCRC_TECNICO_MULTISKILL') AND @PCRC = 'VAG_PCRC_TECNICO_TOTAL' THEN 'VAG_PCRC_TECNICO_TOTAL' 
  ELSE pcrc END = @PCRC


select * from aprobacion





SELECT      i.SWOBJECTID , i.SWDATERECEIVED , i.SWRECEIVER , i.SWACTIONTAKEN , 
                      i.SWDATEACTIONTAKEN , u.SWUSER
FROM         VTV.dbo.inbox AS i INNER JOIN
                      VTV.dbo.SW_USER AS u ON i.SWRECEIVER = u.SWDEFAULTINBOX
where swobjectid in (select swcaseid from [10.105.220.49].vantive_une_data.dbo.puntualidad)



select * from [10.105.220.49].vantive_une_data.dbo.puntualidad
where swcaseid ='15108891'


select *
from VTV.dbo.casos 
where swcaseid ='15108891'