drop table #i
select * into #i from OPENROWSET('MSDASQL','DSN=ICCM_PREVIEW_DSN;UID=mangischs;PWD=palangana05',
'select * from iApplicationStat where Timestamp > ''2011-05-18''') 
/*
select application, sum(callsoffered),sum(callsanswered), sum(1) from #i where application in ('M10_Indebidas_OP_1', 'M7_Nuevos_Productos', 'M7_PDTI', 'M7_Sucursal_OnLine', 'sc_Ccard_Pyme', 'M2_NuevosNYP','M2_Competencia_Calculo','M2_Masivos_Calculo','M2_Masivos')
group by application
*/
select left(grupo,15) as grupo,sum(callsanswered) + sum(callsabandoned) as ofr        
	,sum(callsanswered) as atend,sum(callsabandoned) as aband        
	,100*(case sum(callsanswered) + sum(callsabandoned) when '0' then '0' else        
	(convert(decimal(10,2),1-(sum(callsanswered)/cast((sum(callsanswered) + sum(callsabandoned))         
	as decimal (10,2)))))end) as [%Aband],100*(case sum(callsanswered) + sum(callsabandoned)         
	when '0' then '0' else convert(decimal(10,2), ((sum(callsanswered)-sum(callsansweredaftthreshold))/cast((sum(callsanswered)        
	 + sum(callsabandoned)) as decimal(10,2))) ) end)as [%SL]        
from #i as i         
	inner join indicadores.symposium.dbo.campa�a_apli as c on c.aplicationid=i.applicationid        
	where grupo in('alto riesgo','alto valor','carterizado','competencia','masivo','satisfaccion','tempresas','unm')        
	group by grupo with rollup

select left(grupo,15) as grupo,sum(callsanswered) + sum(callsabandoned) as ofr        
	,sum(callsanswered) as atend,sum(callsabandoned) as aband        
	,100*(case sum(callsanswered) + sum(callsabandoned) when '0' then '0' else        
	(convert(decimal(10,2),1-(sum(callsanswered)/cast((sum(callsanswered) + sum(callsabandoned))         
	as decimal (10,2)))))end) as [%Aband],100*(case sum(callsanswered) + sum(callsabandoned)         
	when '0' then '0' else convert(decimal(10,2), ((sum(callsanswered)-sum(callsansweredaftthreshold))/cast((sum(callsanswered)        
	 + sum(callsabandoned)) as decimal(10,2))) ) end)as [%SL]        
from #i as i         
	inner join indicadores.symposium.dbo.campa�a_apli as c on c.aplicationid=i.applicationid        
	where grupo in('tecnico')        
	group by grupo with rollup

select getdate()


select max(timestamp) from #i



sp_helptext sp_mails_eficiencia