select * into tempdb..canal_ingreso from openquery(d,'
SELECT	cctcaseid,CCTTIPOLLAMADA
from	SWBAPPS.CCT_INSTANCIA I,SWBAPPS.CCT_CONTACTO C
where	I.CCTCONTACTOID = C.CCTCONTACTOID
and		i.cctcontactoid >=21788909.00000')