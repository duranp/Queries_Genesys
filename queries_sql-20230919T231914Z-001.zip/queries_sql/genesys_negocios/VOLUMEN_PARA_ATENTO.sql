Declare @fi SMALLDATETIME  
Declare @ff SMALLDATETIME   
Declare @SEGMENTO VARCHAR(40)                
Declare @Intervalo int  
Set @intervalo= 15    
Set @fi =getdate()-15--'20120401'  
Set @ff =getdate()--'20120522'    
--set @segmento='NEG_cate_monoskill_atento'  
--set @segmento='NEG_Comercial_No_Personalizado'
set @segmento=null

--drop table #t
select     
	x.Atencion,  
	convert(datetime,(cast(x.anio as varchar)+'/'   
    +cast(x.mes as varchar)+'/'  
    + cast(x.dia as varchar)+' '  
    + cast(x.hora as varchar)+':'  
    + cast(x.minuto as varchar)),121) Fecha,  
	(OFR)Ofr,   
	(AT)At,   
	(AB)Ab,   
	(REC_PROY)Rec_Proy,     
	(case when rec_proy = 0 then 0 else cast(((ofr/rec_proy)-1)*100 as Decimal(6,2)) end) as GAP,         
	(case when ofr = 0 then 0 else cast(ab/ofr*100 as numeric(6,2)) end) as TA,    
	((case at when '0' then '0' else CAST((CASE WHEN SL = 20 THEN ANS_20 ELSE ANS_40 END)/at*100 AS DECIMAL(6,2)) end) )as SL,   
	tt,ans,   
	(TMO_PROY)TMO_PROY,        
	(case when W.TMO_PROY = 0 then 0 else cast((((tt/ans)*1.0/W.TMO_PROY*100.0)-100) as Decimal(6,2)) end) as GAP_TMO    
	into #t
from( 
	select	Atencion,  --agregado
			anio,
			mes,
			dia,
			hora,
			minuto,
			sum(h.ofr)ofr,
			sum(h.at)at,
			sum(h.ab)ab,
			sum(h.ans_20)ans_20,
			sum(h.ans_40)ans_40,
			sum(h.sl)sl 
	from 


		(select  
		CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,dbo.f(date_time)) < 9 OR DATEPART(HOUR,dbo.f(date_time)) >=16) 
		THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE  
		
			case when pseudoskill in(	'Averias_Transf_cliente_TOP',
												'Averias_DATOS-PRESTADORES_top',
												'Averias_DATOS-TOP',
												'Averias_PDTI-VOIP_TOP',
												'Averias_SPEEDYTOP',
												'Averias_VOZ_TOP')  
			then replace (pcrc,'VAG_PCRC_TECNICO_MONOSKILL','NEG_CATE_TOP') else
						
				case when pseudoskill in('Averias_PDTI-VOIP_TOP_sp')  
				then replace (pcrc,'VAG_PCRC_TECNICO_MONOSKILL','NEG_CATE_TOP') else

					case when pseudoskill in('Averias_REITERADO_SPEEDY')  
					then replace (pcrc,'VAG_PCRC_TECNICO_MONOSKILL','NEG_CATE_TOP_1') else --esto tengo que sumar 30 a top y 70 a mono
													
						case when pseudoskill in('Averias_REITERADO_SPEEDY_Masivo')  
						then replace (pcrc,'VAG_PCRC_TECNICO_MONOSKILL','NEG_CATE_TOP_2') else --esto tengo que sumar 30 a top y 70 a mono
															

		pcrc end end end end end  Atencion,
		--pcrc end end Atencion,  
		--select  pcrc Atencion,  
		datepart(year,dbo.f(date_time)) anio,  
		datepart(month,dbo.f(date_time)) mes,  
		datepart(day,dbo.f(date_time)) dia,  
		datepart(hour,dbo.f(date_time)) hora,  
		(datepart(minute,dbo.f(date_time)) /  @intervalo* @intervalo)minuto,  
		sum(entered)ofr,   
		sum(answered)at,   
		sum(abandoned)ab ,   
		sum(ans_20)  ans_20,  
		sum(ans_40) ans_40,  
		sum(sl) as sl               
	  
		from skill_his s inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill           
	  
		Where pcrc =isnull(@SEGMENTO,pcrc) and (dbo.f(date_time) between @fi and (@ff+1)) and((entered)<>0)  
	  
		group by pcrc,pseudoskill,      
		datepart(year,dbo.f(date_time)) ,  
		datepart(month,dbo.f(date_time)) ,  
		datepart(day,dbo.f(date_time)) ,  
		datepart(hour,dbo.f(date_time)) ,  
		(datepart(minute,dbo.f(date_time)) /  @intervalo* @intervalo)  
		) h
	group by Atencion,anio,mes,dia,hora,minuto
	)x  
  
	left join  
  
	(select SEGMENTO ATENCION,    
	datepart(year,(date)) anio,  
	datepart(month,(date)) mes,  
	datepart(day,(date)) dia,  
	datepart(hour,(date)) hora,  
	(datepart(minute,(date)) /  @intervalo* @intervalo)minuto,  
--	SUM(e.rec_proy) REC_PROY,   
	sum(e.rec_proy) REC_PROY,   
	AVG(e.tmo_proy) TMO_PROY  
  
	from (Select * from WFM_LLAMADAS group by segmento,rec_proy,tmo_proy,date) e        
	Where	segmento =isnull(@SEGMENTO,segmento)   
 			and e.tmo_proy > 0 -- para que no incluya los reg en cero en el promedio   
	GROUP BY SEGMENTO,   
	datepart(year,(date)) ,  
	datepart(month,(date)) ,  
	datepart(day,(date)) ,  
	datepart(hour,(date)) ,  
	(datepart(minute,(date)) /  @intervalo* @intervalo)     
	)w   
	on x.anio = W.anio  and x.mes = W.mes   
	and x.dia = W.dia and x.hora = W.hora   
	and x.minuto = W.minuto and x.atencion = W.atencion                
   
	left join    
   
	(SELECT datepart(year,A.FECHA ) anio,  
	datepart(month,A.FECHA ) mes,  
	datepart(day,A.FECHA ) dia,  
	datepart(hour,A.FECHA ) hora,  
	(datepart(minute,A.FECHA ) /  @intervalo* @intervalo)minuto,  
		CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) 
		THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end atencion,   
	SUM(TALKTIME+NRR5) TT,
sum(answered-shortcalls) ans         
   
	FROM AGENT_HIS A INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME   	
   
	Where CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) 
		THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end =isnull(@SEGMENTO,
				CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) 
				THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end )   
  
	GROUP BY datepart(year,A.FECHA ) ,   
    datepart(month,A.FECHA ) ,   
    datepart(day,A.FECHA ) ,  
    datepart(hour,A.FECHA ) ,  
    (datepart(minute,A.FECHA ) /  @intervalo* @intervalo),     
    CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end  
	) ag        
	on x.anio = ag.anio and x.mes = ag.mes and  
	x.dia = ag.dia and x.hora = ag.hora and   
	x.minuto = ag.minuto and x.atencion = ag.atencion     
  
order by x.atencion,  
x.anio,  
x.mes,   
x.dia,  
x.hora,  
x.minuto  

select * from #t

--agrego volumen al top
select t1.atencion, t1.fecha, t1.at + (t2.at* 0.7) + t1.ab + (t2.ab*0.7) ofr, t1.at + (t2.at* 0.7) at, t1.ab + (t2.ab*0.7) ab, rec_proy, gap, ta, sl,  tmo, tmo_proy, gap_tmo
from #t t1 left join 
	(select atencion, fecha, sum(ofr)ofr, sum(at)at, sum(ab)ab from #t where  atencion in ('NEG_CATE_TOP_1','NEG_CATE_TOP_2') group by atencion,fecha) t2 
on t1.fecha = t2.fecha
where t1.atencion = 'NEG_CATE_Multiskill'

union all
select t1.atencion, t1.fecha, t1.at + (t2.at* 0.3) + t1.ab + (t2.ab*0.3) ofr, t1.at + (t2.at* 0.3) at, t1.ab + (t2.ab*0.3) ab, rec_proy, gap, ta, sl,  tmo, tmo_proy, gap_tmo
from #t t1 left join 
	(select atencion, fecha, sum(ofr)ofr, sum(at)at, sum(ab)ab from #t where  atencion in ('NEG_CATE_TOP_1','NEG_CATE_TOP_2') group by atencion,fecha) t2 
on t1.fecha = t2.fecha
where t1.atencion = 'NEG_CATE_TOP'
union all 
select * from #t where atencion not in ('NEG_CATE_TOP','NEG_CATE_TOP_1','NEG_CATE_TOP_2','NEG_CATE_Multiskill')
select day(fecha), datepart(hour,fecha),* from #t
 and se
select * from trae_erlang where date > '01/06/2012' and segmento like '%NEG_Comercial_Pers_Atento%'
order by date


--base definitiva freezada final!

--DIA ACTUAL
--drop table bruta
select * from bruta


DECLARE @DESDE DATETIME, @HASTA DATETIME
SET @DESDE = dbo.dmy(getdate()-60) 
SET @HASTA = getdate()
DELETE FROM BRUTA WHERE FECHA between @DESDE and @HASTA
INSERT INTO BRUTA 
SELECT isnull(isnull(s.fecha, a.fecha),w.date) fecha, upper(ISNULL(ISNULL(S.PCRC,A.PCRC),W.PCRC))PCRC, S.OFR, S.AT, S.AB, S.ANS_20, S.ANS_40, S.ABN_20, S.ABN_40,  
A.ANSWERED, A.TT Tiempo_operativo, A.L logueados, a.util, a.ocup, W.[REC_PROY] volumen_proy, [TMO_PROY], e.req_stf Requerido
--INTO BRUTA 
FROM 
(
 select  CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END PCRC,           
   fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40, sum(ABN_20)  ABN_20, sum(ABN_40) ABN_40
 from skill_his s                                   
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
where fecha    between @DESDE and @HASTA AND PCRC IS NOT NULL
 group by CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END , fecha  
)S
FULL JOIN
(
 SELECT A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END pcrc
, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
Else       
100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup,
sum(nrr2+nrr3+nrr7) capa
 FROM AGENT_HIS A     
  INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
 WHERE FECHA  between @DESDE and @HASTA AND PCRC <> ''   
 GROUP BY  A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END 
)A
ON S.PCRC = A.PCRC AND S.FECHA = A.FECHA
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc, * from WFM_LLAMADAS) W 
	ON W.pcrc= s.pcrc AND W.DATE = S.FECHA and w.date < getdate()
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc,* from TRAE_ERLANG) E
	on e.pcrc= W.pcrc and e.date = w.date and e.date < getdate()
where  isnull(isnull(s.fecha, a.fecha),w.date) between @DESDE and @HASTA


select
SELECT 0/700
--adapto datos a proyectado --


--IMPORTANTE IMPORTAR ARCHIVOS DIRECTAMENTE DEL TXT 
insert into wfm_llamadas
SELECT PCRC, round(replace([Vol Proy CP],',','.'),0), round(replace([TMO Proy CP],',','.'),0),
CAST(REPLACE(LEFT(FECHA,10),'-','')+ ' ' + SUBSTRING(INTERVALO,12,5) AS DATETIME)
FROM ['Volumen CP Junio$']

delete from trae_erlang where date between dbo.dmy(getdate()) and getdate()
INSERT INTO TRAE_ERLANG (segmento, date, hora, req_stf)
SELECT pcrc, convert(varchar(10),fecha,112)+ ' ' + convert(varchar(10),intervalo,114), left(convert(varchar(10),intervalo,114),5) , round(replace(REQ,',','.'),2) 
FROM [REQUERIDO CP Junio]

select * 

select * from wfm_llamadas where date >= '01/06/2012'
insert into wfm_llamadas
select 
pcrc, round(replace([vol proy cp],',','.'),2), round(replace([tmo proy cp],',','.'),2), convert(varchar(10),fecha,112)+ ' ' + right(convert(varchar(16),intervalo,114),5)
from tempdb..vol_junio_2012

delete
from wfm_llamadas
where (datepart(hour,date) < 9 
or datepart(hour,date) > 19)
and datepart(weekday,date) in (1,2,3,4,5)
and convert(varchar(10),date,112) <> '20/06/2012'
and round(replace([rec_proy],',','.'),2)= 0
and (segmento like '%comercial%' or segmento like '%rete%')

select case when right(cast(intervalo as varchar(16)),5) ,* from tempdb..vol_junio_2012 where intervalo like '%p.m%'
drop table tempdb..vol_junio_2012
select * from trae_erlang where dbo.dmy(date) = '25/06/2012' and segmento= 'retencion_in_altos'


delete from trae_erlang where date >= '01/06/2012'
select convert(varchar(10),getdate(),112)
select convert(varchar(10),intervalo,114),* from ['REQUERIDO CP Junio$']
delete from trae_erlang

select distinct segmento from trae_erlang where date >= '01/06/2012'

delete from wfm_llamadas where date >= '01/06/2012' and datepart(weekday,date) in (6) 
--and req_stf =0 
and datepart(hour,date) >14
and segmento like '%comercial%'


select cast(cast(cast('01/01/2012 10:29' as datetime) as float)*15/15 as datetime)
s sp_adh
--CONTROLES
 SELECT distinct login
into #t
 FROM AGENT_HIS A     
  INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
 WHERE FECHA  = '06/06/2012 09:15'AND PCRC = 'VAG_PCRC_COMERCIAL_ALTOS'   
 GROUP BY  A.FECHA, R.pcrc  

select * from interaction_det 
where dbo.usr(nombre_recurso) in (select login from #t)
and dbo.f(fecha_inicio) between  '06/06/2012 09:15' and  '06/06/2012 09:30'
and pseudoskill not like 'Comercial_Alto_Riesgo'


select ''''+login + ''',' from #t
 select  *
 from skill_his s                                   
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
where    FECHA  = '06/06/2012 09:15'AND PCRC = 'VAG_PCRC_COMERCIAL_ALTOS'   




--DIA ACTUAL

DECLARE @DESDE DATETIME, @HASTA DATETIME
SET @DESDE = dbo.dmy(getdate()) 
SET @HASTA = getdate()
DELETE FROM BRUTA WHERE FECHA between @DESDE and @HASTA
INSERT INTO BRUTA 
SELECT isnull(isnull(s.fecha, a.fecha),w.date) fecha, upper(ISNULL(ISNULL(S.PCRC,A.PCRC),W.PCRC))PCRC, S.OFR, S.AT, S.AB, S.ANS_20, S.ANS_40, S.ABN_20, S.ABN_40,  
A.ANSWERED, A.TT , A.L, a.util, a.ocup, W.[REC_PROY], [TMO_PROY], e.req_stf
--INTO BRUTA 
FROM 
(
 select  CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END PCRC,           
   fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40, sum(ABN_20)  ABN_20, sum(ABN_40) ABN_40
 from skill_his s                                   
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
where fecha    between @DESDE and @HASTA AND PCRC IS NOT NULL
 group by CASE WHEN pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END , fecha  
)S
FULL JOIN
(
 SELECT A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END pcrc
, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
Else       
100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup
 FROM AGENT_HIS A     
  INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
 WHERE FECHA  between @DESDE and @HASTA AND PCRC <> ''   
 GROUP BY  A.FECHA, CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' AND (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE PCRC END 
)A
ON S.PCRC = A.PCRC AND S.FECHA = A.FECHA
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc, * from WFM_LLAMADAS) W 
	ON W.pcrc= s.pcrc AND W.DATE = S.FECHA and w.date < getdate()
FULL JOIN (select 'VAG_PCRC_'+ segmento pcrc,* from TRAE_ERLANG) E
	on e.pcrc= W.pcrc and e.date = w.date and e.date < getdate()
where  isnull(isnull(s.fecha, a.fecha),w.date) between @DESDE and @HASTA

update pseudoskill set pcrc = 'VAG_PCRC_TECNICO_TOP' where pseudoskill like '%top%' and atencion = 'tec'


create table aprobacion (date datetime, pcrc varchar(50), dif_aprobada bit, obs_aprobacion varchar(500))

SELECT MAX(DATE_TIME) FROM AGENT_HIS


sp_rename 'sp_adh','sp_adh_old'

sp_helptext sp_adh_old

  
alter PROCEDURE [dbo].[sp_adh] (@segmento as varchar(100), @fi as smalldatetime, @ff as smalldatetime) 
as        
SELECT     fecha, UCASE(PCRC) PCRC, OFR, AT, AB, ANS_20, ANS_40, ANSWERED, TT, L, util, ocup, REC_PROY, TMO_PROY, req_stf
FROM         BRUTA
where isnull(@segmento,pcrc) = pcrc and dbo.dmy(fecha) between @fi and @ff
and pcrc not in ('back_NEG_CATE_Multiskill','posventa')
order by pcrc,fecha


[sp_adh] null,'01/06/2012','01/06/2012'

s sp_get_combo_pcrc

ALTER PROCEDURE sp_get_combo_pcrc  
as  
select distinct pcrc from roster_cm where pcrc <> ''





--CONTROL
	--LAMADAS
 select  pcrc,           
   fecha, sum(entered)ofr, sum(answered)at, sum(abandoned)ab , sum(ans_20)  ans_20, sum(ans_40) ans_40--, sum(AB_20)  AB_20, sum(AB_40) AB_40
 from skill_his s                                   
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill       
where fecha    between dbo.dmy(getdate()) and getdate() AND PCRC IS NOT NULL and  PCRC = 'VAG_PCRC_Comercial_Altos'
 group by pcrc, fecha  


	--AGENTES
 SELECT A.FECHA, R.pcrc, SUM(TALKTIME+NRR5)TT, SUM(ANSWERED-SHORTCALLS) ANSWERED, cast((sum(logintime)-(sum(notreadytime)-sum(nrr4)-sum(nrr5))) / 900 as decimal(8,2))as L,
(Case sum(talktime)+ sum(readytime) + SUM(isnull(nrr5,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) when '0' Then '0'      
Else       
100* convert(decimal(12,2),(sum(talktime)+ sum(isnull(nrr5,0))+ sum(readytime)) /cast(sum(talktime)+ sum(readytime) + SUM(isnull(nrr0,0)) + SUM(isnull(nrr1,0))+ SUM(isnull(nrr2,0))+ SUM(isnull(nrr3,0))+ SUM(isnull(nrr5,0)) + SUM(isnull(nrr6,0))+ SUM(isnull(nrr7,0))+ SUM(isnull(nrr8,0)) as decimal(12,2)))end) Util,
(CASE SUM(TALKTIME)+SUM(nrr5)+sum(readytime) WHEN '0' THEN '0' ELSE      
CAST(100*((SUM (talktime)+sum(isnull(nrr5,0)))/ CAST(SUM(ISNULL(nrr5,0))+sum(talktime)+sum(readytime)AS DECIMAL(12,2) ))AS DECIMAL(12,2))END) Ocup
 FROM AGENT_HIS A     
  INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME  
 WHERE FECHA  = '07/06/2012 08:00:00' AND PCRC IS NOT NULL and  PCRC = 'VAG_PCRC_RETENCION_IN_ALTOS'
 GROUP BY  A.FECHA, R.pcrc  



s sp_adh_resumen_freeze


  select * from skill_his where dbo.dmy(fecha) = dbo.dmy(getdate())
  
  select max(timestamp) from stats_online


select max(fecha) from bruta

SELECT 


select MAX(LEN(swemailaddress))
from vtv..contacto c 
	inner join dw..parque p on c.tasa_clie_codigo = p.cd_party_titular
where ani = (select top 1 ani from dw..parque where cd_party_titular = p.cd_party_titular)




drop table #t2
drop table #t
Declare @fi SMALLDATETIME  
Declare @ff SMALLDATETIME   
Declare @SEGMENTO VARCHAR(40)                
Declare @Intervalo int  
Set @intervalo= 15    
Set @fi =getdate()-15--'20120401'  
Set @ff =getdate()--'20120522'    
--set @segmento='NEG_cate_monoskill_atento'  
--set @segmento='NEG_Comercial_No_Personalizado'
set @segmento=null


select  
	CASE WHEN p.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE p.pcrc end  pcrc,
	fecha,
	sum(answered)at, 
	sum(answered+abandoned)ofr
	into #t
	from skill_his s inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill and p.atencion in ('tec','com','rete')          
	Where pcrc =isnull(@SEGMENTO,pcrc) and (dbo.f(date_time) between @fi and (@ff+1)) and((entered)<>0)  
	group by CASE WHEN p.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE p.pcrc end,
	fecha


SELECT dbo.tohour(fecha) fecha,  
	CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end pcrc,   
	SUM(TALKTIME+NRR5) TT,
	sum(answered-shortcalls) ans         
    into #t2
	FROM AGENT_HIS A INNER JOIN ROSTER_CM R ON A.LOGIN = R.NAME   	
   	Where fecha between @fi and @ff
	GROUP BY dbo.tohour(fecha), 
    CASE WHEN r.pcrc = 'VAG_PCRC_COMERCIAL_ALTOS' and (DATEPART(HOUR,FECHA) < 9 OR DATEPART(HOUR,FECHA) >=16) THEN 'VAG_PCRC_COMERCIAL_MASIVOS' ELSE r.pcrc end  

select --distinct t.pcrc --
t.*, case when ans = 0 then 0 else tt/ans end at 
	from #T t 
		left join #t2 t2 
		on t.pcrc = t2.pcrc and 
		dbo.tohour(t.fecha) = t2.fecha

select * from pseudoskill where pcrc = 'back_NEG_CATE_Multiskill'


insert into vitacora_cambios values(getdate(),'Novedades: Haciendo click en la marquesina se visualiza el detalle en forma ordenada de las incidencias.')

select distinct dbo.dmy(fecha) from bruta
where pcrc = 'VAG_PCRC_COMERCIAL_MASIVOS'
 order by dbo.dmy(fecha) 
select * from aprobacion


select * from bruta where fecha = '20120621 13:45:00.000'
s pd
datepart(hour, '01/01/2012 6:29')+case when datepart(minute,'01/01/2012 6:29')/30*30 = 30 then 0.5 else 0 end

alter function date_tofloat (@date smalldatetime)    
returns float as    
begin    
 return datepart(hour, @date)+datepart(minute,@date)/30*30 / 60.0
end

select datepart(minute,'01/01/2012 6:29')/30*30/6
select dbo.date_tofloat()



select p.*,dbo.date_tofloat(fecha) ,  b.* 
from bruta b 
	left join pcrc p 
		on b.pcrc = p.pcrc and 
		dbo.date_tofloat(fecha) 
		between 
			CASE when DATEPART(WEEkDAY,FECHA) = 6 then s_desde when DATEPART(WEEkDAY,FECHA) = 7 then d_desde else desde end			
		and 
			CASE when DATEPART(WEEkDAY,FECHA) = 6 then s_hasta when DATEPART(WEEkDAY,FECHA) = 7 then d_hasta else hasta end -0.5
where dbo.dmy(fecha) >= '01/06/2012' --and b.pcrc like '%comercial%'
order by b.pcrc, b.fecha


select * from sysobjects where name like '%llam%'

s SP_GET_LLAMADAS_PROY_Modif_new

select * from sysobjects where xtype = 'u'

select * from agrup_responsabilidades
