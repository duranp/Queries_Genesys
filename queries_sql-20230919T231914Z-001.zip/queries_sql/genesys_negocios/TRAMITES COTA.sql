

select month(swdateresolved),sup, sum(case when datediff(hour,swdatecreated, swdateactiontaken) <=48 then 1 else 0 end),
sum(case when datediff(hour,swdatecreated, swdateactiontaken) <=48 then 1 else 0 end)*1.0/sum(1)
,avg(datediff(hour,swdatecreated, swdateactiontaken)), sum(1)
from casos c 
	inner join roster_bo r on c.cctcerradopor = r.cota  
	inner join inbox i     on c.swcaseid = i.swobjectid
		and swactiontaken = 'gestionado'
		and swdateactiontaken = (select min(swdateactiontaken) from inbox where swactiontaken = 'gestionado' and swobjectid = i.swobjectid)
	and swdatecreated >= '01/01/2011'
	
where sup in ('blanco','pernice')
group by month(swdateresolved),sup
	
sp_helptext sp_pendientes

select max(swdatereceived) from inbox
drop table tramites
select * into tramites from openquery(dw,'select p.tx_producto, p2.tx_producto tx_producto_es, e.tx_nombre, e.tx_apellido,t.fc_emision, t.fc_cumplimiento, t.cd_estado_tramite, tt.tx_tipo_tramite, t.cd_pedido_cliente, t.cd_sub_pedido, t.cd_tramite
from
        tasa.sub_pedido s
        inner join tasa.tramites t
                on s.cd_pedido_cliente = t.cd_pedido_cliente
                and s.cd_sub_pedido = t.cd_sub_pedido
        inner join tasa.party_tipo_cliente tc on t.cd_tipo_cliente = tc.cd_tipo_cliente and cd_unidad_negocio = ''pym''
        inner join tasa.party e on t.cd_party_empleado = e.cd_party
        inner join tasa.tipo_tramite tt on t.cd_tipo_tramite = tt.cd_tipo_tramite
        inner join tasa.producto p on t.cd_producto = p.cd_producto
        inner join tasa.producto p2 on t.cd_producto_es = p2.cd_producto
where
t.fc_emision >= ''01/03/2011''')


select month(fc_emision), sum(1) from tramites where tx_apellido + ' ' + tx_nombre in (select nombres from roster_bo where sup in  ('blanco','pernice'))
group by month(fc_emision)

select tx_tipo_tramite, tx_producto_es, sum(1) from tramites where tx_apellido + ' ' + tx_nombre in (select nombres from roster_bo where sup in  ('blanco','pernice'))
group by tx_tipo_tramite, tx_producto_es
order by sum(1) desc

select nombres from roster_bo where sup in  ('blanco','pernice') and nombres not in (select tx_apellido + ' ' + tx_nombre from tramites)

select distinct tx_apellido, tx_nombre from tramites where tx_apellido like '%suner%'

select * from roster_bo where nombres like '%su�er%'
update roster_bo set nombres = 'Suner Gabriel Roberto' where nombres ='Su�er Gabriel'

select sum(1), tx_producto_es FROM TRAMITES
where tx_producto_es in (select tx_producto_es from tramites where tx_apellido + ' ' + tx_nombre in (select nombres from roster_bo where sup in  ('blanco','pernice')))
and tx_apellido not like 'BATCH%' and tx_apellido <> 'INTERACCION GPYM-COT'
GROUP BY tx_producto_es
order by sum(1) desc

select tx_apellido, sum(1) from tramites where tx_apellido not like 'BATCH%'
group by tx_apellido order by sum(1) desc

select sum(1), tx_producto_es from tramites
group by tx_producto_es
order by sum(1) desc

select tx_tipo_tramite, tx_producto_es, 
sum(case when sup is null and asistente is null and tx_apellido + ' ' + tx_nombre not in ('perez carmen','debuono fabiana marisel','ignatti mauro','martin nicolas botta','vivardo miguel angel') then 1 else 0 end)otros , 
sum(case when sup is not null then 1 else 0 end)bo , 
sum(case when tx_apellido + ' ' + tx_nombre in ('perez carmen','debuono fabiana marisel','ignatti mauro','martin nicolas botta','vivardo miguel angel') then 1 else 0 end)macro,
sum(case when asistente is not null then 1 else 0 end) [1L],
sum(1)t
from tramites t left join roster_bo r on tx_apellido + ' ' + tx_nombre = nombres
left join [10.105.8.249].cate.dbo.roster_1l r1 on left(replace(replace(tx_apellido+tx_nombre,' ',''),',',''),10) collate Modern_Spanish_CI_AS = left(replace(replace(asistente,' ',''),',',''),10)
where tx_apellido not like 'BATCH%' and tx_apellido <> 'INTERACCION GPYM-COT'
group by tx_tipo_tramite, tx_producto_es
order by sum(1) desc

select * from [10.105.8.249].cate.dbo.roster_1l
select * from roster_bo where sup in('blanco','pernice')
select * from tramites where tx_apellido = 'vivardo'

select tx_apellido, sum(1) from tramites group by tx_apellido order by sum(1) desc
select  tx_apellido, sum(1) from tramites where tx_producto_es = 'PRECIO NO PRESUPUESTADO'
group by tx_apellido order by sum(1) desc

select  top 10 * from tramites where tx_producto_es = 'PRECIO NO PRESUPUESTADO'
020213341872

select distinct cd_pedido_cliente,
case 
	when sup is not null then 'bo'  
	when tx_apellido + ' ' + tx_nombre in ('perez carmen','debuono fabiana marisel','ignatti mauro','martin nicolas botta','vivardo miguel angel') then 'macro'
	when asistente is not null then '1L'
	else 'otros' end sector
into #p
from tramites t left join roster_bo r on tx_apellido + ' ' + tx_nombre = nombres
left join [10.105.8.249].cate.dbo.roster_1l r1 on left(replace(replace(tx_apellido+tx_nombre,' ',''),',',''),10) collate Modern_Spanish_CI_AS = left(replace(replace(asistente,' ',''),',',''),10)
where tx_apellido not like 'BATCH%' and tx_apellido <> 'INTERACCION GPYM-COT'

select sector, sum(1) from #p group by sector

group by tx_tipo_tramite, tx_producto_es
order by sum(1) desc

'perez carmen','debuono fabiana marisel','ignatti mauro','martin nicolas botta','vivardo miguel angel'
zcem18
ddc059
pym034
zcem12
une262



select * from roster_bo where sup = 'reclamos'

select 24*7
CREATE procedure sp_pendientes(@action varchar(10)=null, @not_action varchar(10)=null)             
as                    
select swreceiver,
sum(1)Q,                
isnull(avg(case when datediff(hour,swdatecreated,getdate())>168 then (datediff(hour,swdatecreated,getdate())-168)/24.0 else null end),0) 'tm_atraso(dias)',                  
round(SUM(CASE WHEN datediff(hour,swdatecreated,getdate()) <=48                THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%0-2 T',                    
round(SUM(CASE WHEN datediff(hour,swdatecreated,getdate()) between 49  and 120 THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%3-5 T',                    
round(SUM(CASE WHEN datediff(hour,swdatecreated,getdate()) between 121 and 168 THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%5-7 T',                    
round(SUM(CASE WHEN datediff(hour,swdatecreated,getdate()) >169                THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%>=8 T',                    
isnull(avg(case when datediff(hour,swdatereceived,getdate())>168                then (datediff(hour,swdatereceived,getdate())-168)/24.0 else null end),0) 'tm_atraso(dias)',                  
round(SUM(CASE WHEN datediff(hour,swdatereceived,getdate()) <=48                THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%0-2 i',                    
round(SUM(CASE WHEN datediff(hour,swdatereceived,getdate()) between 49  and 120 THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%3-5 i',                    
round(SUM(CASE WHEN datediff(hour,swdatereceived,getdate()) between 121 and 168 THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%5-7 i',            
round(SUM(CASE WHEN datediff(hour,swdatereceived,getdate()) >169                THEN 1 ELSE 0 END)*1.0 / SUM(1)*100.0,2) '%>=8 i'                                 
from PENDIENTES i
where swreceiver in      
(
'py_grec_sanchezvf',
'Gest_RecNYP_RodriguE',
'Gest_RecNYP_Regadiod',
'py_grec_Gervini',
'py_grec_Coarasa',
'gest_RecNyP_AlessioA',
'Gest_RecNYP_CejasM',
'py_grec_Delgado',
'Gest_RecNYP_CivesA',
'Gest_RecNYP_ScinicaS',
'Gest_recNYP_CampomaG',
'Pend_Rec_Voz',
'Py_Receptores_rec')
and swdatereceived > dateadd(year,-2,getdate())        
group by swreceiver
with rollup


  
  
  
  select * from PENDIENTES i inner join roster_bo r on i.swreceiver = r.inbox  
  
  select * from roster_bo
  
  
  
  
  sp_helptext sp_puntualidad
  
  
  
  select * from casos where swcaseid in (select swobjectid from 
  
  
  
  select year(swdateresolved)anio, month(swdateresolved)mes, avg(datediff(hour, swdatecreated, swdateresolved))tm, sum(1)q, sum(case when datediff(hour, swdatecreated, swdateresolved) > 48 then 1 else 0 end)*1.0/sum(1) [>48]
from casos c where swcaseid in (select swobjectid from inbox i inner join roster_bo r on i.swreceiver = r.inbox and sup = 'dsoc')
group by year(swdateresolved), month(swdateresolved)
order by year(swdateresolved), month(swdateresolved)