-- TRA ADSL
select 
case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END cliente,
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a 
inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
inner join parque_speedy p on a.ani = p.ani and p.tx_producto not like 'mega%' and p.tx_producto not like '%cam%' 
where 
year(fh_cierre) = 2012
and cd_tipo_actuacion_cierre not in (334,344)
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)
order by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)

drop table #t
select a.ani, fh_ingreso, fh_cierre, cd_tipo_actuacion_apertura, cd_tipo_actuacion_cierre, pb.cd_party_titular -20000000000 cd_party, case when p.ani is not null then 1 else 0 end bl_adsl, null r
into #t
from cate..averias a
inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
left join parque_speedy p on a.ani = p.ani and p.tx_producto not like 'mega%' and p.tx_producto not like '%cam%' 
inner join parque_basica pb on pb.ani = a.ani
where fh_cierre >= dateadd(month,-6, getdate())
and cd_tipo_actuacion_cierre not in (334,344)

select anio, mes, a.ani, q, cd_party_titular - 20000000000 from (
select year(fh_cierre)anio, month(fh_cierre)mes , ani, sum(1) q from #t 
group by year(fh_cierre), month(fh_cierre), ani)a
inner join parque_basica p on p.ani = a.ani


select top 10 * from #t

select * from dt_tipo_cliente


--reiterados ADSL
select case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
END  cd_undidad_negocio, month(fh_cierre) mes, count(*), count(distinct a.ani) 
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
	inner join parque_speedy p on a.ani = p.ani and p.tx_producto like 'speed%'
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = 2012
group by case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS'
 END, month(fh_cierre) 

--reiterados TB
select case	when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' 
END  cd_undidad_negocio, month(fh_cierre) mes, count(*), count(distinct ani) 
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where cd_tipo_actuacion_cierre not in (334,344)
and year(fh_cierre) = 2012
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre) 

-- TRA TB
select 
case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END cliente,
month(fh_cierre) mes,
sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) dentro,
cast(sum(case when datediff(hour, fh_ingreso, fh_cierre) <=48 then 1 else 0 end) as real)/cast(count(*) as real)*100 '%_dentro'
from cate..averias a inner join dt_tipo_cliente t on a.cd_tipo_cliente = t.cd_tipo_cliente  and cd_unidad_negocio in ('pca','pnc')
where 
year(fh_cierre) = 2012
and cd_tipo_actuacion_cierre not in (334,344)
group by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)
order by case when T.tx_tipo_cliente like 'ALTO VALOR%' then 'ALTO VALOR' 
		when T.tx_tipo_cliente like 'ALTO RIESGO%' then 'ALTO RIESGO' 
		when T.tx_tipo_cliente like 'MASIVOS%' then 'MASIVOS' 
		when T.tx_tipo_cliente like 'TOP%' then 'TOP' 
		when T.CD_tipo_cliente IN ('0E','0R','0G') THEN 'COMPETENCIA'
ELSE 'OTROS' END, month(fh_cierre)

select * from

select * into tempdb..actividad from openquery(dw,'select cd_party, p.cd_actividad, a.tx_actividad from tasa.party p
        inner join tasa.party_tipo_cliente t on p.cd_tipo_cliente = t.cd_tipo_cliente and cd_unidad_negocio = ''pym''
        inner join tasa.actividad a on p.cd_actividad = a.cd_actividad
        and fc_baja is  null')
        
        select * from 