select * into skills from openquery(ge,'select * from contact_unpre.skill_201205 union all select * from contact_unpre.skill_201206')

select p.pcrc, p.segmento, s.*   from skills s                                      
 inner join pseudoskill p on  REPLACE(REPLACE(dbo.splitindex(skill,'|',0),'_apy',''),'_TRIADA','') = p.pseudoskill                          
