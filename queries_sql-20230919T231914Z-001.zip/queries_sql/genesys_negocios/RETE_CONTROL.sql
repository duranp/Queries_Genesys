select --date_time, 
dia,  at, ab, ofr/*, sum(answered) ansWERED, sum(abandoned)abaNDONED,  sum(entered) ent,
CASE WHEN AT > 0 THEN (AT-sum(answered))/AT ELSE 0 END GATP_AT, 
CASE WHEN AB > 0 THEN (AB-sum(aBANDONed))/AB ELSE 0 END GAP_AB,
CASE WHEN (AB+AT)> 0 THEN AB*100.0/(AB+AT) ELSE 0 END TA_OL, CASE WHEN (SUM(ABANDONED)+SUM(ANSWERED))> 0 THEN  SUM(ABANDONED)*100/(SUM(ABANDONED)+SUM(ANSWERED)) ELSE 0 END TA_SK,
CASE WHEN (AB+AT)> 0 THEN AB*100.0/(AB+AT) ELSE 0 END -CASE WHEN (SUM(ABANDONED)+SUM(ANSWERED))> 0 THEN  SUM(ABANDONED)*100/(SUM(ABANDONED)+SUM(ANSWERED)) ELSE 0 END  GAP_EF*/
from (
select    
DBO.DMY(TIMESTAMP) dia,
tx_vq,    
sum(case when tx_stat = 'Total_Calls_Answered' then valor else 0 end) AT,    
sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end) AB,    
sum(case when tx_stat = 'Total_Calls_Entered' then valor else 0 end) OFR,    
cast(case when sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end) = 0 then 0 else sum(case when tx_stat = 'Total_Calls_Abandoned' then valor else 0 end)*1.0 /sum(case when tx_stat = 'Total_Calls_Entered' then valor else 0 end)*100.0   
  
end as numeric(6,2)) TA    
from stats_online s left join (select distinct replace(pseudoskill,'_oun','') ps, atencion from pseudoskill) p on replace(s.tx_vq,'vq_','') = ps    
where tx_vq like 'VQ_Comercial_Alto_Valor'
group by DBO.DMY(TIMESTAMP), tx_vq 
)o
	inner join skill_DAY s on dbo.f(date_time) = o.dia and skill in ('Comercial_Alto_Valor','Comercial_Alto_Valor_apy','Comercial_Alto_Valor_Triada','Comercial_Alto_Valor|Comercial_Alto_Valor,Comercial_Alto_Valor_apy')
group by date_time, dia,  at, ab, ofr
order by dia DESC




select SUM(1), pcrc from roster_cm
WHERE FC_BAJA IS NULL
GROUP BY PCRC
update roster_CM SET PCRC = NULL WHERE PCRC = ''

select * FROM ROSTER_CM WHERE (sk like '%no_PERS%' OR VAG IN ('VAG_CC_ATENTO_CORDOBA')) AND FC_BAJA IS NULL
AND SUP NOT LIKE '%serafi%'
WHERE FC_BAJA IS NULL AND PCRC IS NULL
GROUP BY PCRC

SELECT * FROM ROSTER_CM WHERE SK LIKE '%CORDOBA_RETE,%' AND FC_BAJA IS NULL--AND SK LIKE '%CORDOBA_RETE%' 