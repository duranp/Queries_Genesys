
DROP TABLE #CUIT



select * from stats_online where tx_vq like '%rete%' and dbo.dmy(timestamp) = dbo.dmy(getdate())
DROP TABLE #S
select * into #s from openquery(dw,
'select FC_CUMPLIMIENTO, CD_ESTADO_TRAMITE, rtrim(cd_interurbano)||rtrim(cd_urbano)||cd_linea ani, cd_pedido_cliente, cd_sub_pedido, cd_tramite, tx_producto from tasa.tramites t
        inner join tasa.producto p on t.cd_producto_es = p.cd_producto
        inner join tasa.party_Tipo_cliente tc on t.cd_tipo_cliente = tc.cd_tipo_cliente and tc.cd_unidad_negocio = ''pym''
where
fc_cumplimiento >= ''01/05/2012''
and cd_producto_es like ''023%''')
SELECT * FROM #S WHERE ANI IN (SELECT ANI FROM DW..PARQUE WHERE CD_PRODUCTO_ES IS NOT NULL)