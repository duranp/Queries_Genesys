
select * from vtv..casos C INNER JOIN VTV..CLIENTES CU ON C.SWCUSTOMERID = CU.SWCUSTOMERID where cctclasificacionid in (
4802.00000,
4810.00000,
4812.00000,
4816.00000,
4848.00000,
4851.00000,
4854.00000)
and dbo.dmy(swdatecreated) = dbo.dmy(getdate()-1)
DROP TABLE #T
SELECT * into #t FROM OPENQUERY(DW,'
select sp.cd_pedido_cliente -20000000000 cd_pedido_cliente, sp.fc_cumplimiento, T.CD_PRODUCTO_ES -20000000000 CD_PRODUCTO_ES 
from
    tasa.sub_pedido sp
		inner join tasa.tramites t
			on t.cd_pedido_cliente = sp.cd_pedido_cliente and t.cd_sub_pedido = sp.cd_sub_pedido
        inner join tasa.party_tipo_cliente c
            on sp.cd_tipo_cliente = c.cd_tipo_cliente and cd_unidad_negocio = ''PYM''        
        where
(
	(cd_producto_es in(''0230000046031'', 
	''0230000067920'',
	''0230000068159'',
	''0230000068123'',
	''0230000068162'',
	''0230000068120'', 
	''0230000068110'') and t.cd_tipo_tramite = 502)
	or (cd_producto_es = ''0230000068148'' and t.cd_tipo_tramite = 516)
	or (cd_producto_es = ''0230000068149'' and t.cd_tipo_tramite = 514)
)
 and t.fc_cumplimiento >= date-1
 and t.cd_estado_tramite in (''fa'',''cu'')
')



select c.cctclasificacionid, m.cctdescripcion, s.cctdescsubmotivo, c.cctdescripcion  from vtv..clasificacion c 
	inner join vtv..submotivo s on c.cctsubmotivoid = s.cctsubmotivoid 
	inner join vtv..motivo m on s.cctmotivoid = m.cctmotivoid 
where cctclasificacionid in (
4802.00000,
4810.00000,
4812.00000,
4816.00000,
4848.00000,
4851.00000,
4854.00000)
order by s.cctdescsubmotivo


create table MAILING_SVA(
	tx_campa�a varchar(1000),
	tx_plantilla varchar(100),
	tx_titulo varchar(200), 
	TX_BODY VARCHAR(MAX), 
	CCTCLASIFICACIONID INT, 
	CD_PRODUCTO_ES BIGINT)

insert into [10.105.8.249].cate.dbo.e_envio_generico (tx_mail, tx_body, tx_titulo)
--desvio SELECT * FROM MAILING_SVA
INSERT INTO MAILING_SVA
select 'SVA','DESVIOS','Activaci�n Servicio Desv�o Directo',
'<style> td{border:1px solid darkblue;padding:0px}'+
'    table{font-family:calibri;font-size:11pt;color:darkblue;font-weight:bolder}'+
'</style>'+
'<div style="font-family:calibri;font-size:11pt;color:darkblue;line-height:25px; text-indent:20">'+
'<p>Estimado �xxxcliente�</p>'+
'<p>En esta oportunidad nos contactamos para informarle que su pedido de alta de Desv�o Directo ya se encuentra cumplido y disponible para su uso.</p>'+
'<p>Este servicio le permitir� recibir llamadas dirigidas a su n�mero telef�nico, en otro n�mero previamente programado por Ud.</p>'+
'<p>Le recordamos que el costo mensual  del mismo es de $1,55 + IVA  mensual. </p>'+
'<p>Cuando activa el desv�o, abonar� las llamadas que se realicen entre su l�nea y la que haya elegido como destino.</p>'+
'<p>Para activar o desactivar el Desv�o deber� proceder de la siguiente forma:</p>'+
'<table cellSpacing="0">'+
'    <tr><td>Para ACTIVAR EL DESVIO</td><td>* 40 * Nro Telef�nico a desviar #</td></tr>'+
'    <tr><td>Para DESACTIVAR EL DESVIO</td><td><center># 40 #</center></td></tr>'+
'</table>'+
'<p><u><i>Ejemplos de activaci�n:</i></u></p>'+
'<table cellSpacing="0">'+
'    <tr><td style="border:0px">&nbsp</td><td>A N�mero Fijo</td><td>A celular</td></tr>'+
'    <tr><td>Misma localidad y caracter�stica/prefijo</td><td>*40* 4xxx-xxxx #</td><td>*40* 15-xxxx-xxxx #</td></tr>'+
'    <tr><td>Diferente localidad o caracter�stica/prefijo</td><td>*40* 011-4xxx-xxxx #</td><td>*40* 0221-15-xxxx-xxxx #</td></tr>'+
'</table>'+
'<p>Le comentamos como informaci�n adicional que el desvi� cuenta con acceso remoto, lo que significa que lo puede habilitar no solo desde la propia l�nea, sino en forma remota si no se encuentra dentro del domicilio. Para activarlo en forma remota deber� ingresar al 0800-222-8008 y all� escuchar las opciones. La clave inicial del servicio de 4 d�gitos, son los �ltimos 4 n�meros de la l�nea.</p>'+
'<p><b>Condici�n: se requiere para poder activar remotamente el desv�o que se active por primera vez desde la l�nea sobre la que dio de alta el mismo.</b></p>'+
'<br />'+
'</div>'+
'<span style="font-family:calibri;font-size:15pt;color:darkblue;line-height:10px;"><b><p style="font-size:13pt">Saludos cordiales,</p><br />Centro de Atenci�n Telefonica Negocios</b></span>',
4851,230000046031

--memobox
insert into MAILING_SVA
select 'SVA','MEMOBOX','Activaci�n Servicio Memobox',
'<style> td{border:1px solid darkblue;padding:0px}'+
'    table{font-family:calibri;font-size:11pt;color:darkblue;font-weight:bolder}'+
'</style>'+
'<div style="font-family:calibri;font-size:11pt;color:darkblue;line-height:25px; text-indent:20">'+
'<p>Estimado �xxxcliente�</p>'+
'<p>En esta oportunidad nos contactamos para informarle que su pedido de alta de contestador ya se encuentra cumplido y disponible para su uso.</p>'+
'<p>Este servicio le permitir� recibir llamadas cuando su l�nea se encuentre ocupada o no conteste, y guardar los mensajes para despu�s recuperarlos desde su propio tel�fono o cualquier otro. </p>'+
'<p>Le recordamos que el costo del mismo es de $3 + IVA mensual.</p>'+
'<p>El recupero de mensajes es  gratuito a nivel urbano, y con cargo en forma interurbana o internacional, pero no se pagar� en el momento sino con la factura telef�nica.</p>'+
'<p>Para recuperar los mensajes deber� proceder de la siguiente forma:'+
'<ul>'+
'<li>Desde su propio tel�fono, marcando *123 (en forma gratuita).</li>'+
'<li>Desde cualquier tel�fono a nivel nacional, marcando 0-800-333-0269.</li>'+
'<li>Desde el exterior, marcando 0054-800-333-0269.( Esta llamada ser� con cargo al origen de la llamada)</li>'+
'</ul>'+
'</p>'+
'<p>Para escuchar los mensajes, una vez que se ingres� al sistema, se deben seguir los siguientes pasos:'+
'<ol>'+
'<li>Marque el n�mero de casilla (no es necesario si recupera mensajes desde su l�nea).El n�mero de casilla est� formado por su prefijo interurbano (sin el cero) y su n�mero telef�nico (ejemplo: 114332-9663, para la l�nea 4332-9663, de Capital Federal).</li>'+
'<li>Marque la clave de seguridad (inicialmente, formada por los cuatro �ltimos d�gitos de su n�mero telef�nico). </li>'+
'<li>Una locuci�n informar� sobre la cantidad de mensajes nuevos y guardados.</li>'+
'<li>Marque "1" para escuchar los mensajes</li>'+
'</ol>'+
'</p>'+
'<p>Para cambiar el mensaje de bienvenida acceda desde la l�nea sobre que posee el contestador,  marcando *123 (en forma gratuita): '+
'<ol>'+
'<li>Marque la clave de seguridad (inicialmente, formada por los cuatro �ltimos d�gitos de su n�mero telef�nico). </li>'+
'<li>Pulse "3" para modificar las opciones personales.</li>'+
'<li>Marcando "1" podr� cambiar su mensaje de bienvenida (nombre o mensaje)</li>'+
'</ol>'+
'</p>'+
'</div>'+
'<span style="font-family:calibri;font-size:15pt;color:darkblue;line-height:10px;"><b><p style="font-size:13pt">Saludos cordiales,</p><br />Centro de Atenci�n Telefonica Negocios</b></span>',
4854,230000067920


--detallada
insert into MAILING_SVA
select 'SVA','DETALLADA','Activaci�n Servicio Informaci�n Detallada',
'<style> td{border:1px solid darkblue;padding:0px}'+
'    table{font-family:calibri;font-size:11pt;color:darkblue;font-weight:bolder}'+
'</style>'+
'<div style="font-family:calibri;font-size:11pt;color:darkblue;line-height:25px; text-indent:20">'+
'<p>Estimado �xxxcliente�</p>'+
'<p>En esta oportunidad nos contactamos para informarle que su pedido de alta de informaci�n detallada ya se encuentra cumplido.</p>'+
'<p>Por favor tenga en cuenta que de acuerdo al cierre de la facturaci�n de este mes, la informaci�n detallada podr� recibirla a partir de  la pr�xima factura o de la subsiguiente.</p>'+
'<p>Recuerde que si est� adherido a Factura sin Papel, podr� visualizar su facturaci�n a trav�s de la p�gina web http://www.telefonica.com.ar/ accediendo a Mi Cuenta. All� podr� ver y descargar su factura, programar avisos por sms y mail, realizar pagos y dem�s gestiones sobre sus l�neas.</p>'+
'</div>'+
'<span style="font-family:calibri;font-size:15pt;color:darkblue;line-height:10px;"><b><p style="font-size:13pt">Saludos cordiales,</p><br />Centro de Atenci�n Telefonica Negocios</b></span>',
4848,230000068110


--rotacion
insert into MAILING_SVA
select 'SVA','ROTACION','Activaci�n Servicio L�neas Rotativas',
'<style> td{border:1px solid darkblue;padding:0px}'+
'    table{font-family:calibri;font-size:11pt;color:darkblue;font-weight:bolder}'+
'</style>'+
'<div style="font-family:calibri;font-size:11pt;color:darkblue;line-height:25px; text-indent:20">'+
'<p>Estimado �xxxcliente�</p>'+
'<p>En esta oportunidad nos contactamos para informarle que su pedido de rotatividad  ya se encuentra cumplido.</p>'+
'<p>Le recordamos que este servicio es gratuito y tiene como beneficio permitirle no perder llamadas entrantes y que sus clientes solo deban recordar el n�mero telef�nico de la cabecera.</p>'+
'</div>'+
'<span style="font-family:calibri;font-size:15pt;color:darkblue;line-height:10px;"><b><p style="font-size:13pt">Saludos cordiales,</p><br />Centro de Atenci�n Telefonica Negocios</b></span>',
4802,230000068149




